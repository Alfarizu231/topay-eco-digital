import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  ewalletProviders,
  bankProviders,
  serviceItems,
  promoItems,
} from './data/mockData';
import {
  Transaction,
  UserProfile,
  ServiceItem,
  EWalletProvider,
} from './types';

// Components
import { SplashScreen } from './components/SplashScreen';
import { LoginScreen } from './components/LoginScreen';
import { AppHeader } from './components/AppHeader';
import { BalanceCard } from './components/BalanceCard';
import { QuickActions } from './components/QuickActions';
import { ServicesGrid } from './components/ServicesGrid';
import { BottomNavigation, TabType } from './components/BottomNavigation';
import { RiwayatScreen } from './components/RiwayatScreen';
import { PromoScreen } from './components/PromoScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { EditProfileModal } from './components/EditProfileModal';
import { ChangePinModal } from './components/ChangePinModal';
import { ConnectedDevicesModal } from './components/ConnectedDevicesModal';
import { HelpCenterModal } from './components/HelpCenterModal';
import { LegalDocModal } from './components/LegalDocModal';
import { TopUpEWalletModal } from './components/TopUpEWalletModal';
import { QRISModal } from './components/QRISModal';
import { TransferModal } from './components/TransferModal';
import { TopUpModal } from './components/TopUpModal';
import { ServiceModal } from './components/ServiceModal';
import { SecurityCenterModal } from './components/SecurityCenterModal';
import { ReceiptModal } from './components/ReceiptModal';
import { AdminDashboard } from './components/AdminDashboard';
import { TransactionPinModal, TransactionSummaryData } from './components/TransactionPinModal';
import { CashFlowDashboardModal } from './components/CashFlowDashboardModal';
import { SeoHead, SeoPageKey } from './components/SeoHead';
import { authFetch, getUserAuthToken } from './utils/authFetch';
import { Smartphone, Monitor, ChevronRight, Sparkles, CheckCircle2, Info, AlertTriangle, X, Activity } from 'lucide-react';

type AuthStatus = 'loading' | 'authenticated' | 'unauthenticated';

interface ToastState {
  id: string;
  type: 'success' | 'info' | 'error';
  message: string;
}

const PUBLIC_SEO_ROUTES: Record<string, { section: 'home' | 'layanan' | 'promo' | 'keamanan' | 'faq'; sectionId?: string }> = {
  '/': { section: 'home' },
  '/layanan': { section: 'layanan', sectionId: 'layanan' },
  '/promo': { section: 'promo', sectionId: 'promo' },
  '/keamanan': { section: 'keamanan', sectionId: 'keamanan' },
  '/faq': { section: 'faq', sectionId: 'faq' },
};

function isCrawlerOrBot(): boolean {
  if (typeof navigator === 'undefined') return false;
  const ua = navigator.userAgent || '';
  return (
    navigator.webdriver === true ||
    /bot|crawler|spider|googlebot|bingbot|slurp|duckduckbot|baiduspider|yandex|facebot|twitterbot|whatsapp|linkedinbot/i.test(ua)
  );
}

const EMPTY_USER_PROFILE: UserProfile = {
  name: '',
  username: '',
  phone: '',
  email: '',
  avatarUrl: '',
  membershipTier: 'Reguler',
  balance: 0,
  ecoPoints: 0,
  treesPlanted: 0,
  co2SavedKg: 0,
  isPhoneVerified: false,
  isEmailVerified: false,
  isPinActive: false,
  isBiometricActive: false,
  securityScore: 0,
};

export default function App() {
  // App State
  const initialPath = typeof window !== 'undefined' ? window.location.pathname : '/';
  const [currentPath, setCurrentPath] = useState<string>(initialPath);
  const [showSplash, setShowSplash] = useState<boolean>(() => {
    if (isCrawlerOrBot()) return false;
    if (initialPath !== '/' && PUBLIC_SEO_ROUTES[initialPath]) return false;
    return true;
  });
  const [authStatus, setAuthStatus] = useState<AuthStatus>('loading');
  const [currentView, setCurrentView] = useState<'app' | 'admin'>('app');
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  const [phoneFrameMode, setPhoneFrameMode] = useState<boolean>(false);
  const [toast, setToast] = useState<ToastState | null>(null);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDarkMode);
  }, [isDarkMode]);

  // Business Data State (Initialized cleanly from persistent session cache and refreshed from backend API)
  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('topay_user_profile');
      if (saved) {
        return { ...EMPTY_USER_PROFILE, ...JSON.parse(saved) };
      }
    } catch {
      // fallback
    }
    return EMPTY_USER_PROFILE;
  });

  const [transactions, setTransactions] = useState<Transaction[]>([]);

  // Helper: Show Floating Toast
  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = Date.now().toString();
    setToast({ id, type, message });
    setTimeout(() => {
      setToast((curr) => (curr?.id === id ? null : curr));
    }, 3800);
  };

  // Modals state
  const [showTopUpModal, setShowTopUpModal] = useState(false);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [showQRISModal, setShowQRISModal] = useState(false);
  const [showEWalletModal, setShowEWalletModal] = useState(false);
  const [showSecurityCenter, setShowSecurityCenter] = useState(false);
  const [showCashFlowModal, setShowCashFlowModal] = useState(false);
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [showChangePinModal, setShowChangePinModal] = useState(false);
  const [showConnectedDevicesModal, setShowConnectedDevicesModal] = useState(false);
  const [showHelpCenterModal, setShowHelpCenterModal] = useState(false);
  const [legalModalType, setLegalModalType] = useState<'terms' | 'privacy' | null>(null);

  const [activeServiceModal, setActiveServiceModal] = useState<ServiceItem | null>(null);
  const [activeReceipt, setActiveReceipt] = useState<Transaction | null>(null);

  // Mandatory PIN Verification Modal state
  const [pendingTransaction, setPendingTransaction] = useState<TransactionSummaryData | null>(null);
  const [showPinModal, setShowPinModal] = useState<boolean>(false);

  // Helper to re-fetch profile and transactions from server
  const refreshAppData = () => {
    if (!getUserAuthToken()) return;

    authFetch('/api/profile')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.success && data.user) {
          setUser((prev) => {
            const updated = { ...prev, ...data.user };
            localStorage.setItem('topay_user_profile', JSON.stringify(updated));
            return updated;
          });
        }
      })
      .catch((err) => console.warn('Profile refresh error:', err));

    authFetch('/api/transactions')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.success && Array.isArray(data.transactions)) {
          setTransactions(data.transactions);
        }
      })
      .catch((err) => console.warn('Transactions refresh error:', err));
  };

  // Check Auth Session and Synchronize with backend API on mount
  useEffect(() => {
    const token = getUserAuthToken();

    if (token) {
      authFetch('/api/auth/session')
        .then((res) => {
          const contentType = res.headers.get('content-type');
          if (contentType && contentType.includes('application/json')) {
            return res.json();
          }
          return null;
        })
        .then((data) => {
          if (data && data.success && data.authenticated && data.user) {
            setUser((prev) => {
              const updated = { ...prev, ...data.user };
              localStorage.setItem('topay_user_profile', JSON.stringify(updated));
              return updated;
            });
            setAuthStatus('authenticated');
            refreshAppData();
          } else {
            localStorage.removeItem('topay_auth_token');
            sessionStorage.removeItem('topay_auth_token');
            setAuthStatus('unauthenticated');
          }
        })
        .catch((err) => {
          console.warn('Session verification error:', err);
          setAuthStatus('unauthenticated');
        });
    } else {
      setAuthStatus('unauthenticated');
    }
  }, []);

  // Sync browser popstate & scroll to SEO section if landing directly on /layanan, /promo, /keamanan, /faq
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
    };
    window.addEventListener('popstate', handlePopState);

    const routeInfo = PUBLIC_SEO_ROUTES[window.location.pathname];
    if (routeInfo?.sectionId) {
      setTimeout(() => {
        document.getElementById(routeInfo.sectionId!)?.scrollIntoView({ behavior: 'smooth' });
      }, 150);
    }

    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handlePublicNavigate = (path: string, sectionId?: string) => {
    if (window.location.pathname !== path) {
      window.history.pushState({}, '', path);
      setCurrentPath(path);
    }
    if (sectionId) {
      setTimeout(() => {
        document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
      }, 60);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Compute active SEO page key
  const getSeoPageKey = (): SeoPageKey => {
    if (currentView === 'admin') return 'admin';
    if (authStatus === 'authenticated') {
      if (activeTab === 'riwayat') return 'riwayat';
      if (activeTab === 'promo') return 'promo';
      if (activeTab === 'profile') return 'profile';
      if (activeTab === 'qris') return 'qris';
      return 'home';
    }
    const routeMatch = PUBLIC_SEO_ROUTES[currentPath];
    if (routeMatch && routeMatch.section !== 'home') {
      return routeMatch.section;
    }
    return 'login';
  };

  // Fire eco green confetti helper
  const triggerGreenConfetti = () => {
    confetti({
      particleCount: 75,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#143D28', '#6BCB37', '#74C642', '#A3E635', '#FFFFFF'],
    });
  };

  // Profile Update Handler (Persistent)
  const handleProfileUpdated = (updatedUser: UserProfile) => {
    setUser(updatedUser);
    try {
      localStorage.setItem('topay_user_profile', JSON.stringify(updatedUser));
    } catch (err) {
      console.warn('LocalStorage error:', err);
    }
  };

  // Login Handler (Real Session Creation)
  const handleLoginSuccess = (userData?: any, token?: string) => {
    if (token) {
      localStorage.setItem('topay_auth_token', token);
      sessionStorage.setItem('topay_auth_token', token);
    }
    if (userData) {
      setUser((prev) => {
        const updated = { ...prev, ...userData };
        localStorage.setItem('topay_user_profile', JSON.stringify(updated));
        return updated;
      });
    } else {
      // Re-read latest cached profile
      try {
        const saved = localStorage.getItem('topay_user_profile');
        if (saved) {
          setUser((prev) => ({ ...prev, ...JSON.parse(saved) }));
        }
      } catch {
        // ignore
      }
    }
    setAuthStatus('authenticated');
    refreshAppData();
    showToast('Berhasil masuk kembali.', 'success');
  };

  // Logout Handler (Real Session Teardown)
  const handleLogout = async () => {
    const token = localStorage.getItem('topay_auth_token') || sessionStorage.getItem('topay_auth_token');
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ token }),
      });
    } catch (err) {
      console.warn('Logout API error:', err);
    }

    // Clean active authentication tokens & cached profile
    localStorage.removeItem('topay_auth_token');
    sessionStorage.removeItem('topay_auth_token');
    localStorage.removeItem('topay_user_profile');

    // Close all open modals
    setShowTopUpModal(false);
    setShowTransferModal(false);
    setShowQRISModal(false);
    setShowEWalletModal(false);
    setShowSecurityCenter(false);
    setShowCashFlowModal(false);
    setShowEditProfileModal(false);
    setShowChangePinModal(false);
    setShowConnectedDevicesModal(false);
    setShowHelpCenterModal(false);
    setLegalModalType(null);
    setActiveServiceModal(null);
    setActiveReceipt(null);

    // Reset state & views
    setUser(EMPTY_USER_PROFILE);
    setTransactions([]);
    setAuthStatus('unauthenticated');
    setActiveTab('home');
    setCurrentView('app');

    // Notify user with requested message
    showToast('Anda berhasil keluar dari akun.', 'info');
  };

  // Top Up Handler - Step 1: Open PIN Modal
  const handleTopUpSuccess = (amount: number, method: string) => {
    setPendingTransaction({
      title: `Top Up Saldo via ${method}`,
      category: 'Top Up Saldo',
      type: 'topup',
      amount,
      fee: 0,
      direction: 'in',
      recipientOrSender: method,
      note: 'Top Up Saldo TO PAY',
    });
    setShowTopUpModal(false);
    setShowPinModal(true);
  };

  // Transfer Handler - Step 1: Open PIN Modal
  const handleTransferComplete = (txData: {
    type: 'topay' | 'bank';
    recipient: string;
    accountNumber: string;
    bankName?: string;
    amount: number;
    note: string;
    fee: number;
  }) => {
    setPendingTransaction({
      title: txData.type === 'topay' ? 'Transfer ke TO PAY' : `Transfer ke ${txData.bankName || 'Bank'}`,
      category: txData.type === 'topay' ? 'Transfer TO PAY' : 'Transfer Bank',
      type: 'transfer',
      amount: txData.amount,
      fee: txData.fee,
      recipientOrSender: txData.recipient,
      accountNumber: txData.accountNumber,
      note: txData.note,
    });
    setShowTransferModal(false);
    setShowPinModal(true);
  };

  // QRIS Payment Complete Handler (from QRISModal which has internal PIN verification)
  const handleQRISPayment = (completedTx: Transaction) => {
    setUser((prev) => {
      const newBal = prev.balance - completedTx.amount - (completedTx.fee || 0);
      const newPoints = prev.ecoPoints + (completedTx.ecoImpact?.ecoPoints || 15);
      const newCo2 = Number((prev.co2SavedKg + (completedTx.ecoImpact?.co2SavedKg || 0.5)).toFixed(1));
      const updated = {
        ...prev,
        balance: Math.max(0, newBal),
        ecoPoints: newPoints,
        co2SavedKg: newCo2,
      };
      localStorage.setItem('topay_user_profile', JSON.stringify(updated));
      return updated;
    });

    setTransactions((prev) => [completedTx, ...prev]);
    setShowQRISModal(false);
    setActiveReceipt(completedTx);
    triggerGreenConfetti();
  };

  // Top Up E-Wallet Handler - Step 1: Open PIN Modal
  const handleEWalletTopUp = (data: {
    provider: EWalletProvider;
    amount: number;
    phone: string;
    adminFee: number;
  }) => {
    setPendingTransaction({
      title: `Top Up E-Wallet ${data.provider.name}`,
      category: 'E-Wallet',
      type: 'ewallet',
      amount: data.amount,
      fee: data.adminFee,
      recipientOrSender: `${data.provider.name} - ${data.phone}`,
      accountNumber: data.phone,
      note: `Top Up Saldo ${data.provider.name}`,
    });
    setShowEWalletModal(false);
    setShowPinModal(true);
  };

  // Bill / Service Payment Handler - Step 1: Open PIN Modal
  const handleServicePayment = (data: {
    serviceName: string;
    amount: number;
    accountOrNumber: string;
    category: string;
  }) => {
    setPendingTransaction({
      title: data.serviceName,
      category: data.category,
      type: 'bill',
      amount: data.amount,
      fee: 0,
      recipientOrSender: `No: ${data.accountOrNumber}`,
      accountNumber: data.accountOrNumber,
      note: `Pembayaran ${data.serviceName}`,
    });
    setActiveServiceModal(null);
    setShowPinModal(true);
  };

  // Universal Handler after PIN is cryptographically verified on Backend
  const handlePinTransactionSuccess = (result: { transaction: Transaction; newBalance: number }) => {
    setUser((prev) => {
      const updated = {
        ...prev,
        balance: result.newBalance,
        ecoPoints: prev.ecoPoints + (result.transaction.ecoImpact?.ecoPoints || 10),
        co2SavedKg: Number((prev.co2SavedKg + (result.transaction.ecoImpact?.co2SavedKg || 0.3)).toFixed(1)),
      };
      localStorage.setItem('topay_user_profile', JSON.stringify(updated));
      return updated;
    });
    setTransactions((prev) => [result.transaction, ...prev]);
    setShowPinModal(false);
    setPendingTransaction(null);
    setActiveReceipt(result.transaction);
    triggerGreenConfetti();
    showToast(`Transaksi ${result.transaction.title} berhasil diautentikasi dengan PIN!`, 'success');
  };

  // Quick Action Selector
  const handleQuickAction = (action: 'topup' | 'transfer' | 'qris' | 'pay') => {
    if (action === 'topup') setShowTopUpModal(true);
    else if (action === 'transfer') setShowTransferModal(true);
    else if (action === 'qris') setShowQRISModal(true);
    else if (action === 'pay') {
      const plnService = serviceItems.find((s) => s.id === 'pln') || serviceItems[0];
      setActiveServiceModal(plnService);
    }
  };

  // Services Grid Selector
  const handleSelectService = (service: ServiceItem) => {
    if (service.id === 'ewallet') {
      setShowEWalletModal(true);
    } else {
      setActiveServiceModal(service);
    }
  };

  const activeSeoPageKey = getSeoPageKey();
  const activePublicSection = PUBLIC_SEO_ROUTES[currentPath]?.section || 'home';

  // 1. Login / Public Screen (with non-blocking Splash overlay when loading)
  if (authStatus !== 'authenticated') {
    return (
      <div className={`relative min-h-screen ${isDarkMode ? 'dark bg-[#0A1610]' : 'bg-[#F5F9F6]'}`}>
        <SeoHead pageKey={activeSeoPageKey} />
        {(showSplash || authStatus === 'loading') && (
          <SplashScreen onFinish={() => setShowSplash(false)} isDarkMode={isDarkMode} />
        )}
        {/* Floating Toast on Login Screen */}
        {toast && (
          <div className="fixed top-4 inset-x-0 mx-auto max-w-sm z-[100] px-4 pointer-events-auto animate-in fade-in slide-in-from-top-4 duration-300">
            <div
              className={`p-3.5 rounded-2xl shadow-xl border flex items-center justify-between gap-3 text-xs sm:text-sm font-semibold transition-all ${
                toast.type === 'success'
                  ? 'bg-[#143D28] text-white border-[#2A6546]'
                  : toast.type === 'info'
                    ? 'bg-[#0F2D1F] text-emerald-50 border-[#1E4E36]'
                    : 'bg-rose-900 text-white border-rose-700'
              }`}
            >
              <div className="flex items-center gap-2.5">
                {toast.type === 'success' && <CheckCircle2 className="w-5 h-5 text-[#6BCB37] shrink-0" />}
                {toast.type === 'info' && <Info className="w-5 h-5 text-[#6BCB37] shrink-0" />}
                {toast.type === 'error' && <AlertTriangle className="w-5 h-5 text-rose-300 shrink-0" />}
                <span>{toast.message}</span>
              </div>
              <button
                type="button"
                onClick={() => setToast(null)}
                className="text-gray-300 hover:text-white cursor-pointer p-0.5"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
        <LoginScreen
          onLoginSuccess={handleLoginSuccess}
          isDarkMode={isDarkMode}
          activeSection={activePublicSection}
          onNavigate={handlePublicNavigate}
          onOpenLegal={(type) => setLegalModalType(type)}
        />
        {legalModalType && (
          <LegalDocModal
            type={legalModalType}
            isOpen={!!legalModalType}
            onClose={() => setLegalModalType(null)}
            isDarkMode={isDarkMode}
          />
        )}
      </div>
    );
  }

  // 3. Web Admin Dashboard View
  if (currentView === 'admin') {
    return (
      <div className={isDarkMode ? 'dark bg-[#0A1610]' : 'bg-[#FAFCFA]'}>
        <SeoHead pageKey="admin" />
        {/* Floating Toast on Admin */}
        {toast && (
          <div className="fixed top-4 inset-x-0 mx-auto max-w-sm z-[100] px-4 pointer-events-auto">
            <div className="p-3.5 rounded-2xl bg-[#143D28] text-white border border-[#2A6546] shadow-xl flex items-center justify-between gap-3 text-xs sm:text-sm font-semibold">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-[#6BCB37] shrink-0" />
                <span>{toast.message}</span>
              </div>
              <button type="button" onClick={() => setToast(null)} className="text-gray-300 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
        <AdminDashboard
          transactions={transactions}
          onBackToApp={() => setCurrentView('app')}
          isDarkMode={isDarkMode}
        />
      </div>
    );
  }

  // 4. Mobile Application View
  return (
    <div
      className={`min-h-screen transition-colors ${
        isDarkMode ? 'dark bg-[#0A1610] text-white' : 'bg-[#F4F7F4] text-[#0F2D1F]'
      }`}
    >
      <SeoHead pageKey={activeSeoPageKey} />
      {showSplash && <SplashScreen onFinish={() => setShowSplash(false)} isDarkMode={isDarkMode} />}
      {/* Top Floating App/Web Mode Bar */}
      <div className="w-full bg-[#143D28] text-white px-4 py-2 text-xs flex items-center justify-between shadow-xs sticky top-0 z-30">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#6BCB37] animate-pulse" />
          <span className="font-bold tracking-wide">TO PAY • Digital Eco Payment</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setPhoneFrameMode(!phoneFrameMode)}
            className={`hidden md:flex items-center gap-1 px-2.5 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
              phoneFrameMode ? 'bg-[#6BCB37] text-[#0F2D1F]' : 'bg-white/15 text-white hover:bg-white/25'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>{phoneFrameMode ? 'Full Layout' : 'Frame Ponsel'}</span>
          </button>

          <button
            type="button"
            onClick={() => setCurrentView('admin')}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#6BCB37] text-[#0F2D1F] hover:bg-[#78d447] font-extrabold transition-all cursor-pointer shadow-xs"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Web Admin Dashboard</span>
          </button>
        </div>
      </div>

      {/* Floating Toast Notification Banner */}
      {toast && (
        <div className="fixed top-12 inset-x-0 mx-auto max-w-sm z-[100] px-4 pointer-events-auto animate-in fade-in slide-in-from-top-4 duration-300">
          <div
            className={`p-3.5 rounded-2xl shadow-2xl border flex items-center justify-between gap-3 text-xs sm:text-sm font-semibold transition-all ${
              toast.type === 'success'
                ? 'bg-[#143D28] text-white border-[#2A6546]'
                : toast.type === 'info'
                  ? 'bg-[#0F2D1F] text-emerald-50 border-[#1E4E36]'
                  : 'bg-rose-900 text-white border-rose-700'
            }`}
          >
            <div className="flex items-center gap-2.5">
              {toast.type === 'success' && <CheckCircle2 className="w-5 h-5 text-[#6BCB37] shrink-0" />}
              {toast.type === 'info' && <Info className="w-5 h-5 text-[#6BCB37] shrink-0" />}
              {toast.type === 'error' && <AlertTriangle className="w-5 h-5 text-rose-300 shrink-0" />}
              <span>{toast.message}</span>
            </div>
            <button
              type="button"
              onClick={() => setToast(null)}
              className="text-gray-300 hover:text-white cursor-pointer p-0.5"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Container Wrapper */}
      <div className={`mx-auto ${phoneFrameMode ? 'max-w-md py-6 px-3' : 'max-w-md md:max-w-lg lg:max-w-xl py-4 px-4'}`}>
        <div
          className={`relative rounded-3xl transition-all ${
            phoneFrameMode
              ? isDarkMode
                ? 'bg-[#12281E] border-8 border-neutral-800 shadow-2xl p-4 min-h-[850px]'
                : 'bg-white border-8 border-neutral-800 shadow-2xl p-4 min-h-[850px]'
              : isDarkMode
                ? 'bg-[#12281E] border border-[#1E4330] p-4 sm:p-5 shadow-sm'
                : 'bg-white border border-[#E2ECE5] p-4 sm:p-5 shadow-sm'
          }`}
        >
          {/* Header */}
          <AppHeader
            user={user}
            onProfileClick={() => setActiveTab('profile')}
            onNotificationsClick={() => showToast('Semua transaksi terlindungi dan berjalan normal', 'info')}
            onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
            onSwitchToAdmin={() => setCurrentView('admin')}
            isDarkMode={isDarkMode}
            isHomeTab={activeTab === 'home'}
          />

          {/* Active Tab Content */}
          <main className="pb-24 pt-2">
            {activeTab === 'home' && (
              <div className="space-y-5">
                {/* 6. BALANCE CARD */}
                <BalanceCard
                  balance={user.balance}
                  ecoPoints={user.ecoPoints}
                  treesPlanted={user.treesPlanted}
                  onTopUpClick={() => setShowTopUpModal(true)}
                  onTransferClick={() => setShowTransferModal(true)}
                  onSecurityClick={() => setShowSecurityCenter(true)}
                  onCashFlowClick={() => setShowCashFlowModal(true)}
                  isDarkMode={isDarkMode}
                />

                {/* 7. QUICK ACTION */}
                <QuickActions
                  onSelectAction={handleQuickAction}
                  isDarkMode={isDarkMode}
                />

                {/* 8. SERVICES (10 Services Grid) */}
                <ServicesGrid
                  services={serviceItems}
                  onSelectService={handleSelectService}
                  isDarkMode={isDarkMode}
                />

                {/* Promo Highlights in Home */}
                <div className="pt-1">
                  <div className="flex items-center justify-between mb-2.5">
                    <h2 className="text-sm font-bold text-[#143D28] dark:text-white flex items-center gap-1.5">
                      <span>Promo Spesial TO PAY</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#EAF6EE] text-[#143D28] dark:bg-[#1B3A29] dark:text-[#6BCB37]">
                        Terbaru
                      </span>
                    </h2>
                    <button
                      type="button"
                      onClick={() => setActiveTab('promo')}
                      className="text-xs font-bold text-[#143D28] dark:text-[#6BCB37] hover:underline cursor-pointer flex items-center gap-0.5"
                    >
                      <span>Lihat Semua</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div
                    onClick={() => setActiveTab('promo')}
                    className="p-4 rounded-2xl bg-gradient-to-r from-[#143D28] to-[#1F543A] text-white relative overflow-hidden cursor-pointer shadow-md transition-transform hover:scale-[1.01]"
                  >
                    <div className="relative z-10">
                      <span className="text-[10px] font-bold bg-[#6BCB37] text-[#0F2D1F] px-2 py-0.5 rounded-full">
                        Cashback 30%
                      </span>
                      <h3 className="text-base font-extrabold mt-1 text-white">
                        Belanja Hijau & Tanam Bibit Mangrove
                      </h3>
                      <p className="text-xs text-emerald-100/90 mt-0.5">
                        Gunakan QRIS TO PAY di merchant ramah lingkungan.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Recent Transactions Preview in Home */}
                <div>
                  <div className="flex items-center justify-between mb-2.5">
                    <h2 className="text-sm font-bold text-[#143D28] dark:text-white">
                      Aktivitas Terkini
                    </h2>
                    <button
                      type="button"
                      onClick={() => setActiveTab('riwayat')}
                      className="text-xs font-bold text-[#143D28] dark:text-[#6BCB37] hover:underline cursor-pointer flex items-center gap-0.5"
                    >
                      <span>Selengkapnya</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="space-y-2">
                    {transactions.length === 0 ? (
                      <div
                        className={`p-4 rounded-xl border text-center text-xs ${
                          isDarkMode
                            ? 'bg-[#153222] border-[#1E4330] text-gray-300'
                            : 'bg-white border-[#E6EFE8] text-gray-500'
                        }`}
                      >
                        Belum ada aktivitas transaksi pada akun ini.
                      </div>
                    ) : (
                      transactions.slice(0, 3).map((tx) => (
                        <div
                          key={tx.id}
                          onClick={() => setActiveReceipt(tx)}
                          className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                            isDarkMode
                              ? 'bg-[#153222] border-[#1E4330] hover:bg-[#1A3D2A]'
                              : 'bg-white border-[#E6EFE8] hover:bg-[#F9FCFA]'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="w-8 h-8 rounded-lg bg-[#EAF6EE] dark:bg-[#1A3828] flex items-center justify-center text-[#143D28] dark:text-[#6BCB37]">
                              <Sparkles className="w-4 h-4 text-[#6BCB37]" />
                            </div>
                            <div className="min-w-0">
                              <div className="text-xs font-bold text-[#143D28] dark:text-white truncate">
                                {tx.title}
                              </div>
                              <div className="text-[10px] text-gray-500 truncate">{tx.date}</div>
                            </div>
                          </div>

                          <div className="text-xs font-extrabold text-[#143D28] dark:text-white">
                            {tx.direction === 'in' ? '+' : '-'}Rp{tx.amount.toLocaleString('id-ID')}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* 12. RIWAYAT TRANSAKSI */}
            {activeTab === 'riwayat' && (
              <RiwayatScreen
                transactions={transactions}
                onSelectTransaction={(tx) => setActiveReceipt(tx)}
                isDarkMode={isDarkMode}
              />
            )}

            {/* 10. QRIS */}
            {activeTab === 'qris' && (
              <div className="space-y-4">
                <button
                  type="button"
                  onClick={() => setShowQRISModal(true)}
                  className="w-full py-4 rounded-2xl bg-[#143D28] hover:bg-[#0E2C1D] text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                >
                  <Sparkles className="w-5 h-5 text-[#6BCB37]" />
                  <span>Buka Scanner QRIS TO PAY</span>
                </button>
              </div>
            )}

            {/* 13. PROMO */}
            {activeTab === 'promo' && (
              <PromoScreen promos={promoItems} isDarkMode={isDarkMode} />
            )}

            {/* 14. PROFILE */}
            {activeTab === 'profile' && (
              <ProfileScreen
                user={user}
                onOpenSecurity={() => setShowSecurityCenter(true)}
                onOpenEditProfile={() => setShowEditProfileModal(true)}
                onOpenChangePin={() => setShowChangePinModal(true)}
                onOpenConnectedDevices={() => setShowConnectedDevicesModal(true)}
                onOpenHelpCenter={() => setShowHelpCenterModal(true)}
                onOpenLegalTerms={() => setLegalModalType('terms')}
                onOpenLegalPrivacy={() => setLegalModalType('privacy')}
                onLogout={handleLogout}
                onNotificationToggled={(val) => {
                  setUser((prev) => ({ ...prev, isNotificationActive: val }));
                }}
                onBiometricToggled={(val) => {
                  setUser((prev) => ({ ...prev, isBiometricActive: val }));
                }}
                isDarkMode={isDarkMode}
              />
            )}
          </main>

          {/* 17. BOTTOM NAVIGATION */}
          <BottomNavigation
            activeTab={activeTab}
            onTabChange={(tab) => {
              if (tab === 'qris') {
                setShowQRISModal(true);
              } else {
                setActiveTab(tab);
              }
            }}
            onQRISClick={() => setShowQRISModal(true)}
            isDarkMode={isDarkMode}
          />
        </div>
      </div>

      {/* Interactive Flow Modals */}
      {/* Edit Profile Modal */}
      {showEditProfileModal && (
        <EditProfileModal
          isOpen={showEditProfileModal}
          onClose={() => setShowEditProfileModal(false)}
          user={user}
          onProfileUpdated={handleProfileUpdated}
        />
      )}

      {/* Ubah PIN Modal */}
      {showChangePinModal && (
        <ChangePinModal
          isOpen={showChangePinModal}
          onClose={() => setShowChangePinModal(false)}
          onPinChanged={() => {
            // Re-fetch profile to refresh security score if changed
            authFetch('/api/profile')
              .then((res) => (res.ok ? res.json() : null))
              .then((data) => {
                if (data && data.success && data.user) {
                  setUser((prev) => ({ ...prev, ...data.user }));
                }
              })
              .catch((err) => console.warn(err));
          }}
          isDarkMode={isDarkMode}
        />
      )}

      {/* Perangkat Terhubung Modal */}
      {showConnectedDevicesModal && (
        <ConnectedDevicesModal
          isOpen={showConnectedDevicesModal}
          onClose={() => setShowConnectedDevicesModal(false)}
          isDarkMode={isDarkMode}
        />
      )}

      {/* Pusat Bantuan Modal */}
      {showHelpCenterModal && (
        <HelpCenterModal
          isOpen={showHelpCenterModal}
          onClose={() => setShowHelpCenterModal(false)}
          isDarkMode={isDarkMode}
          transactions={transactions}
        />
      )}

      {/* Syarat & Ketentuan / Kebijakan Privasi Modal */}
      {legalModalType && (
        <LegalDocModal
          type={legalModalType}
          isOpen={!!legalModalType}
          onClose={() => setLegalModalType(null)}
          isDarkMode={isDarkMode}
        />
      )}

      {/* 9. Top Up E-Wallet Modal */}
      {showEWalletModal && (
        <TopUpEWalletModal
          providers={ewalletProviders}
          userPhone={user.phone}
          onClose={() => setShowEWalletModal(false)}
          onSubmitTopUp={handleEWalletTopUp}
          isDarkMode={isDarkMode}
        />
      )}

      {/* 10. QRIS Scanner / My QR Modal */}
      {showQRISModal && (
        <QRISModal
          user={user}
          onClose={() => setShowQRISModal(false)}
          onPaymentComplete={handleQRISPayment}
          isDarkMode={isDarkMode}
        />
      )}

      {/* 11. Transfer Uang Modal */}
      {showTransferModal && (
        <TransferModal
          bankList={bankProviders}
          userBalance={user.balance}
          onClose={() => setShowTransferModal(false)}
          onTransferComplete={handleTransferComplete}
          isDarkMode={isDarkMode}
        />
      )}

      {/* Top Up Saldo TO PAY Modal */}
      {showTopUpModal && (
        <TopUpModal
          onClose={() => setShowTopUpModal(false)}
          onTopUpSuccess={handleTopUpSuccess}
          isDarkMode={isDarkMode}
        />
      )}

      {/* 8. Service / Bill Checkout Modal */}
      {activeServiceModal && (
        <ServiceModal
          service={activeServiceModal}
          userBalance={user.balance}
          userPhone={user.phone}
          onClose={() => setActiveServiceModal(null)}
          onPaymentSuccess={handleServicePayment}
          isDarkMode={isDarkMode}
        />
      )}

      {/* 15. Security Center Modal (85/100 score + checklist) */}
      {showSecurityCenter && (
        <SecurityCenterModal
          user={user}
          onClose={() => setShowSecurityCenter(false)}
          isDarkMode={isDarkMode}
        />
      )}

      {/* Laporan Arus Kas & Audit Saldo Modal */}
      {showCashFlowModal && (
        <CashFlowDashboardModal
          onClose={() => setShowCashFlowModal(false)}
          onRefreshData={refreshAppData}
          isDarkMode={isDarkMode}
        />
      )}

      {/* Digital Receipt Modal */}
      {activeReceipt && (
        <ReceiptModal
          transaction={activeReceipt}
          onClose={() => setActiveReceipt(null)}
          onRefundSuccess={(newBal) => {
            setUser((prev) => {
              const updated = { ...prev, balance: newBal };
              localStorage.setItem('topay_user_profile', JSON.stringify(updated));
              return updated;
            });
            refreshAppData();
          }}
          isDarkMode={isDarkMode}
        />
      )}

      {/* 16. Mandatory PIN Verification Modal for Transactions */}
      {showPinModal && pendingTransaction && (
        <TransactionPinModal
          isOpen={showPinModal}
          transactionData={pendingTransaction}
          onClose={() => {
            setShowPinModal(false);
            setPendingTransaction(null);
          }}
          onSuccess={handlePinTransactionSuccess}
          isDarkMode={isDarkMode}
        />
      )}
    </div>
  );
}
