import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Copy,
  Check,
  Calendar,
  Sparkles,
  Leaf,
  QrCode,
  Tag,
  X,
  AlertCircle,
  CheckCircle2,
  Receipt,
  ArrowRight,
  RotateCcw,
} from 'lucide-react';
import { PromoItem } from '../types';

interface PromoScreenProps {
  promos: PromoItem[];
  onApplyPromo?: (promo: PromoItem) => void;
  isDarkMode?: boolean;
}

interface PromoValidationRule {
  code: string;
  title: string;
  discountType: 'DISKON_PERSEN' | 'BEBAS_ADMIN' | 'BONUS_ECO_POINTS';
  discountValue: number; // percentage (e.g., 30) or points
  maxDiscount?: number;
  validUntil: string;
  category: string;
  description: string;
}

const PROMO_RULES: Record<string, PromoValidationRule> = {
  TOPAYGREEN30: {
    code: 'TOPAYGREEN30',
    title: 'Cashback 30% Eco Merchant',
    discountType: 'DISKON_PERSEN',
    discountValue: 30,
    maxDiscount: 25000,
    validUntil: '31 Agu 2026',
    category: 'QRIS',
    description: 'Diskon 30% langsung hingga Rp25.000 untuk pembayaran QRIS.',
  },
  BEBASBIAYA26: {
    code: 'BEBASBIAYA26',
    title: 'Bebas Biaya Transfer Bank',
    discountType: 'BEBAS_ADMIN',
    discountValue: 0,
    maxDiscount: 6500,
    validUntil: '15 Sep 2026',
    category: 'Transfer',
    description: 'Potongan 100% biaya admin (Rp6.500 menjadi Rp0).',
  },
  PLANTTREE: {
    code: 'PLANTTREE',
    title: 'Tanam 1 Pohon Tiap Top Up E-Wallet',
    discountType: 'BONUS_ECO_POINTS',
    discountValue: 100,
    maxDiscount: 0,
    validUntil: '28 Agu 2026',
    category: 'E-Wallet',
    description: 'Bonus +100 Eco Points & kontribusi 1 bibit pohon mangrove.',
  },
  PLNECO15: {
    code: 'PLNECO15',
    title: 'Diskon Token Listrik PLN 15%',
    discountType: 'DISKON_PERSEN',
    discountValue: 15,
    maxDiscount: 20000,
    validUntil: '05 Sep 2026',
    category: 'Tagihan',
    description: 'Diskon 15% hingga Rp20.000 untuk pembelian token atau tagihan PLN.',
  },
};

const DEFAULT_ADMIN_FEE = 6500;

export const PromoScreen: React.FC<PromoScreenProps> = ({
  promos,
  onApplyPromo,
  isDarkMode = false,
}) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [bottomToast, setBottomToast] = useState<string | null>(null);
  const [selectedPromoModal, setSelectedPromoModal] = useState<PromoItem | null>(null);

  // Checkout & Promo Validation Modal State
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [billAmountInput, setBillAmountInput] = useState<string>('100000');
  const [promoCodeInput, setPromoCodeInput] = useState<string>('');
  const [appliedRule, setAppliedRule] = useState<PromoValidationRule | null>(null);
  const [promoError, setPromoError] = useState<string | null>(null);
  const [checkoutConfirmed, setCheckoutConfirmed] = useState(false);

  const triggerToast = (msg: string) => {
    setBottomToast(msg);
    setTimeout(() => {
      setBottomToast((curr) => (curr === msg ? null : curr));
    }, 2800);
  };

  const copyToClipboard = async (code: string) => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(code);
      } else {
        const tempInput = document.createElement('input');
        tempInput.value = code;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);
      }
    } catch {
      // Clipboard fallback ignored; still show feedback
    }
    setCopiedCode(code);
    triggerToast(`Kode promo ${code} berhasil disalin!`);
    setTimeout(() => {
      setCopiedCode((curr) => (curr === code ? null : curr));
    }, 2000);
  };

  const handleCopy = (code: string, e: React.MouseEvent) => {
    e.stopPropagation();
    void copyToClipboard(code);
  };

  const openPromoCheckout = (prefillCode?: string) => {
    setCheckoutConfirmed(false);
    setPromoError(null);
    if (prefillCode) {
      const normalized = prefillCode.trim().toUpperCase();
      setPromoCodeInput(normalized);
      const matched = PROMO_RULES[normalized] || null;
      setAppliedRule(matched);
      if (!matched) {
        setPromoError('Kode promo tidak valid atau sudah kedaluwarsa.');
      }
    } else {
      setPromoCodeInput('');
      setAppliedRule(null);
    }
    setShowCheckoutModal(true);
  };

  const handleApplyPromoCode = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setCheckoutConfirmed(false);
    const cleaned = promoCodeInput.trim().toUpperCase();
    if (!cleaned) {
      setAppliedRule(null);
      setPromoError('Kode promo tidak valid atau sudah kedaluwarsa.');
      return;
    }

    const foundRule = PROMO_RULES[cleaned];
    if (!foundRule) {
      setAppliedRule(null);
      setPromoError('Kode promo tidak valid atau sudah kedaluwarsa.');
      return;
    }

    setPromoError(null);
    setAppliedRule(foundRule);

    const matchedPromoItem = promos.find((p) => p.code.toUpperCase() === cleaned);
    if (matchedPromoItem && onApplyPromo) {
      onApplyPromo(matchedPromoItem);
    }
  };

  const handleResetPromo = () => {
    setPromoCodeInput('');
    setAppliedRule(null);
    setPromoError(null);
    setCheckoutConfirmed(false);
  };

  const checkoutTotals = useMemo(() => {
    const rawNumber = Number(billAmountInput.replace(/\D/g, '')) || 0;
    const subtotal = Math.max(0, rawNumber);
    const baseAdminFee = subtotal > 0 ? DEFAULT_ADMIN_FEE : 0;

    let adminFee = baseAdminFee;
    let discountAmount = 0;
    let bonusLabel = '';

    if (appliedRule && subtotal > 0) {
      if (appliedRule.discountType === 'DISKON_PERSEN') {
        const rawDiscount = Math.round((subtotal * appliedRule.discountValue) / 100);
        discountAmount = appliedRule.maxDiscount
          ? Math.min(rawDiscount, appliedRule.maxDiscount)
          : rawDiscount;
      } else if (appliedRule.discountType === 'BEBAS_ADMIN') {
        adminFee = 0;
      } else if (appliedRule.discountType === 'BONUS_ECO_POINTS') {
        bonusLabel = `+${appliedRule.discountValue} Eco Points & 1 Pohon`;
      }
    }

    const totalPayable = Math.max(0, subtotal + adminFee - discountAmount);
    const totalSaved = (baseAdminFee - adminFee) + discountAmount;

    return {
      subtotal,
      baseAdminFee,
      adminFee,
      discountAmount,
      bonusLabel,
      totalPayable,
      totalSaved,
    };
  }, [billAmountInput, appliedRule]);

  return (
    <div className="w-full space-y-4">
      {/* Header + QRIS / Checkout Trigger */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold text-[#143D28] dark:text-white">
            Promo TO PAY
          </h1>
          <p className="text-xs text-gray-600 dark:text-gray-300">
            Penawaran eksklusif, cashback & pembayaran promo hijau
          </p>
        </div>

        <button
          type="button"
          onClick={() => openPromoCheckout()}
          className="px-3.5 py-2.5 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] dark:bg-[#6BCB37] dark:hover:bg-[#5ab829] text-white dark:text-[#0F2D1F] text-xs font-extrabold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer whitespace-nowrap"
        >
          <QrCode className="w-4 h-4" />
          <span>Bayar dengan Promo</span>
        </button>
      </div>

      {/* Featured Banner */}
      <div className="relative rounded-2xl bg-gradient-to-r from-[#143D28] via-[#1A4D34] to-[#123824] text-white p-5 sm:p-6 overflow-hidden shadow-lg border border-[#20553A]">
        <div className="absolute inset-0 pointer-events-none opacity-20">
          <svg className="w-full h-full" viewBox="0 0 300 150" fill="none">
            <path d="M-10 120 C 60 100, 140 30, 310 10" stroke="#6BCB37" strokeWidth="2.5" />
            <path d="M30 140 C 100 120, 180 60, 320 50" stroke="#FFFFFF" strokeWidth="1.5" />
            <circle cx="270" cy="30" r="40" fill="#6BCB37" fillOpacity="0.1" />
          </svg>
        </div>

        <div className="relative z-10 max-w-md space-y-2.5">
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#6BCB37] text-[#0F2D1F]">
            <Sparkles className="w-3 h-3" />
            Eco Cashback Spesial
          </span>
          <h2 className="text-xl font-extrabold text-white">
            Hemat Hingga 30% Tiap Belanja
          </h2>
          <p className="text-xs text-emerald-100/90">
            Gunakan QRIS TO PAY di lebih dari 25.000 gerai mitra ramah lingkungan dengan potongan hingga Rp25.000.
          </p>
          <div className="pt-1 flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={(e) => handleCopy('TOPAYGREEN30', e)}
              className="text-xs bg-white/15 hover:bg-white/25 px-3 py-1.5 rounded-lg font-mono font-bold text-[#A3E635] flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {copiedCode === 'TOPAYGREEN30' ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Tersalin!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>KODE: TOPAYGREEN30</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => openPromoCheckout('TOPAYGREEN30')}
              className="text-xs bg-[#6BCB37] hover:bg-[#7ad847] text-[#0F2D1F] px-3 py-1.5 rounded-lg font-extrabold flex items-center gap-1 transition-colors cursor-pointer"
            >
              <span>Gunakan Promo</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Promo Cards List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {promos.map((promo) => {
          const isCopied = copiedCode === promo.code;
          return (
            <motion.div
              key={promo.id}
              whileHover={{ scale: 1.01 }}
              onClick={() => setSelectedPromoModal(promo)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between relative overflow-hidden ${
                isDarkMode
                  ? 'bg-[#12281E] border-[#1E4330] hover:border-[#6BCB37]'
                  : 'bg-white border-[#E2ECE5] hover:border-[#143D28] shadow-xs'
              }`}
            >
              <div className="absolute top-2 right-2 opacity-10 pointer-events-none">
                <Leaf className="w-12 h-12 text-[#143D28] dark:text-[#6BCB37]" />
              </div>

              <div>
                <div className="flex items-center justify-between gap-2 mb-2 text-[11px]">
                  <span className="font-bold text-[#143D28] dark:text-[#6BCB37]">
                    {promo.category}
                  </span>
                  <span className="font-extrabold text-[#143D28] dark:text-[#6BCB37]">
                    Diskon {promo.discount}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-[#143D28] dark:text-white line-clamp-1">
                  {promo.title}
                </h3>
                <p className="text-xs text-gray-600 dark:text-gray-300 mt-1 line-clamp-2">
                  {promo.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-gray-100 dark:border-gray-800 space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1 text-[11px] text-gray-500 dark:text-gray-400">
                    <Calendar className="w-3 h-3" />
                    <span>s/d {promo.validUntil}</span>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => handleCopy(promo.code, e)}
                    aria-label={`Salin kode promo ${promo.code}`}
                    className="px-2.5 py-1.5 rounded-lg bg-[#EAF6EE] hover:bg-[#D7EFE0] dark:bg-[#1A3828] dark:hover:bg-[#204E38] text-[#143D28] dark:text-[#6BCB37] text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {isCopied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-[#16A34A] dark:text-[#6BCB37]" />
                        <span>Tersalin!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span className="font-mono">{promo.code}</span>
                      </>
                    )}
                  </button>
                </div>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    openPromoCheckout(promo.code);
                  }}
                  className="w-full py-2 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] dark:bg-[#1F543A] dark:hover:bg-[#296B4B] text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Tag className="w-3.5 h-3.5 text-[#6BCB37]" />
                  <span>Gunakan Promo</span>
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Bottom Interactive QRIS Promo CTA */}
      <button
        type="button"
        onClick={() => openPromoCheckout()}
        className={`w-full p-4 rounded-2xl border flex items-center justify-between transition-all cursor-pointer ${
          isDarkMode
            ? 'bg-[#12281E] border-[#1E4330] hover:border-[#6BCB37] text-white'
            : 'bg-[#F4FAF6] border-[#D7EFE0] hover:border-[#143D28] text-[#143D28]'
        }`}
      >
        <div className="flex items-center gap-3 text-left">
          <div className="w-10 h-10 rounded-xl bg-[#143D28] text-[#6BCB37] flex items-center justify-center shrink-0">
            <QrCode className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-extrabold">Gunakan Kode Promo saat Checkout</div>
            <div className="text-xs text-gray-600 dark:text-gray-300">
              Terapkan kode seperti TOPAYGREEN30 atau BEBASBIAYA26 dan lihat perhitungan potongan langsung
            </div>
          </div>
        </div>
        <ArrowRight className="w-4 h-4 shrink-0" />
      </button>

      {/* Promo Detail Modal */}
      <AnimatePresence>
        {selectedPromoModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ duration: 0.18 }}
              className={`w-full max-w-md rounded-2xl p-5 shadow-2xl border ${
                isDarkMode
                  ? 'bg-[#12281E] border-[#1E4330] text-white'
                  : 'bg-white border-[#E2ECE5] text-[#0F2D1F]'
              }`}
            >
              <div className="flex justify-between items-center pb-3 border-b border-gray-100 dark:border-gray-800">
                <span className="text-xs font-bold text-[#143D28] dark:text-[#6BCB37]">
                  Detail Syarat & Ketentuan Promo
                </span>
                <button
                  type="button"
                  onClick={() => setSelectedPromoModal(null)}
                  className="p-1.5 text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="py-3 space-y-3">
                <h2 className="text-base font-extrabold text-[#143D28] dark:text-white">
                  {selectedPromoModal.title}
                </h2>
                <p className="text-xs text-gray-600 dark:text-gray-300">
                  {selectedPromoModal.description}
                </p>

                <div className="p-3 rounded-xl bg-[#F4FAF6] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330]">
                  <div className="text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1.5">
                    Syarat dan Ketentuan:
                  </div>
                  <ul className="text-xs space-y-1 text-gray-600 dark:text-gray-300 list-disc list-inside">
                    {selectedPromoModal.terms.map((t, idx) => (
                      <li key={idx}>{t}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row gap-2">
                <button
                  type="button"
                  onClick={() => copyToClipboard(selectedPromoModal.code)}
                  className="flex-1 py-2.5 rounded-xl bg-[#EAF6EE] hover:bg-[#D7EFE0] dark:bg-[#1A3828] dark:hover:bg-[#224A35] text-[#143D28] dark:text-[#6BCB37] font-bold text-xs cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Salin Kode</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const code = selectedPromoModal.code;
                    setSelectedPromoModal(null);
                    openPromoCheckout(code);
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white font-bold text-xs shadow-md cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Tag className="w-3.5 h-3.5 text-[#6BCB37]" />
                  <span>Gunakan di Checkout</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Pembayaran & Validasi Promo Modal */}
      <AnimatePresence>
        {showCheckoutModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs overflow-y-auto">
            <motion.div
              initial={{ scale: 0.94, opacity: 0, y: 12 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.94, opacity: 0, y: 12 }}
              transition={{ duration: 0.2 }}
              className={`w-full max-w-md rounded-2xl p-5 sm:p-6 shadow-2xl border my-auto ${
                isDarkMode
                  ? 'bg-[#12281E] border-[#1E4330] text-white'
                  : 'bg-white border-[#E2ECE5] text-[#0F2D1F]'
              }`}
            >
              {/* Modal Header */}
              <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-[#EAF6EE] dark:bg-[#1A3828] flex items-center justify-center">
                    <Receipt className="w-4 h-4 text-[#143D28] dark:text-[#6BCB37]" />
                  </div>
                  <div>
                    <h2 className="text-sm font-extrabold text-[#143D28] dark:text-white">
                      Checkout & Validasi Promo
                    </h2>
                    <p className="text-[11px] text-gray-500 dark:text-gray-400">
                      Perhitungan diskon & biaya admin secara langsung
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowCheckoutModal(false)}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 dark:hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {checkoutConfirmed ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="py-5 text-center space-y-3"
                >
                  <div className="w-14 h-14 mx-auto rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center">
                    <CheckCircle2 className="w-8 h-8 text-emerald-600 dark:text-[#6BCB37]" />
                  </div>
                  <div>
                    <h3 className="text-base font-extrabold text-[#143D28] dark:text-white">
                      Promo Berhasil Diterapkan!
                    </h3>
                    <p className="text-xs text-gray-600 dark:text-gray-300 mt-1">
                      Total tagihan akhir{' '}
                      <span className="font-bold tabular-nums text-[#143D28] dark:text-[#6BCB37]">
                        Rp{checkoutTotals.totalPayable.toLocaleString('id-ID')}
                      </span>{' '}
                      telah dihitung dengan promo{' '}
                      <span className="font-mono font-bold">
                        {appliedRule ? appliedRule.code : 'Tanpa Promo'}
                      </span>.
                    </p>
                  </div>

                  {checkoutTotals.totalSaved > 0 && (
                    <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-xs font-bold text-emerald-800 dark:text-[#A3E635]">
                      Total Hemat: Rp{checkoutTotals.totalSaved.toLocaleString('id-ID')}
                    </div>
                  )}

                  <div className="pt-2 flex gap-2">
                    <button
                      type="button"
                      onClick={handleResetPromo}
                      className="flex-1 py-2.5 rounded-xl border border-gray-200 dark:border-[#1E4330] text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-gray-50 dark:hover:bg-[#193829] cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Gunakan Promo Lain</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowCheckoutModal(false)}
                      className="flex-1 py-2.5 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white text-xs font-bold cursor-pointer"
                    >
                      Tutup
                    </button>
                  </div>
                </motion.div>
              ) : (
                <div className="py-4 space-y-4">
                  {/* Input Total Belanja */}
                  <div>
                    <label
                      htmlFor="promo-bill-amount"
                      className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1.5"
                    >
                      Total Belanja (Rp)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-500 dark:text-gray-400">
                        Rp
                      </span>
                      <input
                        id="promo-bill-amount"
                        type="text"
                        inputMode="numeric"
                        value={billAmountInput}
                        onChange={(e) => {
                          const digits = e.target.value.replace(/\D/g, '').slice(0, 9);
                          setBillAmountInput(digits);
                        }}
                        placeholder="100000"
                        className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm font-bold tabular-nums outline-none transition-colors ${
                          isDarkMode
                            ? 'bg-[#0A1610] border-[#1E4330] text-white focus:border-[#6BCB37]'
                            : 'bg-[#F9FCFA] border-[#D7EFE0] text-[#143D28] focus:border-[#143D28]'
                        }`}
                      />
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {[50000, 100000, 250000].map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => setBillAmountInput(String(preset))}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold tabular-nums border transition-colors cursor-pointer ${
                            Number(billAmountInput) === preset
                              ? 'bg-[#143D28] text-white border-[#143D28] dark:bg-[#6BCB37] dark:text-[#0F2D1F] dark:border-[#6BCB37]'
                              : 'border-gray-200 dark:border-[#1E4330] text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#1A3828]'
                          }`}
                        >
                          Rp{preset.toLocaleString('id-ID')}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Input Kode Promo + Terapkan */}
                  <form onSubmit={handleApplyPromoCode}>
                    <label
                      htmlFor="promo-code-input"
                      className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1.5"
                    >
                      Masukkan Kode Promo
                    </label>
                    <div className="flex gap-2">
                      <input
                        id="promo-code-input"
                        type="text"
                        value={promoCodeInput}
                        onChange={(e) => {
                          setPromoCodeInput(e.target.value.toUpperCase());
                          if (promoError) setPromoError(null);
                        }}
                        placeholder="Contoh: TOPAYGREEN30"
                        className={`flex-1 px-3.5 py-2.5 rounded-xl border text-xs font-mono font-bold uppercase outline-none transition-colors ${
                          isDarkMode
                            ? 'bg-[#0A1610] border-[#1E4330] text-white placeholder:text-gray-500 focus:border-[#6BCB37]'
                            : 'bg-[#F9FCFA] border-[#D7EFE0] text-[#143D28] placeholder:text-gray-400 focus:border-[#143D28]'
                        }`}
                      />
                      <button
                        type="submit"
                        className="px-4 py-2.5 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] dark:bg-[#6BCB37] dark:hover:bg-[#5ac228] text-white dark:text-[#0F2D1F] text-xs font-extrabold transition-colors cursor-pointer shrink-0"
                      >
                        Terapkan
                      </button>
                    </div>
                  </form>

                  {/* Quick Test Chips */}
                  <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                    <span className="text-gray-500 dark:text-gray-400">Kode tersedia:</span>
                    {Object.values(PROMO_RULES).map((rule) => (
                      <button
                        key={rule.code}
                        type="button"
                        onClick={() => {
                          setPromoCodeInput(rule.code);
                          setPromoError(null);
                          setAppliedRule(rule);
                        }}
                        className="px-2 py-0.5 rounded-md font-mono font-bold bg-[#EAF6EE] hover:bg-[#D7EFE0] dark:bg-[#1A3828] dark:hover:bg-[#224A35] text-[#143D28] dark:text-[#6BCB37] cursor-pointer transition-colors"
                      >
                        {rule.code}
                      </button>
                    ))}
                  </div>

                  {/* Validation Feedback */}
                  <AnimatePresence mode="wait">
                    {promoError && (
                      <motion.div
                        key="promo-error"
                        initial={{ opacity: 0, y: -4 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -4 }}
                        className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-200 text-xs font-semibold flex items-center gap-2"
                      >
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>{promoError}</span>
                      </motion.div>
                    )}

                    {appliedRule && !promoError && (
                      <motion.div
                        key={appliedRule.code}
                        initial={{ opacity: 0, y: -4 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -4 }}
                        className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-[#A3E635] text-xs flex items-start justify-between gap-2"
                      >
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600 dark:text-[#6BCB37]" />
                          <div>
                            <div className="font-extrabold">
                              Promo {appliedRule.code} diterapkan!
                            </div>
                            <div className="text-[11px] opacity-90">{appliedRule.description}</div>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={handleResetPromo}
                          className="text-[11px] font-bold underline shrink-0 cursor-pointer"
                        >
                          Hapus
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Calculation Summary */}
                  <div
                    className={`p-4 rounded-xl border space-y-2 text-xs ${
                      isDarkMode
                        ? 'bg-[#0A1610] border-[#1E4330]'
                        : 'bg-[#F4FAF6] border-[#D7EFE0]'
                    }`}
                  >
                    <div className="flex items-center justify-between text-gray-600 dark:text-gray-300">
                      <span>Harga Awal</span>
                      <span className="font-bold tabular-nums text-[#143D28] dark:text-white">
                        Rp{checkoutTotals.subtotal.toLocaleString('id-ID')}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-gray-600 dark:text-gray-300">
                      <span>Biaya Admin</span>
                      <div className="flex items-center gap-1.5 font-bold tabular-nums">
                        {appliedRule?.discountType === 'BEBAS_ADMIN' && checkoutTotals.baseAdminFee > 0 ? (
                          <>
                            <span className="line-through text-gray-400">
                              Rp{checkoutTotals.baseAdminFee.toLocaleString('id-ID')}
                            </span>
                            <span className="text-emerald-600 dark:text-[#6BCB37]">Rp0</span>
                          </>
                        ) : (
                          <span className="text-[#143D28] dark:text-white">
                            Rp{checkoutTotals.adminFee.toLocaleString('id-ID')}
                          </span>
                        )}
                      </div>
                    </div>

                    {checkoutTotals.discountAmount > 0 && (
                      <div className="flex items-center justify-between text-emerald-700 dark:text-[#6BCB37] font-bold">
                        <span>Potongan Promo ({appliedRule?.code})</span>
                        <span className="tabular-nums">
                          -Rp{checkoutTotals.discountAmount.toLocaleString('id-ID')}
                        </span>
                      </div>
                    )}

                    {checkoutTotals.bonusLabel && (
                      <div className="flex items-center justify-between text-emerald-700 dark:text-[#6BCB37] font-bold">
                        <span>Bonus Ekstra</span>
                        <span>{checkoutTotals.bonusLabel}</span>
                      </div>
                    )}

                    <div className="pt-2 border-t border-gray-200 dark:border-[#1E4330] flex items-center justify-between">
                      <span className="font-extrabold text-[#143D28] dark:text-white">
                        Total Tagihan Akhir
                      </span>
                      <motion.span
                        key={checkoutTotals.totalPayable}
                        initial={{ scale: 0.94, opacity: 0.7 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ duration: 0.16 }}
                        className="text-base font-black tabular-nums text-[#143D28] dark:text-[#6BCB37]"
                      >
                        Rp{checkoutTotals.totalPayable.toLocaleString('id-ID')}
                      </motion.span>
                    </div>
                  </div>

                  {/* Modal Footer CTA */}
                  <button
                    type="button"
                    disabled={checkoutTotals.subtotal <= 0}
                    onClick={() => setCheckoutConfirmed(true)}
                    className="w-full py-3 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] disabled:opacity-50 text-white font-extrabold text-xs shadow-md cursor-pointer transition-colors"
                  >
                    Konfirmasi Pembayaran
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Bottom Floating Toast Notification for Clipboard Copy */}
      <AnimatePresence>
        {bottomToast && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.18 }}
            className="fixed bottom-20 md:bottom-6 inset-x-0 mx-auto max-w-sm z-[120] px-4 pointer-events-auto"
          >
            <div className="px-4 py-3 rounded-2xl bg-[#143D28] text-white border border-[#2A6546] shadow-2xl flex items-center justify-between gap-2 text-xs font-bold">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#6BCB37] shrink-0" />
                <span>{bottomToast}</span>
              </div>
              <button
                type="button"
                onClick={() => setBottomToast(null)}
                className="text-emerald-200 hover:text-white cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
