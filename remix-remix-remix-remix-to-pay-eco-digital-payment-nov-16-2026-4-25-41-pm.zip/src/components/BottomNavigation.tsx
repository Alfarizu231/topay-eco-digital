import React from 'react';
import { Home, History, QrCode, Tag, User } from 'lucide-react';

export type TabType = 'home' | 'riwayat' | 'qris' | 'promo' | 'profile';

interface BottomNavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  onQRISClick: () => void;
  isDarkMode?: boolean;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  activeTab,
  onTabChange,
  onQRISClick,
  isDarkMode = false,
}) => {
  const tabs = [
    { id: 'home' as const, label: 'Home', icon: Home },
    { id: 'riwayat' as const, label: 'Riwayat', icon: History },
    { id: 'qris' as const, label: 'QRIS', icon: QrCode, isCenter: true },
    { id: 'promo' as const, label: 'Promo', icon: Tag },
    { id: 'profile' as const, label: 'Profile', icon: User },
  ];

  return (
    <nav
      aria-label="Navigasi Utama"
      className={`fixed bottom-0 inset-x-0 z-40 border-t backdrop-blur-md transition-colors ${
        isDarkMode
          ? 'bg-[#12281E]/95 border-[#1E4330]'
          : 'bg-white/95 border-[#E2ECE5] shadow-[0_-4px_20px_rgba(20,61,40,0.06)]'
      }`}
    >
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between relative">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          if (tab.isCenter) {
            return (
              <div key={tab.id} className="relative -top-5 flex flex-col items-center">
                <button
                  type="button"
                  onClick={onQRISClick}
                  className="w-14 h-14 rounded-full bg-gradient-to-tr from-[#143D28] via-[#1B4D36] to-[#0E2C1D] text-white flex items-center justify-center shadow-lg shadow-[#143D28]/35 border-3 border-[#6BCB37] hover:scale-105 active:scale-95 transition-all cursor-pointer group"
                  aria-label="Scan QRIS"
                >
                  <Icon className="w-7 h-7 text-[#6BCB37] group-hover:scale-110 transition-transform" />
                </button>
                <span className="text-[10px] font-extrabold text-[#143D28] dark:text-[#6BCB37] mt-0.5 tracking-tight">
                  QRIS
                </span>
              </div>
            );
          }

          return (
            <button
              key={tab.id}
              type="button"
              aria-current={isActive ? 'page' : undefined}
              onClick={() => onTabChange(tab.id)}
              className="flex-1 flex flex-col items-center justify-center py-1 group cursor-pointer transition-all active:scale-95"
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-colors ${
                    isActive
                      ? isDarkMode
                        ? 'text-[#6BCB37]'
                        : 'text-[#143D28]'
                      : 'text-gray-400 group-hover:text-gray-600 dark:group-hover:text-gray-300'
                  }`}
                />
                {isActive && (
                  <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-[#6BCB37]" />
                )}
              </div>
              <span
                className={`text-[10px] font-bold mt-1 transition-colors ${
                  isActive
                    ? isDarkMode
                      ? 'text-[#6BCB37]'
                      : 'text-[#143D28]'
                    : 'text-gray-400'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
