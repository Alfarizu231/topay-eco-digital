import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard,
  Users,
  Receipt,
  ShieldCheck,
  Activity,
  UserX,
  UserCheck,
  Search,
  Filter,
  Download,
  RefreshCw,
  Clock,
  Leaf,
  Lock,
  Unlock,
  KeyRound,
  LogOut,
  Eye,
  Edit3,
  AlertTriangle,
  CheckCircle2,
  X,
  ChevronRight,
  ChevronLeft,
  DollarSign,
  Smartphone,
  Sparkles,
  TrendingUp,
  BarChart3,
  Database,
  Server,
  Globe,
  FileText,
  SlidersHorizontal,
  Mail,
  Phone,
  ShieldAlert,
  Calendar,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  Info,
  Ticket,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { ToPayLogo } from './ToPayLogo';
import { AdminTicketsPanel } from './AdminTicketsPanel';
import { AdminUser, ManagedUser, AuditLogEntry, AdminOverviewStats, Transaction } from '../types';

interface AdminDashboardProps {
  transactions: Transaction[];
  onBackToApp?: () => void;
  isDarkMode?: boolean;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  transactions: initialTxList,
  onBackToApp,
  isDarkMode = false,
}) => {
  // Authentication State
  const [adminToken, setAdminToken] = useState<string | null>(() => {
    return localStorage.getItem('topay_admin_token');
  });
  const [currentAdmin, setCurrentAdmin] = useState<AdminUser | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginSubmitting, setLoginSubmitting] = useState(false);

  // Navigation & View State
  const [activeMenu, setActiveMenu] = useState<string>('dashboard');
  const [ticketsRefreshKey, setTicketsRefreshKey] = useState<number>(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Dashboard Overview Metrics State
  const [overviewStats, setOverviewStats] = useState<AdminOverviewStats | null>(null);

  // User Management State
  const [usersList, setUsersList] = useState<ManagedUser[]>([]);
  const [usersLoading, setUsersLoading] = useState(false);
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [userStatusFilter, setUserStatusFilter] = useState<'all' | 'active' | 'blocked'>('all');
  const [userTierFilter, setUserTierFilter] = useState<string>('all');
  const [selectedUserDetail, setSelectedUserDetail] = useState<any | null>(null);
  const [loadingUserDetail, setLoadingUserDetail] = useState(false);

  // Modals for Actions
  const [blockTargetUser, setBlockTargetUser] = useState<ManagedUser | null>(null);
  const [blockReasonInput, setBlockReasonInput] = useState('Terdeteksi aktivitas mencurigakan dan anomali transaksi berulang');
  const [unblockTargetUser, setUnblockTargetUser] = useState<ManagedUser | null>(null);
  const [editTargetUser, setEditTargetUser] = useState<ManagedUser | null>(null);
  const [editFormData, setEditFormData] = useState({
    name: '',
    phone: '',
    email: '',
    membershipTier: 'Eco Classic Member',
    balanceAdjustment: 0,
    adjustmentReason: '',
    isPhoneVerified: true,
    isEmailVerified: true,
  });

  // Audit Logs State
  const [auditLogsList, setAuditLogsList] = useState<AuditLogEntry[]>([]);
  const [auditLogsLoading, setAuditLogsLoading] = useState(false);
  const [auditSearchQuery, setAuditSearchQuery] = useState('');
  const [auditActionFilter, setAuditActionFilter] = useState<string>('all');

  // Transactions State
  const [adminTxList, setAdminTxList] = useState<Transaction[]>(initialTxList);
  const [txSearchQuery, setTxSearchQuery] = useState('');
  const [txTypeFilter, setTxTypeFilter] = useState('all');

  // Security Center State
  const [securityMetrics, setSecurityMetrics] = useState<any | null>(null);
  const [securityLoading, setSecurityLoading] = useState(false);
  const [lockdownPromptOpen, setLockdownPromptOpen] = useState(false);
  const [lockdownReason, setLockdownReason] = useState('');
  const [lockdownSubmitting, setLockdownSubmitting] = useState(false);
  const [purgeSessionsPromptOpen, setPurgeSessionsPromptOpen] = useState(false);
  const [purgeSubmitting, setPurgeSubmitting] = useState(false);

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Helper fetcher with admin token
  const fetchWithAuth = useCallback(
    async (url: string, options: RequestInit = {}) => {
      const token = adminToken || localStorage.getItem('topay_admin_token');
      const headers = {
        'Content-Type': 'application/json',
        'x-admin-token': token || '',
        Authorization: token ? `Bearer ${token}` : '',
        ...(options.headers || {}),
      };
      return fetch(url, { credentials: 'same-origin', ...options, headers });
    },
    [adminToken]
  );

  // 1. Verify Admin Session on Mount
  useEffect(() => {
    const verifyAdmin = async () => {
      const storedToken = localStorage.getItem('topay_admin_token');
      if (!storedToken) {
        setAuthLoading(false);
        return;
      }

      try {
        const res = await fetch('/api/admin/auth/me', {
          headers: {
            'x-admin-token': storedToken,
            Authorization: `Bearer ${storedToken}`,
          },
        });
        const data = await res.json();
        if (data.success && data.admin) {
          setCurrentAdmin(data.admin);
          setAdminToken(storedToken);
        } else {
          localStorage.removeItem('topay_admin_token');
          setAdminToken(null);
          setCurrentAdmin(null);
        }
      } catch {
        localStorage.removeItem('topay_admin_token');
        setAdminToken(null);
      } finally {
        setAuthLoading(false);
      }
    };

    verifyAdmin();
  }, []);

  // 2. Fetch Dashboard Overview Data
  const loadOverviewData = useCallback(async () => {
    if (!adminToken) return;
    setIsRefreshing(true);
    try {
      const res = await fetchWithAuth('/api/admin/overview');
      const data = await res.json();
      if (data.success && data.stats) {
        setOverviewStats(data.stats);
      }
    } catch (err) {
      console.error('Failed to load admin stats:', err);
    } finally {
      setIsRefreshing(false);
    }
  }, [adminToken, fetchWithAuth]);

  // 3. Fetch Users List
  const loadUsersData = useCallback(async () => {
    if (!adminToken) return;
    setUsersLoading(true);
    try {
      const queryParams = new URLSearchParams();
      if (userSearchQuery) queryParams.set('search', userSearchQuery);
      if (userStatusFilter !== 'all') queryParams.set('status', userStatusFilter);
      if (userTierFilter !== 'all') queryParams.set('tier', userTierFilter);

      const res = await fetchWithAuth(`/api/admin/users?${queryParams.toString()}`);
      const data = await res.json();
      if (data.success && data.users) {
        setUsersList(data.users);
      }
    } catch (err) {
      console.error('Failed to load users:', err);
    } finally {
      setUsersLoading(false);
    }
  }, [adminToken, userSearchQuery, userStatusFilter, userTierFilter, fetchWithAuth]);

  // 4. Fetch Audit Logs
  const loadAuditLogs = useCallback(async () => {
    if (!adminToken) return;
    setAuditLogsLoading(true);
    try {
      const queryParams = new URLSearchParams();
      if (auditSearchQuery) queryParams.set('search', auditSearchQuery);
      if (auditActionFilter !== 'all') queryParams.set('action', auditActionFilter);

      const res = await fetchWithAuth(`/api/admin/audit-logs?${queryParams.toString()}`);
      const data = await res.json();
      if (data.success && data.auditLogs) {
        setAuditLogsList(data.auditLogs);
      }
    } catch (err) {
      console.error('Failed to load audit logs:', err);
    } finally {
      setAuditLogsLoading(false);
    }
  }, [adminToken, auditSearchQuery, auditActionFilter, fetchWithAuth]);

  // 5. Fetch Transactions
  const loadTransactionsData = useCallback(async () => {
    if (!adminToken) return;
    try {
      const res = await fetchWithAuth('/api/admin/transactions');
      const data = await res.json();
      if (data.success && data.transactions) {
        setAdminTxList(data.transactions);
      }
    } catch (err) {
      console.error('Failed to load transactions:', err);
    }
  }, [adminToken, fetchWithAuth]);

  // 6. Fetch Security Metrics
  const loadSecurityMetrics = useCallback(async () => {
    if (!adminToken) return;
    setSecurityLoading(true);
    try {
      const res = await fetchWithAuth('/api/admin/security/metrics');
      const data = await res.json();
      if (data.success && data.security) {
        setSecurityMetrics(data.security);
      }
    } catch (err) {
      console.error('Failed to load security metrics:', err);
    } finally {
      setSecurityLoading(false);
    }
  }, [adminToken, fetchWithAuth]);

  // Handle Emergency Lockdown Toggle
  const handleToggleLockdown = async () => {
    setLockdownSubmitting(true);
    try {
      const res = await fetchWithAuth('/api/admin/security/lockdown-toggle', {
        method: 'POST',
        body: JSON.stringify({ reason: lockdownReason.trim() }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message, 'success');
        setLockdownPromptOpen(false);
        setLockdownReason('');
        loadSecurityMetrics();
        loadAuditLogs();
      } else {
        showToast(data.error || 'Gagal mengubah status lockdown.', 'error');
      }
    } catch (err) {
      showToast('Terjadi kendala jaringan.', 'error');
    } finally {
      setLockdownSubmitting(false);
    }
  };

  // Handle Resolve Incident
  const handleResolveIncident = async (incidentId: string) => {
    try {
      const res = await fetchWithAuth(`/api/admin/security/incidents/${incidentId}/resolve`, {
        method: 'POST',
        body: JSON.stringify({ notes: 'Mitigasi manual disetujui oleh Administrator.' }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('Insiden berhasil ditandai sebagai termitigasi.', 'success');
        loadSecurityMetrics();
        loadAuditLogs();
      } else {
        showToast(data.error || 'Gagal memperbarui status insiden.', 'error');
      }
    } catch {
      showToast('Gagal memproses permintaan mitigasi.', 'error');
    }
  };

  // Handle Purge All Active Platform Sessions
  const handlePurgeSessions = async () => {
    setPurgeSubmitting(true);
    try {
      const res = await fetchWithAuth('/api/admin/security/revoke-all-sessions', {
        method: 'POST',
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message, 'success');
        setPurgeSessionsPromptOpen(false);
        loadSecurityMetrics();
        loadAuditLogs();
      } else {
        showToast(data.error || 'Gagal mencabut sesi pengguna.', 'error');
      }
    } catch {
      showToast('Gagal menghubungi server pusat.', 'error');
    } finally {
      setPurgeSubmitting(false);
    }
  };

  // Load appropriate data whenever tab changes or token arrives
  useEffect(() => {
    if (adminToken) {
      if (activeMenu === 'dashboard') {
        loadOverviewData();
      } else if (activeMenu === 'users') {
        loadUsersData();
      } else if (activeMenu === 'audit') {
        loadAuditLogs();
      } else if (activeMenu === 'security') {
        loadSecurityMetrics();
        loadAuditLogs();
      } else if (activeMenu === 'transactions') {
        loadTransactionsData();
      }
    }
  }, [adminToken, activeMenu, loadOverviewData, loadUsersData, loadAuditLogs, loadTransactionsData, loadSecurityMetrics]);

  // Handle Admin Login Submission
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoginSubmitting(true);

    try {
      const res = await fetch('/api/admin/auth/login', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: loginUsername.trim(),
          password: loginPassword,
        }),
      });

      const rawText = await res.text();
      let data: any = {};
      try {
        data = JSON.parse(rawText);
      } catch {
        data = {
          success: false,
          error: `Server mengembalikan respons tidak valid (HTTP ${res.status}). Silakan coba beberapa saat lagi.`,
        };
      }

      if (res.ok && data.success && data.token && data.admin) {
        localStorage.setItem('topay_admin_token', data.token);
        setAdminToken(data.token);
        setCurrentAdmin(data.admin);
        showToast(data.message || `Selamat datang, ${data.admin.name}!`, 'success');
        loadOverviewData();
      } else {
        setLoginError(data.error || 'Autentikasi admin gagal.');
      }
    } catch {
      setLoginError('Terjadi kesalahan jaringan saat menghubungkan ke Server Otorisasi.');
    } finally {
      setLoginSubmitting(false);
    }
  };

  // Handle Admin Logout
  const handleAdminLogout = async () => {
    try {
      await fetchWithAuth('/api/admin/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    localStorage.removeItem('topay_admin_token');
    setAdminToken(null);
    setCurrentAdmin(null);
    showToast('Sesi Admin telah diakhiri dengan aman.', 'info');
  };

  // Handle View User Details
  const handleOpenUserDetail = async (user: ManagedUser) => {
    setLoadingUserDetail(true);
    setSelectedUserDetail(user);
    try {
      const res = await fetchWithAuth(`/api/admin/users/${user.id}`);
      const data = await res.json();
      if (data.success && data.user) {
        setSelectedUserDetail(data.user);
      }
    } catch (err) {
      console.error('Failed to get user details:', err);
    } finally {
      setLoadingUserDetail(false);
    }
  };

  // Handle User Block Action
  const handleConfirmBlock = async () => {
    if (!blockTargetUser) return;
    try {
      const res = await fetchWithAuth(`/api/admin/users/${blockTargetUser.id}/block`, {
        method: 'POST',
        body: JSON.stringify({ reason: blockReasonInput.trim() }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Akun ${blockTargetUser.name} berhasil diblokir. Sesi pengguna telah dicabut.`, 'success');
        setBlockTargetUser(null);
        loadUsersData();
        loadOverviewData();
        if (selectedUserDetail && selectedUserDetail.id === blockTargetUser.id) {
          setSelectedUserDetail(data.user);
        }
      } else {
        showToast(data.error || 'Gagal memblokir pengguna.', 'error');
      }
    } catch {
      showToast('Gagal memproses permintaan blokir.', 'error');
    }
  };

  // Handle User Unblock Action
  const handleConfirmUnblock = async () => {
    if (!unblockTargetUser) return;
    try {
      const res = await fetchWithAuth(`/api/admin/users/${unblockTargetUser.id}/unblock`, {
        method: 'POST',
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Blokir pada akun ${unblockTargetUser.name} berhasil dibuka.`, 'success');
        setUnblockTargetUser(null);
        loadUsersData();
        loadOverviewData();
        if (selectedUserDetail && selectedUserDetail.id === unblockTargetUser.id) {
          setSelectedUserDetail(data.user);
        }
      } else {
        showToast(data.error || 'Gagal membuka blokir.', 'error');
      }
    } catch {
      showToast('Gagal memproses pembukaan blokir.', 'error');
    }
  };

  // Handle Revoke Active Sessions
  const handleRevokeSessions = async (userId: string, userName: string) => {
    try {
      const res = await fetchWithAuth(`/api/admin/users/${userId}/revoke-sessions`, {
        method: 'POST',
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Berhasil mencabut ${data.revokedCount} sesi aktif untuk ${userName}.`, 'success');
      } else {
        showToast(data.error || 'Gagal mencabut sesi pengguna.', 'error');
      }
    } catch {
      showToast('Gagal menghubungi server.', 'error');
    }
  };

  // Handle Edit User Data Submission
  const handleSaveUserEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editTargetUser) return;

    try {
      const res = await fetchWithAuth(`/api/admin/users/${editTargetUser.id}/update`, {
        method: 'PUT',
        body: JSON.stringify(editFormData),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Data akun ${editTargetUser.name} berhasil diperbarui!`, 'success');
        setEditTargetUser(null);
        loadUsersData();
        if (selectedUserDetail && selectedUserDetail.id === editTargetUser.id) {
          setSelectedUserDetail(data.user);
        }
      } else {
        showToast(data.error || 'Gagal memperbarui data pengguna.', 'error');
      }
    } catch {
      showToast('Terjadi kesalahan saat menyimpan perubahan.', 'error');
    }
  };

  // Open Edit Form pre-filled
  const openEditModal = (user: ManagedUser) => {
    setEditTargetUser(user);
    setEditFormData({
      name: user.name,
      phone: user.phone,
      email: user.email,
      membershipTier: user.membershipTier || 'Eco Classic Member',
      balanceAdjustment: 0,
      adjustmentReason: '',
      isPhoneVerified: user.isPhoneVerified,
      isEmailVerified: user.isEmailVerified,
    });
  };

  // Strictly compliant TO PAY forest green & lime palette (NO PURPLE, NO BLUE)
  const GREEN_PALETTE = {
    forest: '#143D28',
    dark: '#0F2D1F',
    primary: '#16A34A',
    lime: '#6BCB37',
    lightLime: '#A3E635',
    softGreen: '#D7EFE0',
  };

  const pieColors = ['#143D28', '#16A34A', '#6BCB37', '#84CC16', '#F59E0B'];

  // Sidebar Menu Configuration
  const menuItems = [
    { id: 'dashboard', label: 'Overview & Metrik', icon: LayoutDashboard },
    { id: 'users', label: 'Manajemen Pengguna', icon: Users, badge: overviewStats ? `${overviewStats.totalUsers}` : '3.1k' },
    { id: 'transactions', label: 'Buku Transaksi (Ledger)', icon: Receipt },
    { id: 'tickets', label: 'Tiket & Pengaduan CS', icon: Ticket },
    { id: 'audit', label: 'Log Audit Admin', icon: FileText },
    { id: 'security', label: 'Keamanan & Sistem', icon: ShieldCheck },
  ];

  // -------------------------------------------------------------
  // 1. ADMIN LOGIN VIEW (IF NOT AUTHENTICATED)
  // -------------------------------------------------------------
  if (!adminToken || !currentAdmin) {
    if (authLoading) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[#F4F7F4] dark:bg-[#0A1610] text-[#0F2D1F] dark:text-white">
          <div className="flex flex-col items-center gap-3">
            <RefreshCw className="w-8 h-8 text-[#6BCB37] animate-spin" />
            <p className="text-sm font-bold text-[#143D28] dark:text-gray-200">
              Memverifikasi otorisasi Admin TO PAY...
            </p>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen flex flex-col justify-between bg-[#F4F7F4] dark:bg-[#0A1610] text-[#0F2D1F] dark:text-white p-4 sm:p-6">
        {/* Top bar with back to app */}
        <div className="max-w-md w-full mx-auto flex items-center justify-between">
          <ToPayLogo size="md" showText={true} showTagline={true} variant={isDarkMode ? 'white' : 'default'} />
          {onBackToApp && (
            <button
              type="button"
              onClick={onBackToApp}
              className="text-xs font-bold text-[#143D28] dark:text-[#6BCB37] hover:underline flex items-center gap-1 cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Buka Mobile App</span>
            </button>
          )}
        </div>

        {/* Center Login Box */}
        <div className="max-w-md w-full mx-auto my-auto py-8">
          <div className="bg-white dark:bg-[#12281E] border border-[#D7EFE0] dark:border-[#1E4330] rounded-3xl p-6 sm:p-8 shadow-xl">
            {/* Header Badge */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-2xl bg-[#143D28] text-[#6BCB37] flex items-center justify-center shadow-xs">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-lg font-black text-[#143D28] dark:text-white">
                    Pusat Kontrol Admin
                  </h2>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Sistem Autentikasi Terenkripsi 256-bit
                  </p>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-[#EAF6EE] text-[#143D28] dark:bg-[#163826] dark:text-[#6BCB37] border border-[#16A34A]/30">
                Restricted
              </span>
            </div>

            {/* Error banner */}
            {loginError && (
              <div className="mb-5 p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-rose-800 dark:text-rose-200 text-xs flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Akses Ditolak</p>
                  <p className="mt-0.5 leading-relaxed">{loginError}</p>
                </div>
              </div>
            )}

            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1.5">
                  Admin ID / Username
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={loginUsername}
                    onChange={(e) => setLoginUsername(e.target.value)}
                    placeholder="Masukkan ID Admin (cth: admin_utama)"
                    className="w-full pl-10 pr-4 py-3 rounded-2xl text-xs font-semibold bg-gray-50 dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] text-[#0F2D1F] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#143D28] dark:focus:ring-[#6BCB37] transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1.5">
                  Kata Sandi Admin
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full pl-10 pr-4 py-3 rounded-2xl text-xs font-semibold bg-gray-50 dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] text-[#0F2D1F] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#143D28] dark:focus:ring-[#6BCB37] transition-all"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loginSubmitting}
                className="w-full py-3.5 px-4 rounded-2xl bg-[#143D28] hover:bg-[#0E2C1D] text-white text-xs font-black tracking-wide flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all cursor-pointer disabled:opacity-50"
              >
                {loginSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-[#6BCB37]" />
                    <span>Mengautentikasi...</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4 text-[#6BCB37]" />
                    <span>Masuk ke Command Center</span>
                  </>
                )}
              </button>
            </form>
          </div>

          <div className="mt-6 text-center text-xs text-gray-400">
            <p>TO PAY Enterprise Security Node • ISO 27001 Certified • Bank Indonesia EMVCo</p>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="max-w-md w-full mx-auto text-center text-[11px] text-gray-400 pb-2">
          © 2026 PT TO PAY Digital Nusantara. All rights reserved.
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // 2. AUTHENTICATED ADMIN DASHBOARD
  // -------------------------------------------------------------
  return (
    <div className={`min-h-screen flex ${isDarkMode ? 'bg-[#0A1610] text-white' : 'bg-[#F4F7F4] text-[#0F2D1F]'}`}>
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 inset-x-0 mx-auto max-w-md z-[100] px-4 pointer-events-auto animate-in fade-in slide-in-from-top-4 duration-300">
          <div
            className={`p-3.5 rounded-2xl shadow-2xl border flex items-center justify-between gap-3 text-xs sm:text-sm font-semibold ${
              toastMessage.type === 'success'
                ? 'bg-[#143D28] text-white border-[#2A6546]'
                : toastMessage.type === 'info'
                ? 'bg-[#0F2D1F] text-emerald-50 border-[#1E4E36]'
                : 'bg-rose-900 text-white border-rose-700'
            }`}
          >
            <div className="flex items-center gap-2.5">
              {toastMessage.type === 'success' && <CheckCircle2 className="w-5 h-5 text-[#6BCB37] shrink-0" />}
              {toastMessage.type === 'info' && <Info className="w-5 h-5 text-[#6BCB37] shrink-0" />}
              {toastMessage.type === 'error' && <AlertTriangle className="w-5 h-5 text-rose-300 shrink-0" />}
              <span className="leading-snug">{toastMessage.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setToastMessage(null)}
              className="text-gray-300 hover:text-white cursor-pointer p-0.5"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Sidebar Navigation */}
      <aside
        className={`w-64 flex-shrink-0 flex flex-col justify-between border-r p-4 transition-colors hidden md:flex ${
          isDarkMode ? 'bg-[#12281E] border-[#1E4330]' : 'bg-white border-[#E2ECE5]'
        }`}
      >
        <div>
          {/* Logo & Status */}
          <div className="pb-5 pt-2 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
            <ToPayLogo size="md" showText={true} showTagline={true} variant={isDarkMode ? 'white' : 'default'} />
          </div>

          {/* Admin User Profile Card in Sidebar */}
          <div className="my-4 p-3 rounded-2xl bg-[#F0FAF3] dark:bg-[#163826] border border-[#D7EFE0] dark:border-[#1E4330] flex items-center justify-between">
            <div className="flex items-center gap-2.5 overflow-hidden">
              <img
                src={currentAdmin.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                alt={currentAdmin.name}
                className="w-8 h-8 rounded-full object-cover border border-[#6BCB37]/40 shrink-0"
              />
              <div className="min-w-0">
                <div className="text-xs font-extrabold text-[#143D28] dark:text-white truncate">
                  {currentAdmin.name}
                </div>
                <div className="text-[10px] font-bold text-[#16A34A] dark:text-[#6BCB37] uppercase">
                  {currentAdmin.role === 'superadmin' ? '👑 Superadmin' : '🛡️ Admin'}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={handleAdminLogout}
              title="Keluar dari Admin"
              className="p-1.5 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/50 text-gray-400 hover:text-rose-600 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation Links */}
          <div className="space-y-1">
            <div className="text-[10px] font-bold uppercase tracking-wider text-gray-400 px-3 mb-2">
              Pusat Kontrol
            </div>
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeMenu === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveMenu(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isActive
                      ? isDarkMode
                        ? 'bg-[#183827] text-white border border-[#6BCB37]/40 shadow-xs'
                        : 'bg-[#EAF6EE] text-[#143D28] border border-[#143D28]/10 shadow-xs'
                      : isDarkMode
                      ? 'text-gray-400 hover:bg-[#153222] hover:text-gray-200'
                      : 'text-gray-600 hover:bg-[#F4FAF6] hover:text-[#143D28]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon
                      className={`w-4 h-4 ${
                        isActive ? (isDarkMode ? 'text-[#6BCB37]' : 'text-[#143D28]') : 'text-gray-400'
                      }`}
                    />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="px-1.5 py-0.5 rounded-md text-[9px] font-mono bg-[#6BCB37] text-[#0F2D1F]">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Sidebar Footer */}
        <div className="pt-4 border-t border-gray-100 dark:border-gray-800 space-y-2">
          <div className="p-3 rounded-xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330]">
            <div className="flex items-center gap-1.5 text-xs font-bold text-[#143D28] dark:text-[#A3E635]">
              <Leaf className="w-3.5 h-3.5 text-[#6BCB37]" />
              <span>Command Center Live</span>
            </div>
            <p className="text-[10px] text-gray-500 dark:text-gray-400 mt-0.5">
              Terkoneksi ke Database & API Aktif
            </p>
          </div>

          {onBackToApp && (
            <button
              type="button"
              onClick={onBackToApp}
              className="w-full py-2 px-3 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>Buka Mobile App</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#6BCB37]" />
            </button>
          )}
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-y-auto max-h-screen">
        {/* Top Header Bar */}
        <header
          className={`sticky top-0 z-20 px-6 py-3.5 border-b flex items-center justify-between gap-4 backdrop-blur-md ${
            isDarkMode ? 'bg-[#0A1610]/90 border-[#1E4330]' : 'bg-white/90 border-[#E2ECE5]'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="md:hidden">
              <ToPayLogo size="sm" showText={false} variant={isDarkMode ? 'white' : 'default'} />
            </div>
            <div>
              <h1 className="text-base font-extrabold text-[#143D28] dark:text-white flex items-center gap-2">
                <span>
                  {activeMenu === 'dashboard' && 'Dashboard Overview'}
                  {activeMenu === 'users' && 'Manajemen Pengguna'}
                  {activeMenu === 'transactions' && 'Buku Besar Transaksi'}
                  {activeMenu === 'tickets' && 'Sistem Pengaduan & Tiket CS'}
                  {activeMenu === 'audit' && 'Log Audit Admin'}
                  {activeMenu === 'security' && 'Keamanan & Sistem'}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#EAF6EE] text-[#143D28] dark:bg-[#1B3A29] dark:text-[#6BCB37]">
                  Live Synchronized
                </span>
              </h1>
              <p className="text-[11px] text-gray-500 dark:text-gray-400 hidden sm:block">
                Pusat Kontrol Operasional & Otorisasi TO PAY (Real Database)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Refresh Button */}
            <button
              type="button"
              onClick={() => {
                if (activeMenu === 'dashboard') loadOverviewData();
                else if (activeMenu === 'users') loadUsersData();
                else if (activeMenu === 'tickets') setTicketsRefreshKey((k) => k + 1);
                else if (activeMenu === 'audit') loadAuditLogs();
                else if (activeMenu === 'transactions') loadTransactionsData();
                else if (activeMenu === 'security') loadSecurityMetrics();
              }}
              disabled={isRefreshing}
              className="p-2 rounded-xl border border-[#D7EFE0] dark:border-[#1E4330] bg-white dark:bg-[#12281E] text-[#143D28] dark:text-[#6BCB37] hover:bg-[#F0FAF3] text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Segarkan</span>
            </button>

            {/* Logout Button */}
            <button
              type="button"
              onClick={handleAdminLogout}
              className="py-1.5 px-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 text-xs font-bold flex items-center gap-1.5 hover:bg-rose-100 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Keluar</span>
            </button>

            {onBackToApp && (
              <button
                type="button"
                onClick={onBackToApp}
                className="md:hidden py-1.5 px-2.5 rounded-lg bg-[#143D28] text-white text-xs font-bold"
              >
                App
              </button>
            )}
          </div>
        </header>

        {/* Mobile Horizontal Tab Switcher */}
        <div
          className={`md:hidden flex items-center gap-1.5 overflow-x-auto px-4 py-2.5 border-b scrollbar-none ${
            isDarkMode ? 'bg-[#0F1E18] border-[#1E4330]' : 'bg-[#F8FAF8] border-[#E2ECE5]'
          }`}
        >
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeMenu === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveMenu(item.id)}
                className={`px-3 py-1.5 rounded-xl text-[11px] font-bold whitespace-nowrap flex items-center gap-1.5 transition-all cursor-pointer shrink-0 ${
                  isActive
                    ? 'bg-[#143D28] text-white border border-[#6BCB37]/40'
                    : isDarkMode
                    ? 'bg-[#12281E] text-gray-300 border border-[#1E4330]'
                    : 'bg-white text-gray-600 border border-[#E2ECE5]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#6BCB37]' : 'text-gray-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Router */}
        <div className="p-4 sm:p-6 space-y-6">
          {/* ========================================================= */}
          {/* TAB 1: DASHBOARD OVERVIEW                                 */}
          {/* ========================================================= */}
          {activeMenu === 'dashboard' && (
            <div className="space-y-6">
              {/* 10 Real-Time KPI Cards */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-sm font-extrabold text-[#143D28] dark:text-white flex items-center gap-2">
                    <Activity className="w-4 h-4 text-[#6BCB37]" />
                    <span>Ringkasan Ekosistem Real-Time</span>
                  </h2>
                  <span className="text-xs text-gray-400 font-medium">Sinkronisasi Database Aktif</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                  {/* Card 1: Total Users */}
                  <div className="p-4 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-8 h-8 rounded-xl bg-[#EAF6EE] dark:bg-[#1A3828] flex items-center justify-center">
                        <Users className="w-4 h-4 text-[#143D28] dark:text-[#6BCB37]" />
                      </div>
                      <span className="text-[10px] font-bold text-[#16A34A] bg-[#F0FAF3] dark:bg-[#163826] px-1.5 py-0.5 rounded">
                        Total
                      </span>
                    </div>
                    <div className="text-[11px] font-medium text-gray-500 dark:text-gray-400 truncate">Total Pengguna</div>
                    <div className="text-lg font-black text-[#0F2D1F] dark:text-white mt-0.5">
                      {overviewStats?.totalUsers || 3120}
                    </div>
                  </div>

                  {/* Card 2: Active Users */}
                  <div className="p-4 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-8 h-8 rounded-xl bg-[#EAF6EE] dark:bg-[#1A3828] flex items-center justify-center">
                        <UserCheck className="w-4 h-4 text-[#16A34A] dark:text-[#6BCB37]" />
                      </div>
                      <span className="text-[10px] font-bold text-[#16A34A] bg-[#F0FAF3] dark:bg-[#163826] px-1.5 py-0.5 rounded">
                        Aktif
                      </span>
                    </div>
                    <div className="text-[11px] font-medium text-gray-500 dark:text-gray-400 truncate">Pengguna Aktif</div>
                    <div className="text-lg font-black text-[#0F2D1F] dark:text-white mt-0.5">
                      {overviewStats?.activeUsers || 3118}
                    </div>
                  </div>

                  {/* Card 3: Blocked Users */}
                  <div className="p-4 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950/40 flex items-center justify-center">
                        <UserX className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                      </div>
                      <span className="text-[10px] font-bold text-rose-600 bg-rose-50 dark:bg-rose-950/50 px-1.5 py-0.5 rounded">
                        {overviewStats?.blockedUsers || 0} Terblokir
                      </span>
                    </div>
                    <div className="text-[11px] font-medium text-gray-500 dark:text-gray-400 truncate">Pengguna Diblokir</div>
                    <div className="text-lg font-black text-rose-700 dark:text-rose-400 mt-0.5">
                      {overviewStats?.blockedUsers || 0}
                    </div>
                  </div>

                  {/* Card 4: Total Transactions */}
                  <div className="p-4 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-8 h-8 rounded-xl bg-[#EAF6EE] dark:bg-[#1A3828] flex items-center justify-center">
                        <Receipt className="w-4 h-4 text-[#143D28] dark:text-[#6BCB37]" />
                      </div>
                      <span className="text-[10px] font-bold text-[#16A34A] bg-[#F0FAF3] dark:bg-[#163826] px-1.5 py-0.5 rounded">
                        +{overviewStats?.todayTransactions || 12} Hari Ini
                      </span>
                    </div>
                    <div className="text-[11px] font-medium text-gray-500 dark:text-gray-400 truncate">Total Transaksi</div>
                    <div className="text-lg font-black text-[#0F2D1F] dark:text-white mt-0.5">
                      {overviewStats?.totalTransactions || 48}
                    </div>
                  </div>

                  {/* Card 5: Total Volume */}
                  <div className="p-4 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-8 h-8 rounded-xl bg-[#EAF6EE] dark:bg-[#1A3828] flex items-center justify-center">
                        <TrendingUp className="w-4 h-4 text-[#143D28] dark:text-[#6BCB37]" />
                      </div>
                      <span className="text-[10px] font-bold text-[#16A34A] bg-[#F0FAF3] dark:bg-[#163826] px-1.5 py-0.5 rounded">
                        SLA 99.9%
                      </span>
                    </div>
                    <div className="text-[11px] font-medium text-gray-500 dark:text-gray-400 truncate">Total Volume Transaksi</div>
                    <div className="text-lg font-black text-[#143D28] dark:text-[#6BCB37] mt-0.5">
                      Rp{((overviewStats?.totalTransactionVolume || 28450000) / 1000000).toFixed(1)} Jt
                    </div>
                  </div>
                </div>
              </div>

              {/* Real-time Analytics Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                {/* User Growth & Active Trend */}
                <div className="lg:col-span-2 p-5 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-sm font-extrabold text-[#143D28] dark:text-white">
                        Pertumbuhan & Aktivitas Pengguna
                      </h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Tren akumulasi akun terdaftar vs pengguna aktif bulanan
                      </p>
                    </div>
                    <div className="flex items-center gap-3 text-xs font-semibold">
                      <span className="inline-flex items-center gap-1 text-[#143D28] dark:text-[#6BCB37]">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#143D28] dark:bg-[#6BCB37]" />
                        Total Akun
                      </span>
                      <span className="inline-flex items-center gap-1 text-[#16A34A] dark:text-[#A3E635]">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#16A34A]" />
                        Aktif
                      </span>
                    </div>
                  </div>

                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={overviewStats?.userGrowthData || []}>
                        <defs>
                          <linearGradient id="userGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={GREEN_PALETTE.lime} stopOpacity={0.5} />
                            <stop offset="95%" stopColor={GREEN_PALETTE.forest} stopOpacity={0.05} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? '#1E4330' : '#EDF4EE'} />
                        <XAxis dataKey="name" stroke={isDarkMode ? '#94A3B8' : '#64748B'} fontSize={11} tickLine={false} />
                        <YAxis stroke={isDarkMode ? '#94A3B8' : '#64748B'} fontSize={11} tickLine={false} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: isDarkMode ? '#12281E' : '#FFFFFF',
                            borderColor: GREEN_PALETTE.forest,
                            borderRadius: '12px',
                            fontSize: '12px',
                          }}
                        />
                        <Area type="monotone" dataKey="users" stroke={GREEN_PALETTE.forest} strokeWidth={2.5} fill="url(#userGrad)" name="Total Akun" />
                        <Area type="monotone" dataKey="active" stroke={GREEN_PALETTE.primary} strokeWidth={2} fillOpacity={0} name="Aktif (MAU)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Transaction Category Share */}
                <div className="p-5 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs">
                  <h3 className="text-sm font-extrabold text-[#143D28] dark:text-white mb-1">
                    Distribusi Kategori Transaksi
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">
                    Pangsa volume layanan TO PAY
                  </p>

                  <div className="h-44 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={overviewStats?.categoryBreakdown || []}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          innerRadius={40}
                          outerRadius={65}
                          paddingAngle={3}
                        >
                          {(overviewStats?.categoryBreakdown || []).map((_, index) => (
                            <Cell key={`cell-${index}`} fill={pieColors[index % pieColors.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="space-y-1.5 mt-2 text-xs">
                    {(overviewStats?.categoryBreakdown || []).map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between text-gray-600 dark:text-gray-300">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: pieColors[idx % pieColors.length] }} />
                          <span className="truncate max-w-[130px]">{item.name}</span>
                        </div>
                        <span className="font-bold text-[#143D28] dark:text-white">{item.value}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Transactions Weekly Volume Bar Chart */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="p-5 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs">
                  <h3 className="text-sm font-extrabold text-[#143D28] dark:text-white mb-1">
                    Jumlah Transaksi Harian (7 Hari Terakhir)
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">
                    Perbandingan transaksi berhasil dan gagal
                  </p>
                  <div className="h-52 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={overviewStats?.transactionCountData || []}>
                        <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? '#1E4330' : '#EDF4EE'} />
                        <XAxis dataKey="name" stroke={isDarkMode ? '#94A3B8' : '#64748B'} fontSize={11} />
                        <YAxis stroke={isDarkMode ? '#94A3B8' : '#64748B'} fontSize={11} />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="count" name="Berhasil" fill="#143D28" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="failed" name="Gagal / Timeout" fill="#EF4444" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* 24-Hour User Activity Curve */}
                <div className="p-5 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs">
                  <h3 className="text-sm font-extrabold text-[#143D28] dark:text-white mb-1">
                    Aktivitas Pengguna 24 Jam (Hourly Traffic)
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">
                    Pola transaksi puncak pada jam operasional
                  </p>
                  <div className="h-52 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={overviewStats?.userActivityData || []}>
                        <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? '#1E4330' : '#EDF4EE'} />
                        <XAxis dataKey="hour" stroke={isDarkMode ? '#94A3B8' : '#64748B'} fontSize={11} />
                        <YAxis stroke={isDarkMode ? '#94A3B8' : '#64748B'} fontSize={11} />
                        <Tooltip />
                        <Area type="monotone" dataKey="transactions" stroke="#6BCB37" fill="#6BCB37" fillOpacity={0.25} name="Transaksi / Jam" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 2: USER MANAGEMENT (MANAJEMEN PENGGUNA)               */}
          {/* ========================================================= */}
          {activeMenu === 'users' && (
            <div className="space-y-4">
              {/* Header & Controls Bar */}
              <div className="p-5 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h2 className="text-base font-extrabold text-[#143D28] dark:text-white flex items-center gap-2">
                      <Users className="w-5 h-5 text-[#6BCB37]" />
                      <span>Manajemen & Kontrol Akun Pengguna</span>
                    </h2>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Kelola status akun, pemblokiran, penyesuaian saldo, dan riwayat aktivitas pengguna
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const csvContent =
                          'data:text/csv;charset=utf-8,' +
                          ['ID,Nama,Username,No HP,Email,Status,Tier,Saldo,EcoPoints,Tgl Daftar']
                            .concat(
                              usersList.map(
                                (u) =>
                                  `"${u.id}","${u.name}","${u.username}","${u.phone}","${u.email}","${u.status}","${u.membershipTier}","${u.balance}","${u.ecoPoints}","${u.registeredAt}"`
                              )
                            )
                            .join('\n');
                        const encodedUri = encodeURI(csvContent);
                        const link = document.createElement('a');
                        link.setAttribute('href', encodedUri);
                        link.setAttribute('download', `topay_users_${Date.now()}.csv`);
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        showToast('Data pengguna berhasil diekspor ke CSV.', 'success');
                      }}
                      className="px-3 py-2 rounded-xl bg-[#EAF6EE] dark:bg-[#1A3828] text-[#143D28] dark:text-[#6BCB37] text-xs font-bold flex items-center gap-1.5 hover:bg-[#D7EFE0] transition-colors cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Ekspor Pengguna (CSV)</span>
                    </button>
                  </div>
                </div>

                {/* Filter and Search Bar */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-gray-100 dark:border-gray-800">
                  {/* Search Input */}
                  <div className="relative">
                    <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      value={userSearchQuery}
                      onChange={(e) => setUserSearchQuery(e.target.value)}
                      placeholder="Cari Nama, Username, HP, atau Email..."
                      className="w-full pl-10 pr-4 py-2 rounded-xl text-xs bg-gray-50 dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] text-[#0F2D1F] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#143D28] dark:focus:ring-[#6BCB37]"
                    />
                  </div>

                  {/* Status Filter */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-gray-400 shrink-0">Status:</span>
                    {(['all', 'active', 'blocked'] as const).map((st) => (
                      <button
                        key={st}
                        type="button"
                        onClick={() => setUserStatusFilter(st)}
                        className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          userStatusFilter === st
                            ? 'bg-[#143D28] text-white'
                            : 'bg-gray-100 dark:bg-[#0A1610] text-gray-600 dark:text-gray-400 hover:bg-gray-200'
                        }`}
                      >
                        {st === 'all' && 'Semua'}
                        {st === 'active' && 'Aktif'}
                        {st === 'blocked' && 'Diblokir'}
                      </button>
                    ))}
                  </div>

                  {/* Tier Filter */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-gray-400 shrink-0">Tier:</span>
                    <select
                      value={userTierFilter}
                      onChange={(e) => setUserTierFilter(e.target.value)}
                      className="flex-1 py-2 px-3 rounded-xl text-xs font-semibold bg-gray-50 dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] text-[#0F2D1F] dark:text-white focus:outline-none"
                    >
                      <option value="all">Semua Tier</option>
                      <option value="Eco Classic Member">Eco Classic</option>
                      <option value="Eco Gold Member">Eco Gold</option>
                      <option value="Eco Platinum Member">Eco Platinum</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Users Table */}
              <div className="p-5 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-gray-100 dark:border-gray-800 text-gray-400 uppercase text-[10px] tracking-wider">
                        <th className="pb-3 font-bold">Pengguna</th>
                        <th className="pb-3 font-bold">Kontak & Username</th>
                        <th className="pb-3 font-bold">Status Akun</th>
                        <th className="pb-3 font-bold">Tier & Skor</th>
                        <th className="pb-3 font-bold">Saldo & Poin</th>
                        <th className="pb-3 font-bold">Terdaftar</th>
                        <th className="pb-3 font-bold text-right">Tindakan Admin</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                      {usersLoading ? (
                        <tr>
                          <td colSpan={7} className="py-8 text-center text-gray-400">
                            <RefreshCw className="w-6 h-6 animate-spin mx-auto text-[#6BCB37] mb-2" />
                            <span>Memuat data pengguna dari database...</span>
                          </td>
                        </tr>
                      ) : usersList.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="py-8 text-center text-gray-400">
                            Tidak ada data pengguna yang sesuai dengan filter pencarian.
                          </td>
                        </tr>
                      ) : (
                        usersList.map((user) => {
                          const isBlocked = user.status === 'blocked';
                          return (
                            <tr key={user.id} className="hover:bg-gray-50/60 dark:hover:bg-gray-800/30 transition-colors">
                              {/* Avatar & Name */}
                              <td className="py-3.5 pr-2">
                                <div className="flex items-center gap-2.5">
                                  <img
                                    src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                                    alt={user.name}
                                    className="w-8 h-8 rounded-full object-cover border border-[#6BCB37]/30 shrink-0"
                                  />
                                  <div>
                                    <div className="font-extrabold text-[#143D28] dark:text-white flex items-center gap-1.5">
                                      <span>{user.name}</span>
                                    </div>
                                    <span className="text-[10px] font-mono text-gray-400">{user.id}</span>
                                  </div>
                                </div>
                              </td>

                              {/* Contact & Username */}
                              <td className="py-3.5">
                                <div className="space-y-0.5">
                                  <div className="font-bold text-[#143D28] dark:text-gray-200">{user.username}</div>
                                  <div className="text-[11px] text-gray-500 dark:text-gray-400 flex items-center gap-1">
                                    <Phone className="w-3 h-3 text-gray-400" />
                                    <span>{user.phone}</span>
                                  </div>
                                  <div className="text-[10px] text-gray-400 flex items-center gap-1">
                                    <Mail className="w-3 h-3 text-gray-400" />
                                    <span>{user.email}</span>
                                  </div>
                                </div>
                              </td>

                              {/* Status Badge */}
                              <td className="py-3.5">
                                {isBlocked ? (
                                  <div>
                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-300 dark:border-rose-800">
                                      <Lock className="w-3 h-3" />
                                      <span>DIBLOKIR</span>
                                    </span>
                                    {user.blockedReason && (
                                      <p className="text-[10px] text-rose-600 dark:text-rose-400 mt-1 max-w-[160px] truncate" title={user.blockedReason}>
                                        {user.blockedReason}
                                      </p>
                                    )}
                                  </div>
                                ) : (
                                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-[#EAF6EE] text-[#16A34A] dark:bg-[#163826] dark:text-[#6BCB37] border border-[#16A34A]/20">
                                    <CheckCircle2 className="w-3 h-3" />
                                    <span>AKTIF</span>
                                  </span>
                                )}
                              </td>

                              {/* Tier & Security Score */}
                              <td className="py-3.5">
                                <div className="font-bold text-xs text-[#143D28] dark:text-white">
                                  {user.membershipTier || 'Eco Classic'}
                                </div>
                                <div className="flex items-center gap-1 text-[10px] text-[#16A34A] dark:text-[#6BCB37] font-semibold mt-0.5">
                                  <ShieldCheck className="w-3 h-3" />
                                  <span>Skor {user.securityScore || 85}%</span>
                                </div>
                              </td>

                              {/* Balance & Eco Points */}
                              <td className="py-3.5">
                                <div className="font-black text-[#143D28] dark:text-white">
                                  Rp{(user.balance || 0).toLocaleString('id-ID')}
                                </div>
                                <div className="text-[10px] text-[#16A34A] dark:text-[#A3E635] font-bold flex items-center gap-1">
                                  <Leaf className="w-3 h-3" />
                                  <span>{user.ecoPoints || 0} Poin</span>
                                </div>
                              </td>

                              {/* Registered Date */}
                              <td className="py-3.5 text-gray-500 dark:text-gray-400 text-[11px]">
                                <div>{user.registeredAt}</div>
                                <div className="text-[10px] text-gray-400">Login: {user.lastLogin || '-'}</div>
                              </td>

                              {/* Action Buttons */}
                              <td className="py-3.5 text-right">
                                <div className="flex items-center justify-end gap-1.5">
                                  {/* View Detail */}
                                  <button
                                    type="button"
                                    onClick={() => handleOpenUserDetail(user)}
                                    title="Lihat Detail & Riwayat Akun"
                                    className="p-2 rounded-xl bg-gray-100 dark:bg-[#1A3828] text-[#143D28] dark:text-[#6BCB37] hover:bg-[#EAF6EE] transition-colors cursor-pointer"
                                  >
                                    <Eye className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Edit Data / Balance */}
                                  <button
                                    type="button"
                                    onClick={() => openEditModal(user)}
                                    title="Edit Data / Penyesuaian Saldo"
                                    className="p-2 rounded-xl bg-gray-100 dark:bg-[#1A3828] text-amber-700 dark:text-amber-400 hover:bg-amber-50 transition-colors cursor-pointer"
                                  >
                                    <Edit3 className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Block or Unblock */}
                                  {isBlocked ? (
                                    <button
                                      type="button"
                                      onClick={() => setUnblockTargetUser(user)}
                                      title="Buka Blokir Akun"
                                      className="px-2.5 py-1.5 rounded-xl bg-[#EAF6EE] dark:bg-[#163826] text-[#16A34A] dark:text-[#6BCB37] border border-[#16A34A]/30 text-[11px] font-black flex items-center gap-1 hover:bg-[#D7EFE0] transition-colors cursor-pointer"
                                    >
                                      <Unlock className="w-3 h-3" />
                                      <span>Buka Blokir</span>
                                    </button>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setBlockTargetUser(user);
                                        setBlockReasonInput('Pelanggaran ketentuan layanan & indikasi anomali transaksi');
                                      }}
                                      title="Blokir Akun Pengguna"
                                      className="px-2.5 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 text-[11px] font-black flex items-center gap-1 hover:bg-rose-100 transition-colors cursor-pointer"
                                    >
                                      <Lock className="w-3 h-3" />
                                      <span>Blokir</span>
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 3: TRANSACTIONS LEDGER                                */}
          {/* ========================================================= */}
          {activeMenu === 'transactions' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-base font-extrabold text-[#143D28] dark:text-white flex items-center gap-2">
                    <Receipt className="w-5 h-5 text-[#6BCB37]" />
                    <span>Buku Besar Transaksi (Master Ledger)</span>
                  </h2>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Log mutasi real-time dari QRIS, Transfer, Top Up, Tagihan, dan E-Wallet
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={txSearchQuery}
                      onChange={(e) => setTxSearchQuery(e.target.value)}
                      placeholder="Cari Referensi, Pengirim, Judul..."
                      className="pl-8 pr-3 py-1.5 rounded-xl text-xs bg-gray-50 dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] text-[#0F2D1F] dark:text-white"
                    />
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-gray-100 dark:border-gray-800 text-gray-400 uppercase text-[10px] tracking-wider">
                      <th className="pb-3 font-bold">ID Referensi</th>
                      <th className="pb-3 font-bold">Judul Transaksi</th>
                      <th className="pb-3 font-bold">Kategori</th>
                      <th className="pb-3 font-bold">Pihak Terkait</th>
                      <th className="pb-3 font-bold">Waktu</th>
                      <th className="pb-3 font-bold">Nominal</th>
                      <th className="pb-3 font-bold">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                    {adminTxList
                      .filter((tx) => {
                        if (!txSearchQuery) return true;
                        const q = txSearchQuery.toLowerCase();
                        return (
                          (tx.title && tx.title.toLowerCase().includes(q)) ||
                          (tx.referenceNumber && tx.referenceNumber.toLowerCase().includes(q)) ||
                          (tx.recipientOrSender && tx.recipientOrSender.toLowerCase().includes(q))
                        );
                      })
                      .map((tx) => (
                        <tr key={tx.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-800/30">
                          <td className="py-3 font-mono text-[11px] text-gray-500">{tx.referenceNumber}</td>
                          <td className="py-3 font-bold text-[#143D28] dark:text-white">{tx.title}</td>
                          <td className="py-3 text-gray-500">{tx.category}</td>
                          <td className="py-3 font-medium text-gray-600 dark:text-gray-300">
                            {tx.recipientOrSender || '-'}
                          </td>
                          <td className="py-3 text-gray-400">{tx.date}</td>
                          <td className="py-3 font-black text-[#143D28] dark:text-white">
                            {tx.direction === 'in' ? '+' : '-'}Rp{tx.amount.toLocaleString('id-ID')}
                          </td>
                          <td className="py-3">
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#EAF6EE] text-[#16A34A] border border-[#16A34A]/20">
                              {tx.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 4: AUDIT LOGS (LOG AUDIT ADMIN)                       */}
          {/* ========================================================= */}
          {activeMenu === 'audit' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-base font-extrabold text-[#143D28] dark:text-white flex items-center gap-2">
                    <FileText className="w-5 h-5 text-[#6BCB37]" />
                    <span>Log Audit Aktivitas Administrator</span>
                  </h2>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Rekaman jejak digital permanen setiap tindakan otoritatif dan kebijakan sistem
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={auditSearchQuery}
                      onChange={(e) => setAuditSearchQuery(e.target.value)}
                      placeholder="Cari admin, aksi, user..."
                      className="pl-8 pr-3 py-1.5 rounded-xl text-xs bg-gray-50 dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] text-[#0F2D1F] dark:text-white"
                    />
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-gray-100 dark:border-gray-800 text-gray-400 uppercase text-[10px] tracking-wider">
                      <th className="pb-3 font-bold">Waktu</th>
                      <th className="pb-3 font-bold">Admin</th>
                      <th className="pb-3 font-bold">Aksi</th>
                      <th className="pb-3 font-bold">Target</th>
                      <th className="pb-3 font-bold">Rincian Perubahan</th>
                      <th className="pb-3 font-bold">IP Address</th>
                      <th className="pb-3 font-bold">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                    {auditLogsLoading ? (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-gray-400">
                          <RefreshCw className="w-6 h-6 animate-spin mx-auto text-[#6BCB37] mb-2" />
                          <span>Memuat log audit...</span>
                        </td>
                      </tr>
                    ) : auditLogsList.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-gray-400">
                          Belum ada catatan log audit yang terekam.
                        </td>
                      </tr>
                    ) : (
                      auditLogsList.map((log) => (
                        <tr key={log.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-800/30">
                          <td className="py-3 font-mono text-[11px] text-gray-400">{log.timestamp}</td>
                          <td className="py-3 font-bold text-[#143D28] dark:text-white">{log.adminName}</td>
                          <td className="py-3">
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-gray-100 dark:bg-[#163826] text-[#143D28] dark:text-[#6BCB37]">
                              {log.action}
                            </span>
                          </td>
                          <td className="py-3 font-medium text-gray-600 dark:text-gray-300">{log.targetUser}</td>
                          <td className="py-3 text-gray-600 dark:text-gray-300 max-w-xs">{log.details}</td>
                          <td className="py-3 font-mono text-[10px] text-gray-400">{log.ipAddress || '182.253.xx.xx'}</td>
                          <td className="py-3">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                log.status === 'SUCCESS'
                                  ? 'bg-[#EAF6EE] text-[#16A34A]'
                                  : 'bg-rose-50 text-rose-700'
                              }`}
                            >
                              {log.status}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 5: SECURITY COMMAND & THREAT INTELLIGENCE              */}
          {/* ========================================================= */}
          {activeMenu === 'security' && (
            <div className="space-y-6">
              {/* Emergency Lockdown Active Alert Banner */}
              {securityMetrics?.isSystemLockdownActive && (
                <div className="p-4 rounded-2xl bg-rose-600 text-white shadow-lg flex items-center justify-between animate-pulse">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="w-6 h-6 shrink-0" />
                    <div>
                      <h3 className="font-extrabold text-sm">EMERGENCY SYSTEM LOCKDOWN SEDANG AKTIF!</h3>
                      <p className="text-xs text-rose-100">
                        Seluruh transaksi finansial, QRIS, transfer, dan topup dihentikan sementara untuk pencegahan ancaman.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setLockdownReason('Sistem telah diverifikasi aman. Melepas mode lockdown.');
                      setLockdownPromptOpen(true);
                    }}
                    className="px-4 py-2 bg-white text-rose-700 hover:bg-rose-50 text-xs font-black rounded-xl shadow-md cursor-pointer transition-colors"
                  >
                    Nonaktifkan Lockdown
                  </button>
                </div>
              )}

              {/* Security Status Header */}
              <div className="p-5 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-2xl bg-[#143D28] text-[#6BCB37] flex items-center justify-center shrink-0">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-base font-extrabold text-[#143D28] dark:text-white flex items-center gap-2">
                        <span>Pusat Komando Keamanan & Deteksi Ancaman AI</span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300">
                          Real-time
                        </span>
                      </h2>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Monitoring rate-limiting, proteksi brute-force, PBKDF2 hashing, dan respon insiden otomatis
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setLockdownPromptOpen(true)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5 ${
                        securityMetrics?.isSystemLockdownActive
                          ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                          : 'bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900/50'
                      }`}
                    >
                      <AlertTriangle className="w-4 h-4" />
                      <span>{securityMetrics?.isSystemLockdownActive ? 'Lepas Lockdown' : 'Emergency Lockdown'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPurgeSessionsPromptOpen(true)}
                      className="px-3.5 py-2 rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Cabut Semua Sesi</span>
                    </button>
                  </div>
                </div>

                {/* Telemetry Metrics Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-gray-100 dark:border-gray-800">
                  <div className="p-3.5 rounded-xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330]">
                    <div className="flex items-center justify-between text-xs font-bold text-gray-500">
                      <span>Tingkat Ancaman</span>
                      <ShieldCheck className="w-4 h-4 text-[#16A34A] dark:text-[#6BCB37]" />
                    </div>
                    <div className="text-lg font-black text-[#143D28] dark:text-[#6BCB37] mt-1">
                      {securityMetrics?.threatLevel || 'LOW'}
                    </div>
                    <p className="text-[10px] text-gray-400 mt-0.5">Semua parameter operasional hijau</p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330]">
                    <div className="flex items-center justify-between text-xs font-bold text-gray-500">
                      <span>Ancaman Dicegah</span>
                      <Lock className="w-4 h-4 text-[#16A34A] dark:text-[#6BCB37]" />
                    </div>
                    <div className="text-lg font-black text-[#143D28] dark:text-white mt-1">
                      {securityMetrics?.blockedThreatsCount || 0}
                    </div>
                    <p className="text-[10px] text-gray-400 mt-0.5">Rate limit & AI Risk Blocking</p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330]">
                    <div className="flex items-center justify-between text-xs font-bold text-gray-500">
                      <span>Akun Terkunci (Lockout)</span>
                      <Users className="w-4 h-4 text-amber-500" />
                    </div>
                    <div className="text-lg font-black text-amber-600 dark:text-amber-400 mt-1">
                      {securityMetrics?.activeLockedAccounts || 0} Akun
                    </div>
                    <p className="text-[10px] text-gray-400 mt-0.5">Proteksi Brute-Force aktif</p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330]">
                    <div className="flex items-center justify-between text-xs font-bold text-gray-500">
                      <span>IP Suspicious Watch</span>
                      <Globe className="w-4 h-4 text-purple-500" />
                    </div>
                    <div className="text-lg font-black text-purple-600 dark:text-purple-400 mt-1">
                      {securityMetrics?.activeSuspiciousIPs || 0} IP
                    </div>
                    <p className="text-[10px] text-gray-400 mt-0.5">Exponential backoff & challenge</p>
                  </div>
                </div>
              </div>

              {/* Incidents & Threat Telemetry Feed */}
              <div className="p-5 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-extrabold text-[#143D28] dark:text-white flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                    <span>Daftar Insiden Keamanan & Anomali AI</span>
                  </h3>
                  <button
                    type="button"
                    onClick={loadSecurityMetrics}
                    className="text-xs font-bold text-[#143D28] dark:text-[#6BCB37] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${securityLoading ? 'animate-spin' : ''}`} />
                    <span>Segarkan</span>
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-gray-100 dark:border-gray-800 text-gray-400 uppercase text-[10px] tracking-wider">
                        <th className="pb-3 font-bold">Waktu</th>
                        <th className="pb-3 font-bold">Tipe Insiden</th>
                        <th className="pb-3 font-bold">Tingkat Bahaya</th>
                        <th className="pb-3 font-bold">Target</th>
                        <th className="pb-3 font-bold">Rincian / Anomali</th>
                        <th className="pb-3 font-bold">Status</th>
                        <th className="pb-3 font-bold text-right">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                      {securityMetrics?.incidents?.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="py-8 text-center text-gray-400 text-xs">
                            <ShieldCheck className="w-8 h-8 text-[#6BCB37] mx-auto mb-1.5 opacity-80" />
                            <span>Tidak ada insiden keamanan aktif yang terdeteksi. Sistem berjalan normal.</span>
                          </td>
                        </tr>
                      ) : (
                        securityMetrics?.incidents?.map((inc: any) => (
                          <tr key={inc.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-800/30">
                            <td className="py-3 font-mono text-[11px] text-gray-400">
                              {new Date(inc.timestamp).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                            </td>
                            <td className="py-3">
                              <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-gray-100 dark:bg-[#163826] text-[#143D28] dark:text-[#6BCB37]">
                                {inc.type}
                              </span>
                            </td>
                            <td className="py-3">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  inc.severity === 'CRITICAL'
                                    ? 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300'
                                    : inc.severity === 'HIGH'
                                      ? 'bg-orange-100 text-orange-800 dark:bg-orange-950/60 dark:text-orange-300'
                                      : 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                                }`}
                              >
                                {inc.severity}
                              </span>
                            </td>
                            <td className="py-3 font-medium text-gray-700 dark:text-gray-200">
                              {inc.targetUser || inc.ipAddress || 'System'}
                            </td>
                            <td className="py-3 text-gray-600 dark:text-gray-300 max-w-xs">{inc.details}</td>
                            <td className="py-3">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  inc.status === 'RESOLVED'
                                    ? 'bg-[#EAF6EE] text-[#16A34A] dark:bg-[#163826] dark:text-[#6BCB37]'
                                    : 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                                }`}
                              >
                                {inc.status}
                              </span>
                            </td>
                            <td className="py-3 text-right">
                              {inc.status === 'ACTIVE' ? (
                                <button
                                  type="button"
                                  onClick={() => handleResolveIncident(inc.id)}
                                  className="px-2.5 py-1 rounded-lg bg-[#143D28] hover:bg-[#0E2C1D] text-[#6BCB37] text-[11px] font-bold shadow-xs cursor-pointer transition-colors"
                                >
                                  Mitigasi Selesai
                                </button>
                              ) : (
                                <span className="text-[11px] text-gray-400 font-medium">Termitigasi</span>
                              )}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 6: TICKET & CUSTOMER SUPPORT HELPDESK                 */}
          {/* ========================================================= */}
          {activeMenu === 'tickets' && (
            <AdminTicketsPanel
              key={`tickets-${ticketsRefreshKey}`}
              fetchWithAuth={fetchWithAuth}
              showToast={showToast}
            />
          )}
        </div>
      </main>

      {/* ============================================================= */}
      {/* MODAL 1: USER DETAIL DRAWER / POPUP                           */}
      {/* ============================================================= */}
      <AnimatePresence>
        {selectedUserDetail && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-2xl bg-white dark:bg-[#12281E] border border-[#D7EFE0] dark:border-[#1E4330] rounded-3xl p-6 shadow-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-4 border-b border-gray-100 dark:border-gray-800">
                <div className="flex items-center gap-3">
                  <img
                    src={selectedUserDetail.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                    alt={selectedUserDetail.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-[#6BCB37]"
                  />
                  <div>
                    <h3 className="text-base font-extrabold text-[#143D28] dark:text-white flex items-center gap-2">
                      <span>{selectedUserDetail.name}</span>
                      {selectedUserDetail.status === 'blocked' ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300">
                          DIBLOKIR
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#EAF6EE] text-[#16A34A] dark:bg-[#163826] dark:text-[#6BCB37]">
                          AKTIF
                        </span>
                      )}
                    </h3>
                    <p className="text-xs text-gray-500 font-mono">{selectedUserDetail.username} • {selectedUserDetail.id}</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedUserDetail(null)}
                  className="p-2 rounded-xl text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* User Overview Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-4">
                <div className="p-3 rounded-2xl bg-gray-50 dark:bg-[#0A1610] border border-gray-100 dark:border-gray-800">
                  <span className="text-[10px] text-gray-400 font-bold block">Saldo Akun</span>
                  <span className="text-sm font-black text-[#143D28] dark:text-[#6BCB37]">
                    Rp{(selectedUserDetail.balance || 0).toLocaleString('id-ID')}
                  </span>
                </div>
                <div className="p-3 rounded-2xl bg-gray-50 dark:bg-[#0A1610] border border-gray-100 dark:border-gray-800">
                  <span className="text-[10px] text-gray-400 font-bold block">Eco Points</span>
                  <span className="text-sm font-black text-[#16A34A] dark:text-[#A3E635]">
                    {selectedUserDetail.ecoPoints || 0} Poin
                  </span>
                </div>
                <div className="p-3 rounded-2xl bg-gray-50 dark:bg-[#0A1610] border border-gray-100 dark:border-gray-800">
                  <span className="text-[10px] text-gray-400 font-bold block">Tier Keanggotaan</span>
                  <span className="text-xs font-extrabold text-[#143D28] dark:text-white truncate block">
                    {selectedUserDetail.membershipTier || 'Eco Classic'}
                  </span>
                </div>
                <div className="p-3 rounded-2xl bg-gray-50 dark:bg-[#0A1610] border border-gray-100 dark:border-gray-800">
                  <span className="text-[10px] text-gray-400 font-bold block">Skor Keamanan</span>
                  <span className="text-xs font-black text-[#16A34A] dark:text-[#6BCB37]">
                    {selectedUserDetail.securityScore || 85}% Aman
                  </span>
                </div>
              </div>

              {/* Contact Details */}
              <div className="p-4 rounded-2xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-500">Nomor Telepon:</span>
                  <span className="font-bold text-[#143D28] dark:text-white">{selectedUserDetail.phone}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Alamat Email:</span>
                  <span className="font-bold text-[#143D28] dark:text-white">{selectedUserDetail.email}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Tanggal Terdaftar:</span>
                  <span className="font-bold text-[#143D28] dark:text-white">{selectedUserDetail.registeredAt}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Login Terakhir:</span>
                  <span className="font-bold text-[#143D28] dark:text-white">{selectedUserDetail.lastLogin || '-'}</span>
                </div>
                {selectedUserDetail.blockedReason && (
                  <div className="flex justify-between text-rose-700 dark:text-rose-400 font-bold pt-1 border-t border-rose-200 dark:border-rose-900">
                    <span>Alasan Blokir:</span>
                    <span>{selectedUserDetail.blockedReason}</span>
                  </div>
                )}
              </div>

              {/* Action Buttons in User Detail */}
              <div className="flex flex-wrap items-center justify-end gap-2 mt-5">
                <button
                  type="button"
                  onClick={() => handleRevokeSessions(selectedUserDetail.id, selectedUserDetail.name)}
                  className="px-3 py-2 rounded-xl bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-200 text-xs font-bold hover:bg-gray-200 transition-all cursor-pointer"
                >
                  Cabut Semua Sesi Aktif
                </button>

                <button
                  type="button"
                  onClick={() => {
                    openEditModal(selectedUserDetail);
                  }}
                  className="px-3 py-2 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border border-amber-300 text-xs font-bold hover:bg-amber-100 transition-all cursor-pointer"
                >
                  Edit Data & Saldo
                </button>

                {selectedUserDetail.status === 'blocked' ? (
                  <button
                    type="button"
                    onClick={() => {
                      setUnblockTargetUser(selectedUserDetail);
                    }}
                    className="px-4 py-2 rounded-xl bg-[#143D28] text-[#6BCB37] text-xs font-black hover:bg-[#0E2C1D] transition-all cursor-pointer"
                  >
                    Buka Blokir Akun
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setBlockTargetUser(selectedUserDetail);
                    }}
                    className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-black hover:bg-rose-700 transition-all cursor-pointer"
                  >
                    Blokir Akun Ini
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ============================================================= */}
      {/* MODAL 2: BLOCK USER REASON PROMPT                             */}
      {/* ============================================================= */}
      <AnimatePresence>
        {blockTargetUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-white dark:bg-[#12281E] border border-rose-200 dark:border-rose-900 rounded-3xl p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center gap-3 text-rose-600">
                <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950/60 flex items-center justify-center">
                  <ShieldAlert className="w-5 h-5 text-rose-600" />
                </div>
                <div>
                  <h3 className="text-base font-black text-rose-700 dark:text-rose-400">
                    Konfirmasi Pemblokiran Akun
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Akun: {blockTargetUser.name} ({blockTargetUser.username})
                  </p>
                </div>
              </div>

              <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                Pemblokiran akan <strong className="text-rose-600">seketika mencabut seluruh sesi login aktif</strong> dan mencegah pengguna masuk atau bertransaksi di aplikasi TO PAY.
              </p>

              <div>
                <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1.5">
                  Alasan Pemblokiran (Audit Trail):
                </label>
                <textarea
                  rows={3}
                  value={blockReasonInput}
                  onChange={(e) => setBlockReasonInput(e.target.value)}
                  placeholder="Masukkan alasan pemblokiran..."
                  className="w-full p-3 rounded-2xl text-xs bg-gray-50 dark:bg-[#0A1610] border border-gray-200 dark:border-gray-700 text-[#0F2D1F] dark:text-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setBlockTargetUser(null)}
                  className="px-4 py-2.5 rounded-xl bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 text-xs font-bold hover:bg-gray-200 transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleConfirmBlock}
                  className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black shadow-md transition-colors cursor-pointer"
                >
                  Ya, Blokir Akun Sekarang
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ============================================================= */}
      {/* MODAL 3: UNBLOCK USER CONFIRMATION                            */}
      {/* ============================================================= */}
      <AnimatePresence>
        {unblockTargetUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-white dark:bg-[#12281E] border border-[#D7EFE0] dark:border-[#1E4330] rounded-3xl p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#EAF6EE] dark:bg-[#163826] flex items-center justify-center">
                  <Unlock className="w-5 h-5 text-[#16A34A] dark:text-[#6BCB37]" />
                </div>
                <div>
                  <h3 className="text-base font-black text-[#143D28] dark:text-white">
                    Buka Blokir Akun Pengguna
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Akun: {unblockTargetUser.name} ({unblockTargetUser.username})
                  </p>
                </div>
              </div>

              <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                Pengguna akan diizinkan login kembali dan melakukan transaksi normal menggunakan saldo akunnya.
              </p>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setUnblockTargetUser(null)}
                  className="px-4 py-2.5 rounded-xl bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 text-xs font-bold hover:bg-gray-200 transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleConfirmUnblock}
                  className="px-4 py-2.5 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-[#6BCB37] text-xs font-black shadow-md transition-colors cursor-pointer"
                >
                  Buka Blokir Sekarang
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ============================================================= */}
      {/* MODAL 4: EDIT USER & BALANCE ADJUSTMENT FORM                  */}
      {/* ============================================================= */}
      <AnimatePresence>
        {editTargetUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-lg bg-white dark:bg-[#12281E] border border-[#D7EFE0] dark:border-[#1E4330] rounded-3xl p-6 shadow-2xl max-h-[90vh] overflow-y-auto space-y-4"
            >
              <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800">
                <h3 className="text-base font-extrabold text-[#143D28] dark:text-white flex items-center gap-2">
                  <Edit3 className="w-4 h-4 text-[#6BCB37]" />
                  <span>Edit Data Akun & Penyesuaian Saldo</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setEditTargetUser(null)}
                  className="p-1 text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveUserEdit} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1">
                    Nama Lengkap
                  </label>
                  <input
                    type="text"
                    required
                    value={editFormData.name}
                    onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl text-xs bg-gray-50 dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] text-[#0F2D1F] dark:text-white focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1">
                      Nomor HP
                    </label>
                    <input
                      type="text"
                      required
                      value={editFormData.phone}
                      onChange={(e) => setEditFormData({ ...editFormData, phone: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl text-xs bg-gray-50 dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] text-[#0F2D1F] dark:text-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      required
                      value={editFormData.email}
                      onChange={(e) => setEditFormData({ ...editFormData, email: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl text-xs bg-gray-50 dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] text-[#0F2D1F] dark:text-white focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1">
                    Tier Keanggotaan
                  </label>
                  <select
                    value={editFormData.membershipTier}
                    onChange={(e) => setEditFormData({ ...editFormData, membershipTier: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl text-xs bg-gray-50 dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] text-[#0F2D1F] dark:text-white focus:outline-none"
                  >
                    <option value="Eco Classic Member">Eco Classic Member</option>
                    <option value="Eco Gold Member">Eco Gold Member</option>
                    <option value="Eco Platinum Member">Eco Platinum Member</option>
                  </select>
                </div>

                {/* Balance Adjustment Section */}
                <div className="p-3.5 rounded-2xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] space-y-2">
                  <div className="flex items-center justify-between text-xs font-extrabold text-[#143D28] dark:text-[#6BCB37]">
                    <span>Penyesuaian Saldo Manual (Opsional)</span>
                    <span>Saldo Saat Ini: Rp{(editTargetUser.balance || 0).toLocaleString('id-ID')}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-gray-500 font-bold block mb-1">Nominal Tambah/Kurang (Rp)</label>
                      <input
                        type="number"
                        placeholder="Contoh: 50000 atau -20000"
                        value={editFormData.balanceAdjustment || ''}
                        onChange={(e) =>
                          setEditFormData({ ...editFormData, balanceAdjustment: parseInt(e.target.value) || 0 })
                        }
                        className="w-full px-3 py-2 rounded-xl text-xs bg-white dark:bg-[#12281E] border border-gray-300 dark:border-gray-700 text-[#0F2D1F] dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-gray-500 font-bold block mb-1">Alasan Penyesuaian Saldo</label>
                      <input
                        type="text"
                        placeholder="cth: Kompensasi gangguan layanan"
                        value={editFormData.adjustmentReason}
                        onChange={(e) => setEditFormData({ ...editFormData, adjustmentReason: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl text-xs bg-white dark:bg-[#12281E] border border-gray-300 dark:border-gray-700 text-[#0F2D1F] dark:text-white"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditTargetUser(null)}
                    className="px-4 py-2 rounded-xl bg-gray-100 dark:bg-gray-800 text-gray-600 text-xs font-bold hover:bg-gray-200"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-[#143D28] text-white text-xs font-black hover:bg-[#0E2C1D]"
                  >
                    Simpan Perubahan
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ============================================================= */}
      {/* MODAL 5: EMERGENCY SYSTEM LOCKDOWN PROMPT                     */}
      {/* ============================================================= */}
      <AnimatePresence>
        {lockdownPromptOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-white dark:bg-[#12281E] border border-rose-200 dark:border-rose-900/50 rounded-3xl p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-black text-[#143D28] dark:text-white">
                    {securityMetrics?.isSystemLockdownActive ? 'Nonaktifkan Mode Lockdown?' : 'Aktifkan Emergency Lockdown?'}
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Saklar proteksi sistem instan & isolasi ancaman
                  </p>
                </div>
              </div>

              <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                {securityMetrics?.isSystemLockdownActive
                  ? 'Setelah dinonaktifkan, pengguna akan dapat kembali melakukan transaksi QRIS, transfer, dan topup secara normal.'
                  : 'PERINGATAN: Mengaktifkan mode lockdown akan langsung memblokir seluruh transaksi QRIS dan perpindahan dana di seluruh sistem secara instan hingga dinonaktifkan kembali.'}
              </p>

              <div>
                <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1">
                  Alasan / Catatan Audit
                </label>
                <input
                  type="text"
                  placeholder="cth: Investigasi anomali transaksi berulang"
                  value={lockdownReason}
                  onChange={(e) => setLockdownReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-gray-50 dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] text-[#0F2D1F] dark:text-white focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setLockdownPromptOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 text-xs font-bold hover:bg-gray-200 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleToggleLockdown}
                  disabled={lockdownSubmitting}
                  className={`px-4 py-2.5 rounded-xl text-xs font-black text-white shadow-md cursor-pointer transition-colors flex items-center gap-1.5 ${
                    securityMetrics?.isSystemLockdownActive
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : 'bg-rose-600 hover:bg-rose-700'
                  }`}
                >
                  {lockdownSubmitting ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : securityMetrics?.isSystemLockdownActive ? (
                    'Lepas Lockdown'
                  ) : (
                    'Aktifkan Lockdown Sekarang'
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ============================================================= */}
      {/* MODAL 6: PURGE ALL ACTIVE SESSIONS PROMPT                     */}
      {/* ============================================================= */}
      <AnimatePresence>
        {purgeSessionsPromptOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-white dark:bg-[#12281E] border border-gray-200 dark:border-[#1E4330] rounded-3xl p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center shrink-0">
                  <RefreshCw className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-black text-[#143D28] dark:text-white">
                    Cabut Seluruh Sesi Aktif di Platform?
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Aksi darurat reset otorisasi sesi
                  </p>
                </div>
              </div>

              <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                Seluruh pengguna (kecuali sesi super admin yang sedang aktif ini) akan dipaksa keluar dan harus melakukan login ulang dengan verifikasi kredensial mereka.
              </p>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPurgeSessionsPromptOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 text-xs font-bold hover:bg-gray-200 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handlePurgeSessions}
                  disabled={purgeSubmitting}
                  className="px-4 py-2.5 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-[#6BCB37] text-xs font-black shadow-md cursor-pointer transition-colors flex items-center gap-1.5"
                >
                  {purgeSubmitting ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    'Ya, Cabut Seluruh Sesi'
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
