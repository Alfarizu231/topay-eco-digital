import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Search,
  ChevronDown,
  ChevronUp,
  MessageCircle,
  Mail,
  Phone,
  Send,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Sparkles,
  Headphones,
  Ticket,
  Upload,
  Trash2,
  ArrowLeft,
  Clock,
  Hash,
  Tag,
  MessageSquare,
  Image as ImageIcon,
  RefreshCw,
} from 'lucide-react';
import {
  FAQItem,
  ComplaintTicket,
  TicketPriority,
  Transaction,
} from '../types';
import { PUBLIC_CONTACT } from '../config/publicContact';
import { TicketPriorityBadge, TicketStatusBadge } from './TicketBadges';

interface HelpCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDarkMode?: boolean;
  transactions?: Transaction[];
}

const TICKET_CATEGORIES = [
  'Top Up',
  'QRIS',
  'Transfer',
  'E-Wallet',
  'Tagihan & Pulsa',
  'Akun & Keamanan',
  'Lainnya',
];

export const HelpCenterModal: React.FC<HelpCenterModalProps> = ({
  isOpen,
  onClose,
  isDarkMode = false,
  transactions = [],
}) => {
  const [activeTab, setActiveTab] = useState<'faq' | 'cs' | 'tickets'>('faq');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [faqs, setFaqs] = useState<FAQItem[]>([]);
  const [expandedFaqId, setExpandedFaqId] = useState<string | null>('faq-1');
  const [isLoadingFaqs, setIsLoadingFaqs] = useState(true);

  // Create Ticket ("Buat Pengaduan") Form State
  const [ticketCategory, setTicketCategory] = useState('Top Up');
  const [ticketOrderId, setTicketOrderId] = useState('');
  const [ticketPriority, setTicketPriority] = useState<TicketPriority>('Sedang');
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketDescription, setTicketDescription] = useState('');
  const [ticketAttachment, setTicketAttachment] = useState<string | null>(null);
  const [ticketAttachmentName, setTicketAttachmentName] = useState<string>('');
  const [isSubmittingTicket, setIsSubmittingTicket] = useState(false);
  const [createdTicketSuccess, setCreatedTicketSuccess] = useState<ComplaintTicket | null>(null);
  const [ticketFormError, setTicketFormError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // My Tickets ("Tiket Saya") & Live Chat State
  const [myTickets, setMyTickets] = useState<ComplaintTicket[]>([]);
  const [loadingTickets, setLoadingTickets] = useState(false);
  const [ticketsError, setTicketsError] = useState<string | null>(null);
  const [selectedTicket, setSelectedTicket] = useState<ComplaintTicket | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [userReplyText, setUserReplyText] = useState('');
  const [sendingReply, setSendingReply] = useState(false);

  const getAuthHeaders = useCallback((): Record<string, string> => {
    const token =
      localStorage.getItem('topay_auth_token') ||
      sessionStorage.getItem('topay_auth_token');
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  }, []);

  const loadMyTickets = useCallback(async () => {
    setLoadingTickets(true);
    setTicketsError(null);
    try {
      const res = await fetch('/api/tickets', {
        headers: getAuthHeaders(),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setMyTickets(data.tickets || []);
      } else {
        setTicketsError(data.error || 'Gagal memuat riwayat tiket.');
      }
    } catch (err) {
      console.error('Error loading user tickets:', err);
      setTicketsError('Kendala jaringan saat memuat tiket Anda.');
    } finally {
      setLoadingTickets(false);
    }
  }, [getAuthHeaders]);

  const loadTicketDetail = useCallback(
    async (ticketId: string) => {
      setLoadingDetail(true);
      try {
        const res = await fetch(`/api/tickets/${encodeURIComponent(ticketId)}`, {
          headers: getAuthHeaders(),
        });
        const data = await res.json();
        if (res.ok && data.success && data.ticket) {
          setSelectedTicket(data.ticket);
        } else {
          setTicketsError(data.error || 'Gagal memuat detail tiket.');
        }
      } catch (err) {
        console.error('Error loading ticket detail:', err);
        setTicketsError('Gagal terhubung ke server untuk memuat percakapan.');
      } finally {
        setLoadingDetail(false);
      }
    },
    [getAuthHeaders]
  );

  useEffect(() => {
    if (isOpen) {
      setIsLoadingFaqs(true);
      fetch('/api/help/faq')
        .then((res) => res.json())
        .then((data) => {
          if (data.success && Array.isArray(data.faqs)) {
            setFaqs(data.faqs);
          }
        })
        .catch((err) => console.error('Error fetching FAQs:', err))
        .finally(() => setIsLoadingFaqs(false));

      loadMyTickets();
    }
  }, [isOpen, loadMyTickets]);

  useEffect(() => {
    if (isOpen && activeTab === 'tickets') {
      loadMyTickets();
    }
  }, [isOpen, activeTab, loadMyTickets]);

  if (!isOpen) return null;

  const categories = ['Semua', 'Akun', 'Transaksi', 'QRIS', 'Top Up', 'Transfer', 'Keamanan'];

  const filteredFaqs = faqs.filter((item) => {
    const matchesCat = selectedCategory === 'Semua' || item.category === selectedCategory;
    const matchesSearch =
      item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setTicketFormError('Hanya file gambar (PNG, JPG, JPEG, WebP) yang diperbolehkan sebagai bukti.');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setTicketFormError('Ukuran file bukti maksimal 2 MB.');
      return;
    }

    setTicketFormError(null);
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setTicketAttachment(reader.result);
        setTicketAttachmentName(file.name);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleQuickPickTransaction = (txId: string) => {
    setTicketOrderId(txId);
    const found = transactions.find((t) => t.id === txId);
    if (found) {
      if (found.type === 'topup') setTicketCategory('Top Up');
      else if (found.type === 'qris') setTicketCategory('QRIS');
      else if (found.type === 'transfer') setTicketCategory('Transfer');
      else if (found.type === 'ewallet') setTicketCategory('E-Wallet');
      else if (found.type === 'bill') setTicketCategory('Tagihan & Pulsa');
    }
  };

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    setTicketFormError(null);
    setCreatedTicketSuccess(null);

    if (!ticketSubject.trim() || !ticketDescription.trim()) {
      setTicketFormError('Subjek pengaduan dan deskripsi kendala wajib diisi.');
      return;
    }

    setIsSubmittingTicket(true);
    try {
      const res = await fetch('/api/tickets', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          category: ticketCategory,
          order_id: ticketOrderId.trim() || undefined,
          priority: ticketPriority,
          subject: ticketSubject.trim(),
          description: ticketDescription.trim(),
          attachment_url: ticketAttachment || undefined,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success && data.ticket) {
        setCreatedTicketSuccess(data.ticket);
        setTicketSubject('');
        setTicketDescription('');
        setTicketOrderId('');
        setTicketAttachment(null);
        setTicketAttachmentName('');
        if (fileInputRef.current) fileInputRef.current.value = '';
        await loadMyTickets();
      } else {
        setTicketFormError(data.error || 'Gagal membuat tiket pengaduan.');
      }
    } catch (err) {
      console.error('Create ticket error:', err);
      setTicketFormError('Terjadi kendala jaringan saat mengirim pengaduan.');
    } finally {
      setIsSubmittingTicket(false);
    }
  };

  const handleUserReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !userReplyText.trim()) return;

    setSendingReply(true);
    setTicketsError(null);
    try {
      const res = await fetch(`/api/tickets/${encodeURIComponent(selectedTicket.id)}/reply`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ message: userReplyText.trim() }),
      });
      const data = await res.json();
      if (res.ok && data.success && data.ticket) {
        setSelectedTicket(data.ticket);
        setUserReplyText('');
        await loadMyTickets();
      } else {
        setTicketsError(data.error || 'Gagal mengirim balasan.');
      }
    } catch (err) {
      console.error('User reply error:', err);
      setTicketsError('Terjadi kendala jaringan saat mengirim balasan.');
    } finally {
      setSendingReply(false);
    }
  };

  const openTicketCount = myTickets.filter((t) => t.status !== 'Selesai').length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/65 backdrop-blur-xs">
      <motion.div
        initial={{ scale: 0.94, opacity: 0, y: 15 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.94, opacity: 0, y: 15 }}
        className={`w-full max-w-xl rounded-3xl p-4 sm:p-6 shadow-2xl border relative overflow-hidden flex flex-col max-h-[92vh] ${
          isDarkMode
            ? 'bg-[#12281E] border-[#1E4330] text-white'
            : 'bg-white border-[#E2ECE5] text-[#0F2D1F]'
        }`}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 dark:hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 pb-3 border-b border-gray-100 dark:border-gray-800 pr-8">
          <div className="w-11 h-11 rounded-2xl bg-[#EAF6EE] dark:bg-[#1A3828] text-[#143D28] dark:text-[#6BCB37] flex items-center justify-center shrink-0">
            <Headphones className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-[#143D28] dark:text-white">
              Pusat Bantuan & Tiket CS 24/7
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              FAQ, buat pengaduan ber-ID Order, dan pantau balasan CS secara real-time
            </p>
          </div>
        </div>

        {/* 3-Tab Switcher */}
        <div className="grid grid-cols-3 bg-gray-100 dark:bg-[#0A1610] p-1 rounded-xl mt-3 text-[11px] sm:text-xs font-bold gap-1">
          <button
            type="button"
            onClick={() => setActiveTab('faq')}
            className={`py-2 px-2 rounded-lg transition-all cursor-pointer text-center ${
              activeTab === 'faq'
                ? 'bg-white dark:bg-[#1E4330] text-[#143D28] dark:text-[#6BCB37] shadow-xs'
                : 'text-gray-500 hover:text-gray-800 dark:hover:text-white'
            }`}
          >
            FAQ
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('cs')}
            className={`py-2 px-2 rounded-lg transition-all cursor-pointer text-center ${
              activeTab === 'cs'
                ? 'bg-white dark:bg-[#1E4330] text-[#143D28] dark:text-[#6BCB37] shadow-xs'
                : 'text-gray-500 hover:text-gray-800 dark:hover:text-white'
            }`}
          >
            Buat Pengaduan
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('tickets');
              setSelectedTicket(null);
            }}
            className={`py-2 px-2 rounded-lg transition-all cursor-pointer text-center flex items-center justify-center gap-1.5 ${
              activeTab === 'tickets'
                ? 'bg-white dark:bg-[#1E4330] text-[#143D28] dark:text-[#6BCB37] shadow-xs'
                : 'text-gray-500 hover:text-gray-800 dark:hover:text-white'
            }`}
          >
            <span>Tiket Saya</span>
            {myTickets.length > 0 && (
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                  openTicketCount > 0
                    ? 'bg-[#6BCB37] text-[#0F2D1F]'
                    : 'bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-200'
                }`}
              >
                {myTickets.length}
              </span>
            )}
          </button>
        </div>

        {/* ============================================================ */}
        {/* TAB 1: FAQ                                                   */}
        {/* ============================================================ */}
        {activeTab === 'faq' && (
          <div className="flex-1 overflow-y-auto py-3 space-y-3">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-3 text-gray-400" />
              <input
                type="text"
                placeholder="Cari topik bantuan (cth: QRIS, PIN, Top Up)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`w-full pl-9 pr-3.5 py-2.5 rounded-xl border text-xs outline-none transition-all ${
                  isDarkMode
                    ? 'bg-[#0A1610] border-[#1E4330] text-white focus:border-[#6BCB37]'
                    : 'bg-white border-[#D7EFE0] text-[#0F2D1F] focus:border-[#143D28]'
                }`}
              />
            </div>

            <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {categories.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 rounded-full text-[11px] font-bold whitespace-nowrap transition-all cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-[#143D28] text-white dark:bg-[#6BCB37] dark:text-[#0F2D1F]'
                      : 'bg-gray-100 dark:bg-[#183827] text-gray-600 dark:text-gray-300 hover:bg-gray-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {isLoadingFaqs ? (
              <div className="py-12 flex flex-col items-center justify-center text-gray-400 gap-2">
                <Loader2 className="w-6 h-6 animate-spin text-[#6BCB37]" />
                <span className="text-xs">Memuat daftar bantuan...</span>
              </div>
            ) : filteredFaqs.length === 0 ? (
              <div className="py-12 text-center">
                <p className="text-xs text-gray-400">
                  Tidak ada artikel yang cocok dengan "{searchQuery}".
                </p>
                <button
                  type="button"
                  onClick={() => setActiveTab('cs')}
                  className="mt-2 text-xs font-bold text-[#143D28] dark:text-[#6BCB37] hover:underline cursor-pointer"
                >
                  Buat Tiket Pengaduan ke CS TO PAY →
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {filteredFaqs.map((faq) => {
                  const isExpanded = expandedFaqId === faq.id;
                  return (
                    <div
                      key={faq.id}
                      className={`rounded-2xl border transition-all overflow-hidden ${
                        isDarkMode
                          ? 'bg-[#0A1610] border-[#1E4330]'
                          : 'bg-white border-[#E2ECE5]'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => setExpandedFaqId(isExpanded ? null : faq.id)}
                        className="w-full p-3.5 text-left flex items-center justify-between gap-2.5 cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#EAF6EE] dark:bg-[#1A3828] text-[#143D28] dark:text-[#6BCB37]">
                            {faq.category}
                          </span>
                          <span className="text-xs font-bold text-[#143D28] dark:text-white">
                            {faq.question}
                          </span>
                        </div>
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 text-[#6BCB37] shrink-0" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-gray-400 shrink-0" />
                        )}
                      </button>

                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="px-3.5 pb-3.5 text-xs text-gray-600 dark:text-gray-300 leading-relaxed border-t border-gray-100 dark:border-gray-800/60 pt-2.5 bg-[#F9FCFA] dark:bg-[#12281E]/40"
                          >
                            {faq.answer}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ============================================================ */}
        {/* TAB 2: BUAT PENGADUAN & KONTAK RESMI                         */}
        {/* ============================================================ */}
        {activeTab === 'cs' && (
          <div className="flex-1 overflow-y-auto py-3 space-y-3.5">
            {/* Quick Contact Buttons */}
            <div className="grid grid-cols-2 gap-2">
              <a
                href={PUBLIC_CONTACT.whatsappHref}
                target="_blank"
                rel="noreferrer"
                className="p-2.5 rounded-2xl bg-emerald-50 dark:bg-[#1A3828] border border-emerald-200 dark:border-[#224E38] flex items-center gap-2.5 hover:bg-emerald-100 transition-colors"
              >
                <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <MessageCircle className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-emerald-900 dark:text-emerald-200">WhatsApp CS</div>
                  <div className="text-[10px] text-emerald-700 dark:text-[#6BCB37] truncate">
                    {PUBLIC_CONTACT.phoneDisplay}
                  </div>
                </div>
              </a>

              <a
                href={PUBLIC_CONTACT.mailtoSupportHref}
                className="p-2.5 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/40 flex items-center gap-2.5 hover:bg-blue-100 transition-colors"
              >
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
                  <Mail className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-blue-900 dark:text-blue-200">Email Resmi</div>
                  <div className="text-[10px] text-blue-700 dark:text-blue-300 truncate">
                    {PUBLIC_CONTACT.email}
                  </div>
                </div>
              </a>
            </div>

            <a
              href={PUBLIC_CONTACT.phoneHref}
              className={`w-full px-3.5 py-2 rounded-xl border flex items-center justify-between text-xs transition-colors ${
                isDarkMode
                  ? 'bg-[#0A1610] border-[#1E4330] text-gray-200 hover:border-[#6BCB37]'
                  : 'bg-[#F8FAF8] border-[#E2ECE5] text-[#143D28] hover:border-[#143D28]'
              }`}
            >
              <span className="flex items-center gap-2 font-bold">
                <Phone className="w-3.5 h-3.5 text-[#6BCB37]" />
                <span>Telepon Layanan Pelanggan 24/7</span>
              </span>
              <span className="font-mono font-bold text-[#143D28] dark:text-[#6BCB37]">
                {PUBLIC_CONTACT.phoneDisplay}
              </span>
            </a>

            {/* Formal Ticket Submission Form */}
            <form
              onSubmit={handleCreateTicket}
              className={`p-4 rounded-2xl border space-y-3 ${
                isDarkMode
                  ? 'bg-[#0A1610]/70 border-[#1E4330]'
                  : 'bg-[#FAFCFA] border-[#DCECE1]'
              }`}
            >
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-extrabold text-[#143D28] dark:text-white flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#6BCB37]" />
                  <span>Formulir Pengaduan Kendala (Tiket CS)</span>
                </h3>
                <span className="text-[10px] font-bold text-emerald-600 dark:text-[#6BCB37]">
                  SLA &lt; 30 Menit
                </span>
              </div>

              <AnimatePresence>
                {ticketFormError && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2"
                  >
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{ticketFormError}</span>
                  </motion.div>
                )}

                {createdTicketSuccess && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="p-3 rounded-xl bg-emerald-50 dark:bg-[#1A3828] border border-emerald-200 dark:border-[#2C6146] text-xs text-emerald-800 dark:text-[#6BCB37] space-y-2"
                  >
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-extrabold">
                          Tiket {createdTicketSuccess.ticket_code} berhasil dibuat!
                        </p>
                        <p className="text-[11px] opacity-90 mt-0.5">
                          ID Order: <span className="font-mono font-bold">{createdTicketSuccess.order_id}</span> • Status:{' '}
                          <span className="font-bold">{createdTicketSuccess.status}</span>
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setActiveTab('tickets');
                        loadTicketDetail(createdTicketSuccess.id);
                      }}
                      className="w-full py-1.5 px-3 rounded-lg bg-[#143D28] text-white text-[11px] font-bold hover:bg-[#0E2C1D] transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-[#6BCB37]" />
                      <span>Lihat &amp; Pantau Percakapan Tiket →</span>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Kategori & Prioritas */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                    Kategori Kendala *
                  </label>
                  <select
                    value={ticketCategory}
                    onChange={(e) => setTicketCategory(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs outline-none ${
                      isDarkMode
                        ? 'bg-[#0A1610] border-[#1E4330] text-white focus:border-[#6BCB37]'
                        : 'bg-white border-[#D7EFE0] focus:border-[#143D28]'
                    }`}
                  >
                    {TICKET_CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                    Tingkat Prioritas
                  </label>
                  <select
                    value={ticketPriority}
                    onChange={(e) => setTicketPriority(e.target.value as TicketPriority)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs outline-none ${
                      isDarkMode
                        ? 'bg-[#0A1610] border-[#1E4330] text-white focus:border-[#6BCB37]'
                        : 'bg-white border-[#D7EFE0] focus:border-[#143D28]'
                    }`}
                  >
                    <option value="Rendah">Rendah (Pertanyaan Umum)</option>
                    <option value="Sedang">Sedang (Kendala Layanan)</option>
                    <option value="Tinggi">Tinggi (Dana Terpotong / Mendesak)</option>
                  </select>
                </div>
              </div>

              {/* ID Order / Transaksi + Quick Pick */}
              <div className="space-y-1.5">
                <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300">
                  ID Order / Referensi Transaksi
                </label>
                <div className="relative">
                  <Hash className="w-3.5 h-3.5 absolute left-3 top-2.5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Contoh: TX-17104829201 (Kosongkan jika kendala non-transaksi)"
                    value={ticketOrderId}
                    onChange={(e) => setTicketOrderId(e.target.value)}
                    className={`w-full pl-8 pr-3 py-2 rounded-xl border text-xs font-mono outline-none ${
                      isDarkMode
                        ? 'bg-[#0A1610] border-[#1E4330] text-white focus:border-[#6BCB37]'
                        : 'bg-white border-[#D7EFE0] focus:border-[#143D28]'
                    }`}
                  />
                </div>
                {transactions.length > 0 && (
                  <select
                    value=""
                    onChange={(e) => {
                      if (e.target.value) handleQuickPickTransaction(e.target.value);
                    }}
                    className={`w-full px-3 py-1.5 rounded-lg border text-[11px] outline-none ${
                      isDarkMode
                        ? 'bg-[#12281E] border-[#1E4330] text-emerald-300'
                        : 'bg-[#F0FAF3] border-[#D7EFE0] text-[#143D28]'
                    }`}
                  >
                    <option value="">-- Atau pilih cepat dari riwayat transaksi terakhir Anda --</option>
                    {transactions.slice(0, 10).map((tx) => (
                      <option key={tx.id} value={tx.id}>
                        {tx.id} • {tx.title} (Rp{Math.abs(tx.amount).toLocaleString('id-ID')})
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {/* Subjek */}
              <div>
                <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                  Subjek Pengaduan *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Top Up BCA Virtual Account belum masuk ke saldo"
                  value={ticketSubject}
                  onChange={(e) => setTicketSubject(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl border text-xs outline-none ${
                    isDarkMode
                      ? 'bg-[#0A1610] border-[#1E4330] text-white focus:border-[#6BCB37]'
                      : 'bg-white border-[#D7EFE0] focus:border-[#143D28]'
                  }`}
                />
              </div>

              {/* Deskripsi */}
              <div>
                <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                  Deskripsi Detail Kendala *
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="Jelaskan kronologi lengkap, waktu kejadian, dan nominal transaksi..."
                  value={ticketDescription}
                  onChange={(e) => setTicketDescription(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl border text-xs outline-none ${
                    isDarkMode
                      ? 'bg-[#0A1610] border-[#1E4330] text-white focus:border-[#6BCB37]'
                      : 'bg-white border-[#D7EFE0] focus:border-[#143D28]'
                  }`}
                />
              </div>

              {/* Upload Bukti (Opsional) */}
              <div>
                <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                  Upload Bukti Screenshot (Opsional, Maks 2MB)
                </label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                {!ticketAttachment ? (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className={`w-full py-2.5 px-3 rounded-xl border border-dashed text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                      isDarkMode
                        ? 'border-[#2B5940] text-gray-300 hover:border-[#6BCB37] hover:bg-[#12281E]'
                        : 'border-[#BBDCC7] text-gray-600 hover:border-[#143D28] hover:bg-[#F0FAF3]'
                    }`}
                  >
                    <Upload className="w-4 h-4 text-[#6BCB37]" />
                    <span>Pilih Foto Struk / Screenshot Kendala</span>
                  </button>
                ) : (
                  <div
                    className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 ${
                      isDarkMode
                        ? 'bg-[#12281E] border-[#1E4330]'
                        : 'bg-white border-[#D7EFE0]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={ticketAttachment}
                        alt="Preview bukti"
                        className="w-10 h-10 rounded-lg object-cover border border-gray-200 dark:border-gray-700 shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-bold truncate">{ticketAttachmentName || 'Bukti Terlampir'}</p>
                        <p className="text-[10px] text-emerald-600 dark:text-[#6BCB37]">Siap diunggah bersama tiket</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setTicketAttachment(null);
                        setTicketAttachmentName('');
                        if (fileInputRef.current) fileInputRef.current.value = '';
                      }}
                      className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                      title="Hapus bukti"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              <button
                type="submit"
                disabled={isSubmittingTicket}
                className="w-full py-2.5 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white text-xs font-bold shadow-md transition-colors cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSubmittingTicket ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-[#6BCB37]" />
                    <span>Mengirim Pengaduan...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5 text-[#6BCB37]" />
                    <span>Kirim Tiket Pengaduan</span>
                  </>
                )}
              </button>
            </form>
          </div>
        )}

        {/* ============================================================ */}
        {/* TAB 3: TIKET SAYA (RIWAYAT + LIVE CHAT THREAD)               */}
        {/* ============================================================ */}
        {activeTab === 'tickets' && (
          <div className="flex-1 overflow-y-auto py-3 flex flex-col min-h-0">
            {ticketsError && (
              <div className="mb-3 p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{ticketsError}</span>
              </div>
            )}

            {/* TICKET DETAIL & LIVE CHAT VIEW */}
            {selectedTicket ? (
              <div className="flex flex-col flex-1 min-h-0 space-y-3">
                {/* Back & Refresh Header */}
                <div className="flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setSelectedTicket(null)}
                    className="flex items-center gap-1.5 text-xs font-bold text-[#143D28] dark:text-[#6BCB37] hover:underline cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Kembali ke Daftar Tiket</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => loadTicketDetail(selectedTicket.id)}
                    disabled={loadingDetail}
                    className="flex items-center gap-1 text-[11px] font-bold text-gray-500 hover:text-[#143D28] dark:hover:text-[#6BCB37] cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loadingDetail ? 'animate-spin' : ''}`} />
                    <span>Refresh Chat</span>
                  </button>
                </div>

                {/* Ticket Meta Card */}
                <div
                  className={`p-3.5 rounded-2xl border space-y-2 ${
                    isDarkMode
                      ? 'bg-[#0A1610] border-[#1E4330]'
                      : 'bg-[#F8FAF8] border-[#DCECE1]'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-mono text-xs font-extrabold text-[#143D28] dark:text-[#6BCB37]">
                      {selectedTicket.ticket_code}
                    </span>
                    <div className="flex items-center gap-1.5">
                      <TicketPriorityBadge priority={selectedTicket.priority} />
                      <TicketStatusBadge status={selectedTicket.status} />
                    </div>
                  </div>

                  <h4 className="text-sm font-extrabold text-[#143D28] dark:text-white leading-snug">
                    {selectedTicket.subject}
                  </h4>

                  <div className="flex flex-wrap items-center gap-2 text-[11px]">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-gray-100 dark:bg-[#163826] font-bold">
                      <Tag className="w-3 h-3 text-[#6BCB37]" />
                      {selectedTicket.category}
                    </span>
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-100/70 dark:bg-emerald-950/60 text-emerald-900 dark:text-[#6BCB37] font-mono font-bold">
                      <Hash className="w-3 h-3" />
                      Order: {selectedTicket.order_id}
                    </span>
                  </div>

                  <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed pt-1 border-t border-gray-200/70 dark:border-gray-800">
                    {selectedTicket.description}
                  </p>

                  {selectedTicket.attachment_url && (
                    <div className="pt-1">
                      <div className="text-[10px] font-bold text-gray-400 flex items-center gap-1 mb-1">
                        <ImageIcon className="w-3 h-3" />
                        <span>Bukti Terlampir:</span>
                      </div>
                      <img
                        src={selectedTicket.attachment_url}
                        alt="Bukti pengaduan"
                        className="max-h-40 rounded-xl border border-gray-200 dark:border-gray-700 object-contain"
                      />
                    </div>
                  )}
                </div>

                {/* Live Chat Messages */}
                <div
                  className={`flex-1 overflow-y-auto p-3 rounded-2xl border space-y-2.5 min-h-[160px] max-h-[260px] ${
                    isDarkMode
                      ? 'bg-[#08120D] border-[#1E4330]'
                      : 'bg-gray-50 border-gray-200'
                  }`}
                >
                  {loadingDetail && (!selectedTicket.replies || selectedTicket.replies.length === 0) ? (
                    <div className="py-8 flex justify-center">
                      <Loader2 className="w-5 h-5 animate-spin text-[#6BCB37]" />
                    </div>
                  ) : !selectedTicket.replies || selectedTicket.replies.length === 0 ? (
                    <div className="py-8 text-center text-xs text-gray-400">
                      Belum ada balasan dari Customer Service. Anda dapat menambahkan keterangan tambahan di bawah.
                    </div>
                  ) : (
                    selectedTicket.replies.map((reply) => {
                      const isUser = reply.sender_role === 'user';
                      return (
                        <div
                          key={reply.id}
                          className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                        >
                          <div
                            className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs shadow-xs ${
                              isUser
                                ? 'bg-[#143D28] text-white rounded-br-xs'
                                : isDarkMode
                                ? 'bg-[#183827] border border-[#28593F] text-emerald-50 rounded-bl-xs'
                                : 'bg-white border border-[#D7EFE0] text-[#0F2D1F] rounded-bl-xs'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-3 mb-1">
                              <span
                                className={`text-[10px] font-black ${
                                  isUser
                                    ? 'text-[#6BCB37]'
                                    : 'text-[#16A34A] dark:text-[#6BCB37]'
                                }`}
                              >
                                {isUser ? 'Anda' : `${reply.sender_name} (CS)`}
                              </span>
                              <span className="text-[9px] opacity-70">
                                {reply.dateFormatted ||
                                  new Date(reply.created_at).toLocaleTimeString('id-ID', {
                                    hour: '2-digit',
                                    minute: '2-digit',
                                  })}
                              </span>
                            </div>
                            <p className="leading-relaxed whitespace-pre-wrap">{reply.message}</p>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* User Reply Box */}
                <form onSubmit={handleUserReply} className="flex gap-2 pt-1">
                  <input
                    type="text"
                    placeholder={
                      selectedTicket.status === 'Selesai'
                        ? 'Kirim balasan untuk membuka kembali tiket ini...'
                        : 'Tulis balasan untuk Customer Service...'
                    }
                    value={userReplyText}
                    onChange={(e) => setUserReplyText(e.target.value)}
                    className={`flex-1 px-3.5 py-2.5 rounded-xl border text-xs outline-none ${
                      isDarkMode
                        ? 'bg-[#0A1610] border-[#1E4330] text-white focus:border-[#6BCB37]'
                        : 'bg-white border-[#D7EFE0] focus:border-[#143D28]'
                    }`}
                  />
                  <button
                    type="submit"
                    disabled={sendingReply || !userReplyText.trim()}
                    className="px-4 py-2.5 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50 shrink-0"
                  >
                    {sendingReply ? (
                      <Loader2 className="w-4 h-4 animate-spin text-[#6BCB37]" />
                    ) : (
                      <Send className="w-3.5 h-3.5 text-[#6BCB37]" />
                    )}
                    <span>Kirim</span>
                  </button>
                </form>
              </div>
            ) : (
              /* MY TICKETS LIST VIEW */
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-bold text-gray-500 dark:text-gray-400">
                    Riwayat Pengaduan Anda ({myTickets.length})
                  </p>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={loadMyTickets}
                      disabled={loadingTickets}
                      className="text-xs font-bold text-[#143D28] dark:text-[#6BCB37] flex items-center gap-1 hover:underline cursor-pointer"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${loadingTickets ? 'animate-spin' : ''}`} />
                      <span>Segarkan</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('cs')}
                      className="px-2.5 py-1 rounded-lg bg-[#143D28] text-white text-[11px] font-bold hover:bg-[#0E2C1D] cursor-pointer"
                    >
                      + Pengaduan Baru
                    </button>
                  </div>
                </div>

                {loadingTickets ? (
                  <div className="py-12 flex flex-col items-center justify-center text-gray-400 gap-2">
                    <Loader2 className="w-6 h-6 animate-spin text-[#6BCB37]" />
                    <span className="text-xs">Memuat riwayat tiket Anda...</span>
                  </div>
                ) : myTickets.length === 0 ? (
                  <div className="py-12 text-center space-y-2.5">
                    <div className="w-12 h-12 rounded-2xl bg-[#EAF6EE] dark:bg-[#1A3828] text-[#143D28] dark:text-[#6BCB37] flex items-center justify-center mx-auto">
                      <Ticket className="w-6 h-6" />
                    </div>
                    <p className="text-xs font-bold text-gray-500 dark:text-gray-400">
                      Anda belum memiliki tiket pengaduan.
                    </p>
                    <button
                      type="button"
                      onClick={() => setActiveTab('cs')}
                      className="px-4 py-2 rounded-xl bg-[#143D28] text-white text-xs font-bold hover:bg-[#0E2C1D] cursor-pointer"
                    >
                      Buat Pengaduan Pertama
                    </button>
                  </div>
                ) : (
                  myTickets.map((ticket) => (
                    <button
                      key={ticket.id}
                      type="button"
                      onClick={() => loadTicketDetail(ticket.id)}
                      className={`w-full text-left p-3.5 rounded-2xl border transition-all cursor-pointer space-y-2 ${
                        isDarkMode
                          ? 'bg-[#0A1610] border-[#1E4330] hover:border-[#6BCB37]'
                          : 'bg-white border-[#E2ECE5] hover:border-[#143D28] shadow-2xs'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono text-[11px] font-extrabold text-[#143D28] dark:text-[#6BCB37]">
                          {ticket.ticket_code}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <TicketPriorityBadge priority={ticket.priority} />
                          <TicketStatusBadge status={ticket.status} />
                        </div>
                      </div>

                      <h4 className="text-xs sm:text-sm font-extrabold text-[#143D28] dark:text-white line-clamp-1">
                        {ticket.subject}
                      </h4>

                      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-gray-500 dark:text-gray-400">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-md bg-gray-100 dark:bg-[#163826] font-semibold text-gray-700 dark:text-gray-200">
                            {ticket.category}
                          </span>
                          <span className="font-mono text-[10px]">
                            Order: <strong className="text-[#143D28] dark:text-[#6BCB37]">{ticket.order_id}</strong>
                          </span>
                        </div>
                        <div className="flex items-center gap-2.5">
                          <span className="flex items-center gap-1">
                            <MessageSquare className="w-3 h-3 text-[#6BCB37]" />
                            {ticket.replyCount ?? 0} Balasan
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {ticket.dateFormatted ||
                              new Date(ticket.created_at).toLocaleDateString('id-ID')}
                          </span>
                        </div>
                      </div>
                    </button>
                  ))
                )}
              </div>
            )}
          </div>
        )}
      </motion.div>
    </div>
  );
};
