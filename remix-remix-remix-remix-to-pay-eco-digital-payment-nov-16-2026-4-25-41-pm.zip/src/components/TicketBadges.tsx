import React from 'react';
import { Clock, RefreshCw, MessageSquare, CheckCircle2, AlertTriangle, Minus, ArrowDown } from 'lucide-react';
import { TicketPriority, TicketStatus } from '../types';

export const TicketStatusBadge: React.FC<{ status: TicketStatus | string }> = ({ status }) => {
  switch (status) {
    case 'Menunggu':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
          <Clock className="w-3 h-3" />
          <span>Menunggu</span>
        </span>
      );
    case 'Diproses':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-blue-500/15 text-blue-400 border border-blue-500/30">
          <RefreshCw className="w-3 h-3" />
          <span>Diproses</span>
        </span>
      );
    case 'Tunggu User':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-purple-500/15 text-purple-400 border border-purple-500/30">
          <MessageSquare className="w-3 h-3" />
          <span>Tunggu User</span>
        </span>
      );
    case 'Selesai':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
          <CheckCircle2 className="w-3 h-3" />
          <span>Selesai</span>
        </span>
      );
    default:
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-slate-500/15 text-slate-300 border border-slate-500/30">
          <span>{status}</span>
        </span>
      );
  }
};

export const TicketPriorityBadge: React.FC<{ priority: TicketPriority | string }> = ({ priority }) => {
  switch (priority) {
    case 'Tinggi':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-orange-500/15 text-orange-400 border border-orange-500/30">
          <AlertTriangle className="w-3 h-3" />
          <span>Tinggi</span>
        </span>
      );
    case 'Sedang':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-500/15 text-blue-400 border border-blue-500/30">
          <Minus className="w-3 h-3" />
          <span>Sedang</span>
        </span>
      );
    case 'Rendah':
    default:
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-500/20 text-slate-300 border border-slate-500/30">
          <ArrowDown className="w-3 h-3" />
          <span>Rendah</span>
        </span>
      );
  }
};
