import React from 'react';

interface ToPayLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'custom';
  customHeight?: number;
  showText?: boolean;
  showTagline?: boolean;
  variant?: 'default' | 'white' | 'dark' | 'icon-only';
}

export const ToPayLogo: React.FC<ToPayLogoProps> = ({
  className = '',
  size = 'md',
  customHeight,
  showText = true,
  showTagline = false,
  variant = 'default',
}) => {
  // Dimension mapping
  const sizeMap = {
    sm: { iconSize: 28, textSize: 'text-sm', spacing: 'gap-1.5' },
    md: { iconSize: 40, textSize: 'text-lg', spacing: 'gap-2' },
    lg: { iconSize: 56, textSize: 'text-2xl', spacing: 'gap-3' },
    xl: { iconSize: 84, textSize: 'text-3xl', spacing: 'gap-3.5' },
    custom: { iconSize: customHeight || 40, textSize: 'text-lg', spacing: 'gap-2' },
  };

  const currentSize = sizeMap[size];

  // Palette definition strictly based on brand rules
  // Forest Green: #143D28 / #16422F
  // Lime Green: #6BCB37 / #7AC943
  const isWhite = variant === 'white';
  const forestColor = isWhite ? '#FFFFFF' : '#143D28';
  const limeColor = isWhite ? '#A3E635' : '#6BCB37';
  const textColor = isWhite ? 'text-white' : 'text-[#143D28]';
  const taglineColor = isWhite ? 'text-white/80' : 'text-[#2D5A40]';

  return (
    <div className={`inline-flex items-center ${currentSize.spacing} ${className}`}>
      {/* Precision Vector Squirrel & Leaf Icon matching the brand logo */}
      <svg
        width={currentSize.iconSize}
        height={currentSize.iconSize}
        viewBox="0 0 120 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="flex-shrink-0 transition-transform duration-300 hover:scale-105"
      >
        {/* Outer Squirrel & Leaf Contour - Forest Green */}
        <path
          d="M24 64C20 48 30 24 50 16C58 28 58 42 52 54C62 46 72 40 82 44C88 38 92 38 96 42C98 44 98 48 94 52C100 54 102 58 100 64C96 68 88 66 84 64C86 70 84 76 80 80C72 88 56 94 40 86C28 78 24 68 24 64Z"
          stroke={forestColor}
          strokeWidth="6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Leaf Tail Vein / Inner Leaf Curve - Forest Green & Lime Green */}
        <path
          d="M34 58C32 44 40 28 50 20C48 34 46 48 38 58"
          stroke={forestColor}
          strokeWidth="4.5"
          strokeLinecap="round"
        />
        
        {/* Lime Green Inner Accent Curve on Leaf Tail */}
        <path
          d="M38 48C42 36 46 26 49 22"
          stroke={limeColor}
          strokeWidth="4"
          strokeLinecap="round"
        />

        {/* Squirrel Back & Head Feature Outline */}
        <path
          d="M62 44C68 32 80 30 84 36C86 32 92 32 94 36C96 40 94 44 90 46C96 48 97 53 94 57C90 60 84 58 82 56"
          stroke={forestColor}
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Squirrel Ear */}
        <path
          d="M82 34L85 24C86 23 88 23 89 25L90 32"
          stroke={forestColor}
          strokeWidth="4.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Squirrel Body Central Swirl & Chest Arc */}
        <path
          d="M52 62C52 74 62 82 74 80C82 78 86 70 84 62C82 54 72 50 62 56"
          stroke={forestColor}
          strokeWidth="5.5"
          strokeLinecap="round"
        />

        {/* Lime Green Organic Underbelly / Base Glow Arc */}
        <path
          d="M48 84C62 92 78 88 88 78C92 72 94 66 94 60"
          stroke={limeColor}
          strokeWidth="4.5"
          strokeLinecap="round"
        />

        {/* Squirrel Hand Gesture / Nut Holding Point */}
        <circle cx="88" cy="54" r="2.5" fill={limeColor} />
      </svg>

      {/* Brand Typography */}
      {showText && (
        <div className="flex flex-col">
          <div className={`font-extrabold tracking-wider leading-none ${currentSize.textSize} ${textColor}`}>
            TO PAY
          </div>
          {showTagline && (
            <span className={`text-[10px] sm:text-xs font-medium tracking-normal mt-0.5 ${taglineColor}`}>
              Pay Simple. Live Green.
            </span>
          )}
        </div>
      )}
    </div>
  );
};
