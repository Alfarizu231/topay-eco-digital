import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Search,
  Filter,
  Receipt,
  QrCode,
  Wallet,
  Send,
  Calendar,
  ChevronRight,
  Leaf,
} from 'lucide-react';
import { Transaction } from '../types';

interface RiwayatScreenProps {
  transactions: Transaction[];
  onSelectTransaction: (tx: Transaction) => void;
  isDarkMode?: boolean;
}

export const RiwayatScreen: React.FC<RiwayatScreenProps> = ({
  transactions,
  onSelectTransaction,
  isDarkMode = false,
}) => {
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filterTabs = [
    { id: 'all', label: 'Semua' },
    { id: 'in', label: 'Masuk' },
    { id: 'out', label: 'Keluar' },
    { id: 'topup', label: 'Top Up' },
    { id: 'transfer', label: 'Transfer' },
    { id: 'qris', label: 'QRIS' },
    { id: 'bill', label: 'Tagihan' },
  ];

  const filteredTransactions = transactions.filter((tx) => {
    // Tab Filter
    let matchesTab = true;
    if (activeFilter === 'in') matchesTab = tx.direction === 'in';
    else if (activeFilter === 'out') matchesTab = tx.direction === 'out';
    else if (activeFilter === 'topup') matchesTab = tx.type === 'topup';
    else if (activeFilter === 'transfer') matchesTab = tx.type === 'transfer';
    else if (activeFilter === 'qris') matchesTab = tx.type === 'qris';
    else if (activeFilter === 'bill') matchesTab = tx.type === 'bill' || tx.type === 'data' || tx.type === 'pulsa';

    // Search query
    const matchesSearch =
      tx.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.recipientOrSender.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.referenceNumber.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesTab && matchesSearch;
  });

  const getStatusBadge = (status: Transaction['status']) => {
    switch (status) {
      case 'SUCCESS':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#EAF6EE] text-[#16A34A] border border-[#16A34A]/20">
            Berhasil
          </span>
        );
      case 'PENDING':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#F4FCE3] text-[#65A30D] border border-[#84CC16]/30">
            Diproses
          </span>
        );
      case 'FAILED':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-600 border border-rose-200 dark:bg-rose-950/30 dark:text-rose-400">
            Gagal
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-gray-100 text-gray-600 border border-gray-200 dark:bg-gray-800 dark:text-gray-400">
            Dibatalkan
          </span>
        );
      default:
        return null;
    }
  };

  const getTypeIcon = (type: Transaction['type'], direction: Transaction['direction']) => {
    if (direction === 'in') {
      return (
        <div className="w-9 h-9 rounded-xl bg-[#EAF6EE] dark:bg-[#183827] flex items-center justify-center text-[#143D28] dark:text-[#6BCB37]">
          <ArrowDownLeft className="w-4 h-4 text-[#16A34A]" />
        </div>
      );
    }
    if (type === 'qris') {
      return (
        <div className="w-9 h-9 rounded-xl bg-[#EAF6EE] dark:bg-[#183827] flex items-center justify-center text-[#143D28] dark:text-[#6BCB37]">
          <QrCode className="w-4 h-4 text-[#143D28] dark:text-[#6BCB37]" />
        </div>
      );
    }
    if (type === 'ewallet') {
      return (
        <div className="w-9 h-9 rounded-xl bg-[#EAF6EE] dark:bg-[#183827] flex items-center justify-center text-[#143D28] dark:text-[#6BCB37]">
          <Wallet className="w-4 h-4 text-[#143D28] dark:text-[#6BCB37]" />
        </div>
      );
    }
    if (type === 'transfer') {
      return (
        <div className="w-9 h-9 rounded-xl bg-[#EAF6EE] dark:bg-[#183827] flex items-center justify-center text-[#143D28] dark:text-[#6BCB37]">
          <Send className="w-4 h-4 text-[#143D28] dark:text-[#6BCB37]" />
        </div>
      );
    }
    return (
      <div className="w-9 h-9 rounded-xl bg-[#EAF6EE] dark:bg-[#183827] flex items-center justify-center text-[#143D28] dark:text-[#6BCB37]">
        <ArrowUpRight className="w-4 h-4 text-[#143D28] dark:text-[#6BCB37]" />
      </div>
    );
  };

  return (
    <div className="w-full space-y-4">
      {/* Title & Stats */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-[#143D28] dark:text-white">
            Riwayat Transaksi
          </h1>
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Daftar seluruh mutasi dan pembayaran TO PAY
          </p>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
          <Search className="w-4 h-4 text-[#143D28] dark:text-[#6BCB37]" />
        </div>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Cari transaksi, merchant, nomor ref..."
          className={`w-full pl-10 pr-4 py-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-[#6BCB37] ${
            isDarkMode
              ? 'bg-[#12281E] border-[#1E4330] text-white placeholder-gray-500'
              : 'bg-white border-[#E2ECE5] text-[#0F2D1F] placeholder-gray-400'
          }`}
        />
      </div>

      {/* Horizontal Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {filterTabs.map((tab) => {
          const isActive = activeFilter === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#143D28] text-white shadow-xs'
                  : isDarkMode
                    ? 'bg-[#12281E] text-gray-400 border border-[#1E4330] hover:text-white'
                    : 'bg-white text-gray-600 border border-[#E2ECE5] hover:bg-[#F2FAF5]'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Transactions List */}
      <div className="space-y-2.5">
        {filteredTransactions.length === 0 ? (
          <div className={`p-8 text-center rounded-2xl border ${
            isDarkMode ? 'bg-[#12281E] border-[#1E4330]' : 'bg-white border-[#E2ECE5]'
          }`}>
            <Receipt className="w-10 h-10 mx-auto text-gray-400 mb-2" />
            <div className="text-sm font-bold text-gray-700 dark:text-gray-300">
              {transactions.length === 0 ? 'Belum ada riwayat transaksi' : 'Tidak ada transaksi yang cocok'}
            </div>
            <p className="text-xs text-gray-400 mt-1">
              {transactions.length === 0
                ? 'Aktivitas top up, transfer, QRIS, dan pembayaran tagihan Anda akan tercatat di sini.'
                : 'Gunakan kata kunci atau filter lain untuk melihat mutasi.'}
            </p>
          </div>
        ) : (
          filteredTransactions.map((tx) => {
            const isIncome = tx.direction === 'in';
            return (
              <motion.div
                key={tx.id}
                whileHover={{ scale: 1.005 }}
                onClick={() => onSelectTransaction(tx)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                  isDarkMode
                    ? 'bg-[#12281E] border-[#1E4330] hover:bg-[#183827]'
                    : 'bg-white border-[#E6EFE8] hover:bg-[#F8FAF8] hover:border-[#143D28]/30 shadow-[0_1px_2px_rgba(20,61,40,0.02)]'
                }`}
              >
                {/* Left side: Icon + Title + Date */}
                <div className="flex items-center gap-3 min-w-0">
                  {getTypeIcon(tx.type, tx.direction)}
                  <div className="min-w-0">
                    <div className="text-xs sm:text-sm font-bold text-[#143D28] dark:text-white truncate">
                      {tx.title}
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">
                      <span>{tx.date}</span>
                      <span>•</span>
                      <span className="truncate max-w-[120px] sm:max-w-[180px]">
                        {tx.recipientOrSender}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right side: Amount + Status + Eco impact */}
                <div className="flex flex-col items-end flex-shrink-0">
                  <div
                    className={`text-xs sm:text-sm font-extrabold ${
                      isIncome
                        ? 'text-[#16A34A] dark:text-[#6BCB37]'
                        : 'text-[#143D28] dark:text-gray-100'
                    }`}
                  >
                    {isIncome ? '+' : '-'}Rp{tx.amount.toLocaleString('id-ID')}
                  </div>
                  <div className="flex items-center gap-1.5 mt-1">
                    {tx.ecoImpact && (
                      <span className="hidden sm:flex items-center gap-0.5 text-[10px] text-[#2D5A40] dark:text-[#6BCB37]">
                        <Leaf className="w-2.5 h-2.5" />
                        <span>{tx.ecoImpact.ecoPoints}p</span>
                      </span>
                    )}
                    {getStatusBadge(tx.status)}
                  </div>
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
};
