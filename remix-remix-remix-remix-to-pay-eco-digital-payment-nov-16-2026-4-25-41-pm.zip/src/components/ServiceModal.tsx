import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, CheckCircle2, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';
import { ServiceItem } from '../types';

interface ServiceModalProps {
  service: ServiceItem;
  userBalance: number;
  userPhone?: string;
  onClose: () => void;
  onPaymentSuccess: (data: {
    serviceName: string;
    amount: number;
    accountOrNumber: string;
    category: string;
  }) => void;
  isDarkMode?: boolean;
}

export const ServiceModal: React.FC<ServiceModalProps> = ({
  service,
  userBalance,
  userPhone = '',
  onClose,
  onPaymentSuccess,
  isDarkMode = false,
}) => {
  const defaultPhone =
    service.id === 'pulsa' || service.id === 'data'
      ? userPhone.replace('+62 ', '0').replace(/[^\d]/g, '')
      : '';
  const [customerNumber, setCustomerNumber] = useState(defaultPhone);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const getPresetList = () => {
    switch (service.id) {
      case 'pulsa':
      case 'data':
        return [
          { name: '15.000 (Masa Aktif 30 Hari)', price: 15500 },
          { name: '25.000 (Masa Aktif 30 Hari)', price: 25500 },
          { name: '50.000 (Masa Aktif 45 Hari)', price: 50000 },
          { name: '100.000 (Masa Aktif 60 Hari)', price: 99000 },
          { name: '200.000 (Masa Aktif 90 Hari)', price: 198000 },
        ];
      case 'pln':
        return [
          { name: 'Token Listrik 20.000', price: 21500 },
          { name: 'Token Listrik 50.000', price: 51500 },
          { name: 'Token Listrik 100.000', price: 101500 },
          { name: 'Token Listrik 200.000', price: 201500 },
          { name: 'Token Listrik 500.000', price: 501500 },
        ];
      case 'game':
        return [
          { name: '86 Diamonds MLBB', price: 20000 },
          { name: '172 Diamonds MLBB', price: 40000 },
          { name: '257 Diamonds MLBB', price: 60000 },
          { name: 'Steam Wallet IDR 90K', price: 95000 },
          { name: 'Valorant 1375 VP', price: 135000 },
        ];
      case 'streaming':
        return [
          { name: 'Spotify Premium Individual 1 Bulan', price: 54990 },
          { name: 'Netflix Premium 4K Ultra HD', price: 186000 },
          { name: 'Vidio Platinum Premier League', price: 79000 },
          { name: 'YouTube Premium Family Plan', price: 99000 },
        ];
      default:
        return [
          { name: 'Tagihan Reguler Bulan Ini', price: 125000 },
          { name: 'Tagihan Periode Penuh', price: 245000 },
        ];
    }
  };

  const presetList = getPresetList();
  const [selectedItem, setSelectedItem] = useState(presetList[0]);

  const handlePay = () => {
    if (!customerNumber.trim()) {
      setErrorMsg('Masukkan nomor pelanggan atau nomor HP terlebih dahulu.');
      return;
    }
    if (selectedItem.price > userBalance) {
      setErrorMsg('Saldo TO PAY Anda tidak mencukupi untuk pembayaran ini.');
      return;
    }
    setErrorMsg(null);

    onPaymentSuccess({
      serviceName: `${service.title} - ${selectedItem.name}`,
      amount: selectedItem.price,
      accountOrNumber: customerNumber.trim(),
      category: service.title,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className={`w-full max-w-md rounded-2xl p-5 sm:p-6 shadow-2xl border ${
          isDarkMode ? 'bg-[#12281E] border-[#1E4330] text-white' : 'bg-white border-[#E2ECE5] text-[#0F2D1F]'
        }`}
      >
        <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800">
          <div>
            <h2 className="text-base font-extrabold text-[#143D28] dark:text-white">
              {service.title}
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {service.description}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-3.5 max-h-[70vh] overflow-y-auto pr-1">
          <div>
            <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1">
              Nomor Pelanggan / Nomor HP
            </label>
            <input
              type="text"
              value={customerNumber}
              onChange={(e) => {
                setCustomerNumber(e.target.value);
                if (errorMsg) setErrorMsg(null);
              }}
              placeholder="Contoh: 0812xxxx / ID Pelanggan"
              className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#6BCB37] ${
                isDarkMode
                  ? 'bg-[#0A1610] border-[#1E4330] text-white'
                  : 'bg-[#F4FAF6] border-[#D7EFE0] text-[#0F2D1F]'
              }`}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1.5">
              Pilih Paket / Nominal
            </label>
            <div className="space-y-2">
              {presetList.map((item, idx) => {
                const isSelected = selectedItem.name === item.name;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSelectedItem(item)}
                    className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? isDarkMode
                          ? 'bg-[#1A3D2A] border-[#6BCB37] text-white'
                          : 'bg-[#EAF6EE] border-[#143D28] text-[#143D28] shadow-xs'
                        : isDarkMode
                          ? 'bg-[#0A1610] border-[#1E4330] text-gray-300'
                          : 'bg-white border-[#E2ECE5] text-gray-700 hover:bg-[#F9FCFA]'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-bold">{item.name}</div>
                      <div className="text-[10px] text-gray-400">Proses instan</div>
                    </div>
                    <div className="text-xs sm:text-sm font-extrabold text-[#143D28] dark:text-[#6BCB37]">
                      Rp{item.price.toLocaleString('id-ID')}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-[#143D28] dark:text-[#A3E635]">
              <Sparkles className="w-3.5 h-3.5 text-[#6BCB37]" />
              <span>Dapatkan 10 Eco Points</span>
            </div>
            <span className="font-bold text-[#143D28] dark:text-white">
              Saldo: Rp{userBalance.toLocaleString('id-ID')}
            </span>
          </div>

          {errorMsg && (
            <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-xs font-semibold text-rose-700 dark:text-rose-200">
              {errorMsg}
            </div>
          )}

          <button
            type="button"
            onClick={handlePay}
            className="w-full py-3 px-4 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
          >
            <span>Bayar Sekarang (Rp{selectedItem.price.toLocaleString('id-ID')})</span>
            <ArrowRight className="w-4 h-4 text-[#6BCB37]" />
          </button>
        </div>
      </motion.div>
    </div>
  );
};
