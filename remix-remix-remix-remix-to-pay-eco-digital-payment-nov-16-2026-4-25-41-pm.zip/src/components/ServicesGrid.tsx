import React from 'react';
import {
  Smartphone,
  Wifi,
  Zap,
  HeartPulse,
  Droplets,
  Globe,
  Gamepad2,
  Wallet,
  Tv,
  Receipt,
} from 'lucide-react';
import { ServiceItem } from '../types';

interface ServicesGridProps {
  services: ServiceItem[];
  onSelectService: (service: ServiceItem) => void;
  isDarkMode?: boolean;
}

const iconMap: Record<string, React.ElementType> = {
  Smartphone,
  Wifi,
  Zap,
  HeartPulse,
  Droplets,
  Globe,
  Gamepad2,
  Wallet,
  Tv,
  Receipt,
};

export const ServicesGrid: React.FC<ServicesGridProps> = ({
  services,
  onSelectService,
  isDarkMode = false,
}) => {
  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h2 className="text-sm font-bold text-gray-900 dark:text-white">
            Layanan TO PAY
          </h2>
          <p className="text-[11px] text-gray-600 dark:text-gray-300">
            Kebutuhan harian, tagihan &amp; hiburan digital
          </p>
        </div>
        <span className="text-[11px] font-bold text-[#113C2B] dark:text-[#6BCB37]">
          10 Layanan
        </span>
      </div>

      <div className="grid grid-cols-5 gap-2 sm:gap-3">
        {services.map((srv) => {
          const Icon = iconMap[srv.iconName] || Receipt;
          const isEWallet = srv.id === 'ewallet';

          return (
            <button
              key={srv.id}
              onClick={() => onSelectService(srv)}
              className={`relative flex flex-col items-center justify-center p-2.5 sm:p-3 rounded-xl border transition-all duration-200 cursor-pointer active:scale-95 group ${
                isDarkMode
                  ? 'bg-[#12281E] border-[#1E4330]/80 hover:border-[#6BCB37]/40 hover:bg-[#163826]'
                  : 'bg-white border-[#E6EFE8] hover:border-[#6BCB37]/60 hover:bg-[#F6FAF7] shadow-[0_1px_3px_rgba(20,61,40,0.03)]'
              }`}
            >
              {/* Optional tiny lime badge */}
              {srv.badge && (
                <span className="absolute -top-1.5 right-1 px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-[#6BCB37] text-[#0F2D1F] tracking-tight shadow-xs">
                  {srv.badge}
                </span>
              )}

              {/* Icon Container with Forest Green & Lime Accent */}
              <div
                className={`relative w-10 h-10 rounded-xl flex items-center justify-center mb-1.5 transition-transform duration-200 group-hover:scale-105 ${
                  isDarkMode ? 'bg-[#183628]' : 'bg-[#EAF6EE]'
                }`}
              >
                <Icon className="w-5 h-5 text-[#143D28] dark:text-[#6BCB37]" />
                
                {/* Small Lime Accent Dot on Icon corner */}
                <span className="absolute bottom-1 right-1 w-1.5 h-1.5 rounded-full bg-[#6BCB37]" />
              </div>

              {/* Title */}
              <span
                className={`text-[11px] sm:text-xs font-semibold text-center leading-tight transition-colors line-clamp-1 ${
                  isDarkMode
                    ? 'text-gray-200 group-hover:text-[#6BCB37]'
                    : 'text-[#143D28] group-hover:text-[#0E2C1D]'
                }`}
              >
                {srv.title}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
