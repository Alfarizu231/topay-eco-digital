import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Smartphone,
  Laptop,
  Tablet,
  ShieldCheck,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Loader2,
  Globe,
  Clock,
} from 'lucide-react';
import { ConnectedDevice } from '../types';
import { authFetch } from '../utils/authFetch';

interface ConnectedDevicesModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDarkMode?: boolean;
}

export const ConnectedDevicesModal: React.FC<ConnectedDevicesModalProps> = ({
  isOpen,
  onClose,
  isDarkMode = false,
}) => {
  const [devices, setDevices] = useState<ConnectedDevice[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [revokingId, setRevokingId] = useState<string | null>(null);
  const [confirmDevice, setConfirmDevice] = useState<ConnectedDevice | null>(null);
  const [confirmLogoutAll, setConfirmLogoutAll] = useState(false);
  const [isLoggingOutAll, setIsLoggingOutAll] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleLogoutAll = async () => {
    setIsLoggingOutAll(true);
    setErrorMessage(null);
    try {
      const res = await authFetch('/api/auth/logout-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();
      if (data.success) {
        setToastMessage('Semua sesi di perangkat lain berhasil dicabut.');
        setConfirmLogoutAll(false);
        fetchDevices();
        setTimeout(() => setToastMessage(null), 3000);
      } else {
        setErrorMessage(data.error || 'Gagal mengeluarkan semua perangkat.');
      }
    } catch (err) {
      console.error('Logout all error:', err);
      setErrorMessage('Terjadi kendala jaringan.');
    } finally {
      setIsLoggingOutAll(false);
    }
  };

  const fetchDevices = async () => {
    setIsLoading(true);
    try {
      const res = await authFetch('/api/devices');
      const data = await res.json();
      if (data.success && Array.isArray(data.devices)) {
        setDevices(data.devices);
      }
    } catch (err) {
      console.error('Error fetching devices:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchDevices();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleRevokeDevice = async (device: ConnectedDevice) => {
    setRevokingId(device.id);
    setErrorMessage(null);
    try {
      const res = await authFetch('/api/devices/revoke', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deviceId: device.id }),
      });
      const data = await res.json();
      if (data.success) {
        setDevices((prev) => prev.filter((d) => d.id !== device.id));
        setToastMessage('Perangkat berhasil dikeluarkan.');
        setConfirmDevice(null);
        setTimeout(() => setToastMessage(null), 3000);
      } else {
        setErrorMessage(data.error || 'Gagal mengeluarkan perangkat.');
      }
    } catch (err) {
      console.error('Revoke error:', err);
      setErrorMessage('Terjadi kendala jaringan.');
    } finally {
      setRevokingId(null);
    }
  };

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case 'desktop':
        return <Laptop className="w-5 h-5" />;
      case 'tablet':
        return <Tablet className="w-5 h-5" />;
      default:
        return <Smartphone className="w-5 h-5" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs">
      <motion.div
        initial={{ scale: 0.94, opacity: 0, y: 15 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.94, opacity: 0, y: 15 }}
        className={`w-full max-w-lg rounded-3xl p-5 sm:p-6 shadow-2xl border relative overflow-hidden flex flex-col max-h-[90vh] ${
          isDarkMode
            ? 'bg-[#12281E] border-[#1E4330] text-white'
            : 'bg-white border-[#E2ECE5] text-[#0F2D1F]'
        }`}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 dark:hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 pb-4 border-b border-gray-100 dark:border-gray-800">
          <div className="w-11 h-11 rounded-2xl bg-[#EAF6EE] dark:bg-[#1A3828] text-[#143D28] dark:text-[#6BCB37] flex items-center justify-center shrink-0">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-[#143D28] dark:text-white">
              Perangkat Terhubung
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Daftar sesi & perangkat yang memiliki akses ke akun Anda
            </p>
          </div>
        </div>

        {/* Toast alert */}
        <AnimatePresence>
          {toastMessage && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-3 p-3 rounded-xl bg-emerald-50 dark:bg-[#1A3828] border border-emerald-200 dark:border-[#224E38] flex items-center gap-2 text-xs text-emerald-800 dark:text-[#6BCB37] font-bold"
            >
              <CheckCircle2 className="w-4 h-4 text-[#16A34A] dark:text-[#6BCB37]" />
              <span>{toastMessage}</span>
            </motion.div>
          )}
          {errorMessage && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-3 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 flex items-center gap-2 text-xs text-rose-700 dark:text-rose-200 font-bold"
            >
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* List of devices */}
        <div className="flex-1 overflow-y-auto py-4 space-y-3">
          {isLoading ? (
            <div className="py-12 flex flex-col items-center justify-center text-gray-400 gap-2">
              <Loader2 className="w-6 h-6 animate-spin text-[#6BCB37]" />
              <span className="text-xs">Memuat daftar perangkat...</span>
            </div>
          ) : devices.length === 0 ? (
            <div className="py-10 text-center text-xs text-gray-400">
              Tidak ada perangkat aktif lain yang terhubung.
            </div>
          ) : (
            devices.map((dev) => (
              <div
                key={dev.id}
                className={`p-3.5 sm:p-4 rounded-2xl border transition-all ${
                  dev.isCurrent
                    ? 'bg-[#F0FAF3] dark:bg-[#1A3828]/60 border-[#6BCB37]/50 ring-1 ring-[#6BCB37]/30'
                    : isDarkMode
                      ? 'bg-[#0A1610] border-[#1E4330]'
                      : 'bg-gray-50 border-gray-100'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      dev.isCurrent
                        ? 'bg-[#143D28] text-[#6BCB37]'
                        : isDarkMode
                          ? 'bg-[#1E4330] text-gray-300'
                          : 'bg-gray-200 text-gray-700'
                    }`}>
                      {getDeviceIcon(dev.type)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs sm:text-sm font-bold text-[#143D28] dark:text-white">
                          {dev.name}
                        </h4>
                        {dev.isCurrent && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-[#6BCB37] text-[#0F2D1F]">
                            Perangkat Ini
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">
                        {dev.browser} • {dev.os}
                      </p>
                      <div className="flex items-center gap-1.5 text-[10px] text-gray-400 mt-1.5">
                        <Globe className="w-3 h-3" />
                        <span>{dev.ipLocation}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-[10px] text-emerald-700 dark:text-[#6BCB37] mt-0.5 font-medium">
                        <Clock className="w-3 h-3" />
                        <span>{dev.lastActive}</span>
                      </div>
                    </div>
                  </div>

                  {!dev.isCurrent && (
                    <button
                      type="button"
                      onClick={() => setConfirmDevice(dev)}
                      disabled={revokingId === dev.id}
                      className="px-2.5 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 hover:bg-rose-100 dark:hover:bg-rose-900/50 text-[11px] font-bold transition-colors cursor-pointer border border-rose-200 dark:border-rose-900/40 shrink-0 flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Keluarkan</span>
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Keluar dari Semua Perangkat Button */}
        {devices.some((d) => !d.isCurrent) && (
          <div className="py-2">
            <button
              type="button"
              onClick={() => setConfirmLogoutAll(true)}
              className="w-full py-2.5 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/50 border border-rose-200 dark:border-rose-900/50 text-rose-700 dark:text-rose-300 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <Trash2 className="w-4 h-4 text-rose-600 dark:text-rose-400" />
              <span>Keluar dari Semua Perangkat Lain</span>
            </button>
          </div>
        )}

        {/* Security Info Card */}
        <div className="pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-gray-500 dark:text-gray-400 text-[11px]">
            <ShieldCheck className="w-4 h-4 text-[#16A34A] dark:text-[#6BCB37]" />
            <span>Setiap sesi terproteksi enkripsi TLS 1.3</span>
          </div>
          <button
            type="button"
            onClick={fetchDevices}
            className="text-[11px] font-bold text-[#143D28] dark:text-[#6BCB37] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Segarkan</span>
          </button>
        </div>

        {/* Revoke All Confirmation Dialog */}
        <AnimatePresence>
          {confirmLogoutAll && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-20">
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className={`w-full max-w-sm p-5 rounded-2xl border shadow-xl ${
                  isDarkMode ? 'bg-[#12281E] border-[#1E4330] text-white' : 'bg-white border-gray-200 text-[#0F2D1F]'
                }`}
              >
                <div className="w-10 h-10 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center mb-3">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-bold">Cabut Semua Sesi Lain?</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Apakah Anda yakin ingin mengeluarkan akun dari <strong>seluruh perangkat lain</strong>? Sesi login di perangkat lain akan langsung dinonaktifkan seketika.
                </p>
                <div className="flex gap-2 mt-4">
                  <button
                    type="button"
                    onClick={() => setConfirmLogoutAll(false)}
                    className="flex-1 py-2 rounded-xl border border-gray-200 dark:border-gray-700 text-xs font-bold hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    onClick={handleLogoutAll}
                    disabled={isLoggingOutAll}
                    className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-1"
                  >
                    {isLoggingOutAll ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      'Ya, Keluarkan Semua'
                    )}
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Revoke Confirmation Dialog */}
        <AnimatePresence>
          {confirmDevice && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-20">
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className={`w-full max-w-sm p-5 rounded-2xl border shadow-xl ${
                  isDarkMode ? 'bg-[#12281E] border-[#1E4330] text-white' : 'bg-white border-gray-200 text-[#0F2D1F]'
                }`}
              >
                <div className="w-10 h-10 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center mb-3">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-bold">Keluarkan Perangkat?</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Apakah kamu yakin ingin mengeluarkan <strong>{confirmDevice.name}</strong>? Sesi login perangkat ini akan langsung dibatalkan.
                </p>
                <div className="flex gap-2 mt-4">
                  <button
                    type="button"
                    onClick={() => setConfirmDevice(null)}
                    className="flex-1 py-2 rounded-xl border border-gray-200 dark:border-gray-700 text-xs font-bold hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRevokeDevice(confirmDevice)}
                    disabled={revokingId === confirmDevice.id}
                    className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-1"
                  >
                    {revokingId === confirmDevice.id ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      'Ya, Keluarkan'
                    )}
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};
