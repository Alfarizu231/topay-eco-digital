import React, { useEffect } from 'react';

export type SeoPageKey =
  | 'home'
  | 'layanan'
  | 'promo'
  | 'keamanan'
  | 'faq'
  | 'riwayat'
  | 'profile'
  | 'qris'
  | 'admin'
  | 'login';

interface SeoConfig {
  title: string;
  description: string;
  canonicalPath: string;
  noindex?: boolean;
}

const SEO_PAGE_MAP: Record<SeoPageKey, SeoConfig> = {
  home: {
    title: 'TO PAY – Aplikasi Pembayaran Digital, QRIS & Eco Fintech',
    description:
      'Kelola pembayaran QRIS, transfer bank gratis, top up e-wallet, dan tagihan harian lebih cepat, aman, serta ramah lingkungan bersama TO PAY.',
    canonicalPath: '/',
  },
  login: {
    title: 'TO PAY – Aplikasi Pembayaran Digital, QRIS & Eco Fintech',
    description:
      'Masuk atau daftar akun TO PAY untuk transaksi QRIS nasional, transfer bebas biaya admin, top up e-wallet, dan bayar tagihan ramah lingkungan.',
    canonicalPath: '/',
  },
  layanan: {
    title: 'Layanan Pembayaran Digital, Pulsa, PLN & E-Wallet | TO PAY',
    description:
      'Bayar tagihan listrik PLN, PDAM, BPJS, internet, isi pulsa, paket data, voucher game, dan top up GoPay, DANA, OVO, serta ShopeePay di TO PAY.',
    canonicalPath: '/layanan',
  },
  promo: {
    title: 'Promo Cashback QRIS & Bebas Biaya Transfer | TO PAY',
    description:
      'Temukan promo cashback eco merchant, gratis biaya transfer bank, diskon token listrik PLN, dan bonus Eco Points di dompet digital TO PAY.',
    canonicalPath: '/promo',
  },
  keamanan: {
    title: 'Keamanan Akun, Enkripsi PIN PBKDF2 & Biometrik | TO PAY',
    description:
      'Pelajari perlindungan berlapis TO PAY dengan enkripsi Salted SHA-256, PBKDF2, autentikasi biometrik, kontrol perangkat, dan standar QRIS Bank Indonesia.',
    canonicalPath: '/keamanan',
  },
  faq: {
    title: 'Pusat Bantuan & Tanya Jawab (FAQ) Layanan | TO PAY',
    description:
      'Jawaban lengkap seputar cara daftar, top up saldo, pembayaran QRIS Bank Indonesia, transfer gratis, ubah PIN, dan layanan CS 24/7 TO PAY.',
    canonicalPath: '/faq',
  },
  riwayat: {
    title: 'Riwayat Transaksi & Mutasi Saldo | TO PAY',
    description:
      'Pantau seluruh riwayat transaksi QRIS, transfer, top up saldo, dan pembayaran tagihan Anda secara real-time di TO PAY.',
    canonicalPath: '/riwayat',
    noindex: true,
  },
  profile: {
    title: 'Profil Akun & Pengaturan Keamanan | TO PAY',
    description:
      'Kelola data pribadi, ubah PIN keamanan, biometrik, dan perangkat terhubung pada akun TO PAY Anda.',
    canonicalPath: '/profil',
    noindex: true,
  },
  qris: {
    title: 'Scan & Bayar QRIS Nasional Bank Indonesia | TO PAY',
    description:
      'Lakukan pembayaran instan menggunakan QRIS TO PAY di seluruh merchant berstandar Bank Indonesia dan ASPI.',
    canonicalPath: '/qris',
    noindex: true,
  },
  admin: {
    title: 'Web Admin Command Center | TO PAY',
    description: 'Portal administrasi internal TO PAY.',
    canonicalPath: '/admin',
    noindex: true,
  },
};

function upsertMetaTag(attr: 'name' | 'property', key: string, content: string) {
  let tag = document.head.querySelector(`meta[${attr}="${key}"]`) as HTMLMetaElement | null;
  if (!tag) {
    tag = document.createElement('meta');
    tag.setAttribute(attr, key);
    document.head.appendChild(tag);
  }
  tag.setAttribute('content', content);
}

function upsertLinkTag(rel: string, href: string) {
  let link = document.head.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement | null;
  if (!link) {
    link = document.createElement('link');
    link.setAttribute('rel', rel);
    document.head.appendChild(link);
  }
  link.setAttribute('href', href);
}

interface SeoHeadProps {
  pageKey: SeoPageKey;
}

export const SeoHead: React.FC<SeoHeadProps> = ({ pageKey }) => {
  useEffect(() => {
    const config = SEO_PAGE_MAP[pageKey] || SEO_PAGE_MAP.home;
    const origin = window.location.origin;
    const canonicalUrl = `${origin}${config.canonicalPath}`;
    const ogImageUrl = `${origin}/og-image.jpg`;

    document.title = config.title;

    upsertMetaTag('name', 'description', config.description);
    upsertMetaTag(
      'name',
      'robots',
      config.noindex
        ? 'noindex, nofollow'
        : 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1'
    );
    upsertMetaTag('name', 'googlebot', config.noindex ? 'noindex, nofollow' : 'index, follow');

    upsertLinkTag('canonical', canonicalUrl);

    upsertMetaTag('property', 'og:title', config.title);
    upsertMetaTag('property', 'og:description', config.description);
    upsertMetaTag('property', 'og:url', canonicalUrl);
    upsertMetaTag('property', 'og:image', ogImageUrl);

    upsertMetaTag('name', 'twitter:title', config.title);
    upsertMetaTag('name', 'twitter:description', config.description);
    upsertMetaTag('name', 'twitter:image', ogImageUrl);

    // Sync JSON-LD URLs to absolute origin URLs for Google Rich Results Test
    const jsonLdEl = document.head.querySelector('script[type="application/ld+json"]');
    if (jsonLdEl && jsonLdEl.textContent && jsonLdEl.textContent.includes('"/#organization"')) {
      try {
        const parsed = JSON.parse(jsonLdEl.textContent);
        if (parsed['@graph'] && Array.isArray(parsed['@graph'])) {
          parsed['@graph'] = parsed['@graph'].map((node: any) => {
            if (node['@type'] === 'Organization') {
              return {
                ...node,
                '@id': `${origin}/#organization`,
                url: origin,
                logo: `${origin}/favicon.svg`,
              };
            }
            if (node['@type'] === 'WebApplication') {
              return {
                ...node,
                '@id': `${origin}/#webapp`,
                url: origin,
                image: ogImageUrl,
                publisher: { '@id': `${origin}/#organization` },
              };
            }
            if (node['@type'] === 'FAQPage') {
              return {
                ...node,
                '@id': `${origin}/#faq`,
                url: `${origin}/faq`,
              };
            }
            return node;
          });
          jsonLdEl.textContent = JSON.stringify(parsed);
        }
      } catch {
        // Ignore parse error if already updated
      }
    }
  }, [pageKey]);

  return null;
};
