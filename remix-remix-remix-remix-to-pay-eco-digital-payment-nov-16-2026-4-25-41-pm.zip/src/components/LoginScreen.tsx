import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ToPayLogo } from './ToPayLogo';
import {
  Eye,
  EyeOff,
  Lock,
  Phone,
  Mail,
  User,
  AtSign,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  RefreshCw,
  ShieldAlert,
  CheckCircle2,
} from 'lucide-react';
import { PublicSeoSections } from './PublicSeoSections';

const BRAND_LOGO_SRC = '/assets/aistudio/IMG-20261113-WA0018_542ce974.jpg';

interface LoginScreenProps {
  onLoginSuccess: (userData?: any, token?: string) => void;
  isDarkMode?: boolean;
  activeSection?: 'home' | 'layanan' | 'promo' | 'keamanan' | 'faq';
  onNavigate?: (path: string, sectionId?: string) => void;
  onOpenLegal?: (type: 'terms' | 'privacy') => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLoginSuccess,
  isDarkMode = false,
  activeSection = 'home',
  onNavigate,
  onOpenLegal,
}) => {
  // Common state
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [headerLogoFailed, setHeaderLogoFailed] = useState(false);
  const [cardLogoFailed, setCardLogoFailed] = useState(false);

  // Login Form State (Cleaned - No hardcoded demo credentials)
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  // Register Form State (6 Distinct Fields)
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [showRegConfirmPassword, setShowRegConfirmPassword] = useState(false);

  // Field error tracking for instant inline feedback
  const [fieldErrors, setFieldErrors] = useState<{ [key: string]: string }>({});

  // Multi-layer security challenge state
  const [requiresChallenge, setRequiresChallenge] = useState(false);
  const [challengeData, setChallengeData] = useState<{ id: string; question: string } | null>(null);
  const [challengeAnswer, setChallengeAnswer] = useState('');
  const [remainingAttempts, setRemainingAttempts] = useState<number | null>(null);
  const [lockoutSeconds, setLockoutSeconds] = useState<number | null>(null);

  // Lockout countdown timer
  useEffect(() => {
    if (lockoutSeconds === null || lockoutSeconds <= 0) return;
    const interval = setInterval(() => {
      setLockoutSeconds((prev) => {
        if (prev === null || prev <= 1) return null;
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [lockoutSeconds]);

  const fetchNewChallenge = async () => {
    try {
      const res = await fetch('/api/auth/challenge');
      const data = await res.json();
      if (data.success && data.challenge) {
        setChallengeData(data.challenge);
        setChallengeAnswer('');
      }
    } catch (err) {
      console.error('Failed to load challenge:', err);
    }
  };

  // Validate single registration field
  const validateField = (field: string, value: string) => {
    const errors = { ...fieldErrors };

    switch (field) {
      case 'name':
        if (!value.trim() || value.trim().length < 3) {
          errors.name = 'Nama lengkap wajib diisi (minimal 3 karakter)';
        } else {
          delete errors.name;
        }
        break;
      case 'phone': {
        const digits = value.replace(/\D/g, '');
        if (!digits) {
          errors.phone = 'Nomor HP wajib diisi';
        } else if (!/^(08|628)[0-9]{8,13}$/.test(digits) && !(digits.startsWith('8') && digits.length >= 9)) {
          errors.phone = 'Nomor HP harus valid (contoh: 08xxxxxxxxxx)';
        } else {
          delete errors.phone;
        }
        break;
      }
      case 'email': {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!value.trim()) {
          errors.email = 'Email wajib diisi';
        } else if (!emailRegex.test(value.trim())) {
          errors.email = 'Format email tidak valid';
        } else {
          delete errors.email;
        }
        break;
      }
      case 'username': {
        const cleanUser = value.replace(/^@/, '').trim();
        if (!cleanUser) {
          errors.username = 'Username wajib diisi';
        } else if (cleanUser.length < 4) {
          errors.username = 'Username minimal 4 karakter';
        } else if (!/^[a-zA-Z0-9._]+$/.test(cleanUser)) {
          errors.username = 'Username hanya boleh huruf, angka, titik, atau underscore';
        } else {
          delete errors.username;
        }
        break;
      }
      case 'password':
        if (!value) {
          errors.password = 'Password wajib diisi';
        } else if (value.length < 8) {
          errors.password = 'Password minimal 8 karakter';
        } else if (!/(?=.*[a-zA-Z])(?=.*[0-9])/.test(value)) {
          errors.password = 'Password harus kombinasi huruf dan angka';
        } else {
          delete errors.password;
        }
        // Also recheck confirm password if already entered
        if (regConfirmPassword && value !== regConfirmPassword) {
          errors.confirmPassword = 'Konfirmasi password tidak cocok';
        } else if (regConfirmPassword && value === regConfirmPassword) {
          delete errors.confirmPassword;
        }
        break;
      case 'confirmPassword':
        if (!value) {
          errors.confirmPassword = 'Ulangi password wajib diisi';
        } else if (value !== regPassword) {
          errors.confirmPassword = 'Konfirmasi password tidak cocok';
        } else {
          delete errors.confirmPassword;
        }
        break;
    }

    setFieldErrors(errors);
  };

  const handlePhoneChange = (val: string) => {
    // Only allow numbers and optional plus sign at start
    const cleaned = val.replace(/[^\d+]/g, '');
    setRegPhone(cleaned);
    validateField('phone', cleaned);
    setErrorMsg(null);
  };

  const handleUsernameChange = (val: string) => {
    // No spaces allowed
    const cleaned = val.replace(/\s+/g, '');
    setRegUsername(cleaned);
    validateField('username', cleaned);
    setErrorMsg(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (lockoutSeconds && lockoutSeconds > 0) return;

    setErrorMsg(null);
    setSuccessMsg(null);

    // If Registration Mode: Validate all 6 fields on client side
    if (isRegisterMode) {
      const errors: { [key: string]: string } = {};

      if (!regName.trim() || regName.trim().length < 3) {
        errors.name = 'Nama lengkap wajib diisi (minimal 3 karakter)';
      }

      const phoneDigits = regPhone.replace(/\D/g, '');
      if (!phoneDigits || (!/^(08|628)[0-9]{8,13}$/.test(phoneDigits) && !(phoneDigits.startsWith('8') && phoneDigits.length >= 9))) {
        errors.phone = 'Nomor HP harus valid (contoh: 08xxxxxxxxxx)';
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!regEmail.trim() || !emailRegex.test(regEmail.trim())) {
        errors.email = 'Format email tidak valid';
      }

      const cleanUser = regUsername.replace(/^@/, '').trim();
      if (!cleanUser || cleanUser.length < 4 || !/^[a-zA-Z0-9._]+$/.test(cleanUser)) {
        errors.username = 'Username minimal 4 karakter (hanya huruf, angka, titik, underscore)';
      }

      if (!regPassword || regPassword.length < 8 || !/(?=.*[a-zA-Z])(?=.*[0-9])/.test(regPassword)) {
        errors.password = 'Password minimal 8 karakter dan kombinasi huruf & angka';
      }

      if (!regConfirmPassword || regPassword !== regConfirmPassword) {
        errors.confirmPassword = 'Konfirmasi password tidak cocok';
      }

      if (Object.keys(errors).length > 0) {
        setFieldErrors(errors);
        setErrorMsg('Silakan lengkapi dan periksa kembali data pendaftaran Anda.');
        return;
      }
    } else {
      if (!loginIdentifier.trim()) {
        setErrorMsg('Nomor HP, Email, atau Username wajib diisi.');
        return;
      }
      if (!loginPassword) {
        setErrorMsg('Password wajib diisi.');
        return;
      }
    }

    setIsLoading(true);

    try {
      const endpoint = isRegisterMode ? '/api/auth/register' : '/api/auth/login';
      const bodyPayload = isRegisterMode
        ? {
            name: regName.trim(),
            phone: regPhone.trim(),
            email: regEmail.trim().toLowerCase(),
            username: regUsername.trim(),
            password: regPassword,
            confirmPassword: regConfirmPassword,
          }
        : {
            identifier: loginIdentifier.trim(),
            password: loginPassword,
            rememberMe,
            challengeId: challengeData?.id,
            challengeAnswer: challengeAnswer.trim(),
          };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bodyPayload),
      });

      const rawText = await res.text();
      let data: any = {};
      try {
        data = JSON.parse(rawText);
      } catch (parseErr) {
        console.warn('Non-JSON response from auth endpoint:', rawText.slice(0, 80));
        data = { success: false, error: 'Terjadi gangguan server. Silakan coba beberapa saat lagi.' };
      }

      if (res.ok && data.success) {
        if (isRegisterMode) {
          // Registration Success: Show notification & switch to Login mode
          setSuccessMsg('Akun berhasil dibuat! Silakan masuk dengan akun baru Anda.');
          // Pre-fill username/email in login form
          setLoginIdentifier(regUsername.trim() || regEmail.trim());
          setLoginPassword('');
          // Clear registration form
          setRegName('');
          setRegPhone('');
          setRegEmail('');
          setRegUsername('');
          setRegPassword('');
          setRegConfirmPassword('');
          setFieldErrors({});

          // Switch to Login screen after short delay
          setTimeout(() => {
            setIsRegisterMode(false);
          }, 1500);
        } else {
          // Login Success
          if (data.token) {
            localStorage.setItem('topay_auth_token', data.token);
            sessionStorage.setItem('topay_auth_token', data.token);
          }
          if (data.user) {
            localStorage.setItem('topay_user_profile', JSON.stringify(data.user));
          }
          onLoginSuccess(data.user, data.token);
        }
      } else {
        if (data.isLocked) {
          setLockoutSeconds(data.remainingSeconds || 900);
        }
        if (data.remainingAttempts !== undefined) {
          setRemainingAttempts(data.remainingAttempts);
        }
        if (data.requireChallenge && data.challenge) {
          setRequiresChallenge(true);
          setChallengeData(data.challenge);
        }
        setErrorMsg(data.error || 'Autentikasi gagal. Silakan periksa kembali data Anda.');
      }
    } catch (err: any) {
      console.error('API auth error:', err);
      setErrorMsg('Gagal terhubung ke server. Periksa koneksi internet Anda dan coba lagi.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      className={`min-h-screen flex flex-col transition-colors relative ${
        isDarkMode ? 'bg-[#0A1610] text-white' : 'bg-[#F5F9F6] text-gray-900'
      }`}
    >
      {/* Background eco-glow subtle circles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-32 -left-32 w-80 h-80 rounded-full bg-[#6BCB37]/10 blur-3xl" />
        <div className="absolute -bottom-32 -right-32 w-80 h-80 rounded-full bg-[#113C2B]/10 blur-3xl" />
      </div>

      {/* Semantic Public Header & Internal Navigation */}
      <header className="relative z-10 w-full max-w-5xl mx-auto px-4 sm:px-6 pt-4 pb-2 flex items-center justify-between gap-6">
        <a
          href="/"
          onClick={(e) => {
            if (onNavigate) {
              e.preventDefault();
              onNavigate('/');
            }
          }}
          className="inline-flex items-center mr-4 sm:mr-8 shrink-0"
          aria-label="Beranda TO PAY"
        >
          {!headerLogoFailed ? (
            <img
              src={BRAND_LOGO_SRC}
              alt="TO PAY Logo"
              onError={() => setHeaderLogoFailed(true)}
              className={`h-11 sm:h-12 w-auto object-contain transition-transform duration-200 hover:scale-105 ${
                isDarkMode
                  ? 'bg-white/95 rounded-xl px-2 py-1'
                  : 'mix-blend-multiply'
              }`}
            />
          ) : (
            <ToPayLogo size="sm" showText={true} showTagline={false} variant={isDarkMode ? 'white' : 'default'} />
          )}
        </a>

        <nav aria-label="Menu Informasi Publik" className="flex items-center gap-4 sm:gap-7 text-xs sm:text-sm font-semibold">
          <a
            href="/layanan"
            onClick={(e) => {
              if (onNavigate) {
                e.preventDefault();
                onNavigate('/layanan', 'layanan');
              }
            }}
            className="text-gray-700 hover:text-[#113C2B] dark:text-gray-300 dark:hover:text-[#6BCB37] hover:underline underline-offset-4 transition-colors whitespace-nowrap"
          >
            Layanan
          </a>
          <a
            href="/promo"
            onClick={(e) => {
              if (onNavigate) {
                e.preventDefault();
                onNavigate('/promo', 'promo');
              }
            }}
            className="text-gray-700 hover:text-[#113C2B] dark:text-gray-300 dark:hover:text-[#6BCB37] hover:underline underline-offset-4 transition-colors whitespace-nowrap"
          >
            Promo
          </a>
          <a
            href="/keamanan"
            onClick={(e) => {
              if (onNavigate) {
                e.preventDefault();
                onNavigate('/keamanan', 'keamanan');
              }
            }}
            className="text-gray-700 hover:text-[#113C2B] dark:text-gray-300 dark:hover:text-[#6BCB37] hover:underline underline-offset-4 transition-colors whitespace-nowrap"
          >
            Keamanan
          </a>
          <a
            href="/faq"
            onClick={(e) => {
              if (onNavigate) {
                e.preventDefault();
                onNavigate('/faq', 'faq');
              }
            }}
            className="text-gray-700 hover:text-[#113C2B] dark:text-gray-300 dark:hover:text-[#6BCB37] hover:underline underline-offset-4 transition-colors whitespace-nowrap"
          >
            FAQ
          </a>
        </nav>
      </header>

      <main className="relative z-10 flex-1 flex items-center justify-center p-4 sm:p-6 min-h-[calc(100vh-5rem)]">
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className={`relative w-full max-w-lg rounded-3xl p-6 sm:p-9 border my-4 transition-all ${
            isDarkMode
              ? 'bg-[#12281E] border-[#1E4330] shadow-2xl'
              : 'bg-white border-gray-200/90 shadow-[0_18px_45px_-14px_rgba(17,60,43,0.14)]'
          }`}
        >
        {/* Top Centered Official Logo (No enclosing background box in light mode) */}
        <div className="flex flex-col items-center text-center mb-6">
          {!cardLogoFailed ? (
            <img
              src={BRAND_LOGO_SRC}
              alt="TO PAY Logo"
              onError={() => setCardLogoFailed(true)}
              className={`w-32 h-auto object-contain mx-auto mb-3.5 ${
                isDarkMode
                  ? 'bg-white/95 rounded-2xl p-2.5'
                  : 'mix-blend-multiply'
              }`}
            />
          ) : (
            <div className="mb-3.5">
              <ToPayLogo size="lg" showText={true} variant={isDarkMode ? 'white' : 'default'} />
            </div>
          )}
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white text-balance">
            {isRegisterMode ? 'Daftar Akun Baru' : 'Selamat Datang di TO PAY'}
          </h1>
          <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mt-1.5 max-w-sm leading-relaxed">
            {isRegisterMode
              ? 'Lengkapi seluruh data di bawah untuk membuat akun dompet digital TO PAY Anda.'
              : 'Dompet digital ramah lingkungan berstandar keamanan tinggi Bank Indonesia.'}
          </p>
        </div>

        {/* Lockout Warning Banner */}
        {lockoutSeconds !== null && lockoutSeconds > 0 && (
          <div className="mb-4 p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-xs text-amber-800 dark:text-amber-300 flex items-start gap-2.5">
            <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Akses Login Ditangguhkan Sementara</p>
              <p className="mt-0.5">
                Terlalu banyak percobaan gagal. Silakan tunggu{' '}
                <span className="font-mono font-bold text-amber-700 dark:text-amber-200">
                  {Math.floor(lockoutSeconds / 60)}:{(lockoutSeconds % 60).toString().padStart(2, '0')}
                </span>{' '}
                sebelum mencoba kembali.
              </p>
            </div>
          </div>
        )}

        {/* Success Alert */}
        <AnimatePresence>
          {successMsg && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-4 p-3.5 rounded-xl bg-emerald-50 dark:bg-[#1A3828] border border-emerald-300 dark:border-[#224E38] text-xs text-emerald-800 dark:text-[#6BCB37] flex items-center gap-2.5"
            >
              <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600 dark:text-[#6BCB37]" />
              <span className="font-bold">{successMsg}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Error Notification */}
        {errorMsg && (!lockoutSeconds || lockoutSeconds <= 0) && (
          <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
            {remainingAttempts !== null && remainingAttempts > 0 && (
              <span className="px-2 py-0.5 rounded-md bg-rose-200 dark:bg-rose-900 font-bold whitespace-nowrap text-[10px]">
                Sisa {remainingAttempts}x
              </span>
            )}
          </div>
        )}

        {/* Form Container */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* ================= REGISTER FIELDS (6 DISTINCT FIELDS) ================= */}
          {isRegisterMode ? (
            <>
              {/* 1. Nama Lengkap */}
              <div>
                <label className="block text-xs font-bold text-gray-800 dark:text-gray-200 mb-1.5">
                  Nama Lengkap <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <User className="w-4 h-4 text-[#113C2B] dark:text-[#6BCB37]" />
                  </div>
                  <input
                    type="text"
                    value={regName}
                    onChange={(e) => {
                      setRegName(e.target.value);
                      validateField('name', e.target.value);
                      setErrorMsg(null);
                    }}
                    placeholder="Masukkan nama lengkap"
                    required
                    disabled={isLoading}
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm transition-all focus:outline-none ${
                      fieldErrors.name
                        ? 'border-rose-400 bg-rose-50/50 dark:bg-rose-950/20 focus:ring-2 focus:ring-rose-400/30'
                        : isDarkMode
                        ? 'bg-[#0A1610] border-[#24523A] text-white placeholder:text-gray-500 focus:border-[#6BCB37] focus:ring-2 focus:ring-[#6BCB37]/25'
                        : 'bg-white border-gray-300 text-gray-900 placeholder:text-gray-400 focus:border-[#113C2B] focus:ring-2 focus:ring-[#113C2B]/20'
                    }`}
                  />
                </div>
                {fieldErrors.name && (
                  <p className="text-[11px] text-rose-600 mt-1 font-medium">{fieldErrors.name}</p>
                )}
              </div>

              {/* 2. Nomor HP */}
              <div>
                <label className="block text-xs font-bold text-gray-800 dark:text-gray-200 mb-1.5">
                  Nomor HP <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Phone className="w-4 h-4 text-[#113C2B] dark:text-[#6BCB37]" />
                  </div>
                  <input
                    type="tel"
                    value={regPhone}
                    onChange={(e) => handlePhoneChange(e.target.value)}
                    placeholder="08xxxxxxxxxx"
                    required
                    disabled={isLoading}
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm transition-all focus:outline-none ${
                      fieldErrors.phone
                        ? 'border-rose-400 bg-rose-50/50 dark:bg-rose-950/20 focus:ring-2 focus:ring-rose-400/30'
                        : isDarkMode
                        ? 'bg-[#0A1610] border-[#24523A] text-white placeholder:text-gray-500 focus:border-[#6BCB37] focus:ring-2 focus:ring-[#6BCB37]/25'
                        : 'bg-white border-gray-300 text-gray-900 placeholder:text-gray-400 focus:border-[#113C2B] focus:ring-2 focus:ring-[#113C2B]/20'
                    }`}
                  />
                </div>
                {fieldErrors.phone && (
                  <p className="text-[11px] text-rose-600 mt-1 font-medium">{fieldErrors.phone}</p>
                )}
              </div>

              {/* 3. Email */}
              <div>
                <label className="block text-xs font-bold text-gray-800 dark:text-gray-200 mb-1.5">
                  Email <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Mail className="w-4 h-4 text-[#113C2B] dark:text-[#6BCB37]" />
                  </div>
                  <input
                    type="email"
                    value={regEmail}
                    onChange={(e) => {
                      setRegEmail(e.target.value);
                      validateField('email', e.target.value);
                      setErrorMsg(null);
                    }}
                    placeholder="contoh@email.com"
                    required
                    disabled={isLoading}
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm transition-all focus:outline-none ${
                      fieldErrors.email
                        ? 'border-rose-400 bg-rose-50/50 dark:bg-rose-950/20 focus:ring-2 focus:ring-rose-400/30'
                        : isDarkMode
                        ? 'bg-[#0A1610] border-[#24523A] text-white placeholder:text-gray-500 focus:border-[#6BCB37] focus:ring-2 focus:ring-[#6BCB37]/25'
                        : 'bg-white border-gray-300 text-gray-900 placeholder:text-gray-400 focus:border-[#113C2B] focus:ring-2 focus:ring-[#113C2B]/20'
                    }`}
                  />
                </div>
                {fieldErrors.email && (
                  <p className="text-[11px] text-rose-600 mt-1 font-medium">{fieldErrors.email}</p>
                )}
              </div>

              {/* 4. Username */}
              <div>
                <label className="block text-xs font-bold text-gray-800 dark:text-gray-200 mb-1.5">
                  Username <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <AtSign className="w-4 h-4 text-[#113C2B] dark:text-[#6BCB37]" />
                  </div>
                  <input
                    type="text"
                    value={regUsername}
                    onChange={(e) => handleUsernameChange(e.target.value)}
                    placeholder="Masukkan username"
                    required
                    disabled={isLoading}
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm transition-all focus:outline-none ${
                      fieldErrors.username
                        ? 'border-rose-400 bg-rose-50/50 dark:bg-rose-950/20 focus:ring-2 focus:ring-rose-400/30'
                        : isDarkMode
                        ? 'bg-[#0A1610] border-[#24523A] text-white placeholder:text-gray-500 focus:border-[#6BCB37] focus:ring-2 focus:ring-[#6BCB37]/25'
                        : 'bg-white border-gray-300 text-gray-900 placeholder:text-gray-400 focus:border-[#113C2B] focus:ring-2 focus:ring-[#113C2B]/20'
                    }`}
                  />
                </div>
                {fieldErrors.username ? (
                  <p className="text-[11px] text-rose-600 mt-1 font-medium">{fieldErrors.username}</p>
                ) : (
                  <p className="text-[11px] text-gray-500 dark:text-gray-400 mt-1">
                    Minimal 4 karakter (huruf, angka, titik, atau underscore tanpa spasi).
                  </p>
                )}
              </div>

              {/* 5. Password */}
              <div>
                <label className="block text-xs font-bold text-gray-800 dark:text-gray-200 mb-1.5">
                  Password <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Lock className="w-4 h-4 text-[#113C2B] dark:text-[#6BCB37]" />
                  </div>
                  <input
                    type={showRegPassword ? 'text' : 'password'}
                    value={regPassword}
                    onChange={(e) => {
                      setRegPassword(e.target.value);
                      validateField('password', e.target.value);
                      setErrorMsg(null);
                    }}
                    placeholder="Masukkan password"
                    required
                    disabled={isLoading}
                    className={`w-full pl-10 pr-10 py-2.5 rounded-xl border text-sm transition-all focus:outline-none ${
                      fieldErrors.password
                        ? 'border-rose-400 bg-rose-50/50 dark:bg-rose-950/20 focus:ring-2 focus:ring-rose-400/30'
                        : isDarkMode
                        ? 'bg-[#0A1610] border-[#24523A] text-white placeholder:text-gray-500 focus:border-[#6BCB37] focus:ring-2 focus:ring-[#6BCB37]/25'
                        : 'bg-white border-gray-300 text-gray-900 placeholder:text-gray-400 focus:border-[#113C2B] focus:ring-2 focus:ring-[#113C2B]/20'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegPassword(!showRegPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-500 hover:text-gray-800 dark:hover:text-gray-200 cursor-pointer"
                  >
                    {showRegPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {fieldErrors.password ? (
                  <p className="text-[11px] text-rose-600 mt-1 font-medium">{fieldErrors.password}</p>
                ) : (
                  <p className="text-[11px] text-gray-500 dark:text-gray-400 mt-1">
                    Minimal 8 karakter dan mengandung kombinasi huruf dan angka.
                  </p>
                )}
              </div>

              {/* 6. Konfirmasi Password */}
              <div>
                <label className="block text-xs font-bold text-gray-800 dark:text-gray-200 mb-1.5">
                  Konfirmasi Password <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Lock className="w-4 h-4 text-[#113C2B] dark:text-[#6BCB37]" />
                  </div>
                  <input
                    type={showRegConfirmPassword ? 'text' : 'password'}
                    value={regConfirmPassword}
                    onChange={(e) => {
                      setRegConfirmPassword(e.target.value);
                      validateField('confirmPassword', e.target.value);
                      setErrorMsg(null);
                    }}
                    placeholder="Ulangi password"
                    required
                    disabled={isLoading}
                    className={`w-full pl-10 pr-10 py-2.5 rounded-xl border text-sm transition-all focus:outline-none ${
                      fieldErrors.confirmPassword
                        ? 'border-rose-400 bg-rose-50/50 dark:bg-rose-950/20 focus:ring-2 focus:ring-rose-400/30'
                        : isDarkMode
                        ? 'bg-[#0A1610] border-[#24523A] text-white placeholder:text-gray-500 focus:border-[#6BCB37] focus:ring-2 focus:ring-[#6BCB37]/25'
                        : 'bg-white border-gray-300 text-gray-900 placeholder:text-gray-400 focus:border-[#113C2B] focus:ring-2 focus:ring-[#113C2B]/20'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegConfirmPassword(!showRegConfirmPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-500 hover:text-gray-800 dark:hover:text-gray-200 cursor-pointer"
                  >
                    {showRegConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {fieldErrors.confirmPassword && (
                  <p className="text-[11px] text-rose-600 mt-1 font-medium">{fieldErrors.confirmPassword}</p>
                )}
              </div>
            </>
          ) : (
            /* ================= LOGIN FIELDS ================= */
            <>
              <div>
                <label className="block text-xs font-bold text-gray-800 dark:text-gray-200 mb-1.5">
                  Nomor HP, Email, atau Username
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <User className="w-4 h-4 text-[#113C2B] dark:text-[#6BCB37]" />
                  </div>
                  <input
                    type="text"
                    value={loginIdentifier}
                    onChange={(e) => {
                      setLoginIdentifier(e.target.value);
                      setErrorMsg(null);
                    }}
                    placeholder="Nomor HP, Email, atau Username"
                    required
                    disabled={isLoading}
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm transition-all focus:outline-none ${
                      isDarkMode
                        ? 'bg-[#0A1610] border-[#24523A] text-white placeholder:text-gray-500 focus:border-[#6BCB37] focus:ring-2 focus:ring-[#6BCB37]/25'
                        : 'bg-white border-gray-300 text-gray-900 placeholder:text-gray-400 focus:border-[#113C2B] focus:ring-2 focus:ring-[#113C2B]/20'
                    }`}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-xs font-bold text-gray-800 dark:text-gray-200">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => setErrorMsg('Silakan hubungi customer service untuk reset password atau gunakan akun terdaftar Anda.')}
                    className="text-xs font-semibold text-[#113C2B] dark:text-[#6BCB37] hover:underline cursor-pointer"
                  >
                    Lupa Password?
                  </button>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Lock className="w-4 h-4 text-[#113C2B] dark:text-[#6BCB37]" />
                  </div>
                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={(e) => {
                      setLoginPassword(e.target.value);
                      setErrorMsg(null);
                    }}
                    placeholder="Masukkan password"
                    required
                    disabled={isLoading}
                    className={`w-full pl-10 pr-10 py-2.5 rounded-xl border text-sm transition-all focus:outline-none ${
                      isDarkMode
                        ? 'bg-[#0A1610] border-[#24523A] text-white placeholder:text-gray-500 focus:border-[#6BCB37] focus:ring-2 focus:ring-[#6BCB37]/25'
                        : 'bg-white border-gray-300 text-gray-900 placeholder:text-gray-400 focus:border-[#113C2B] focus:ring-2 focus:ring-[#113C2B]/20'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-500 hover:text-gray-800 dark:hover:text-gray-200 cursor-pointer"
                  >
                    {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* CAPTCHA / Security Challenge Section if triggered */}
              {requiresChallenge && challengeData && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-emerald-950 dark:text-emerald-200 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-[#113C2B] dark:text-[#6BCB37]" />
                      Verifikasi Keamanan (Challenge)
                    </label>
                    <button
                      type="button"
                      onClick={fetchNewChallenge}
                      className="text-[11px] font-semibold text-[#113C2B] dark:text-[#6BCB37] hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" /> Ganti Soal
                    </button>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="px-3 py-2 rounded-lg bg-white dark:bg-black/40 border border-emerald-200 dark:border-emerald-700 font-mono font-bold text-sm tracking-wider text-gray-900 dark:text-white">
                      {challengeData.question}
                    </div>
                    <input
                      type="number"
                      value={challengeAnswer}
                      onChange={(e) => setChallengeAnswer(e.target.value)}
                      placeholder="Jawaban"
                      required
                      className={`w-full px-3 py-2 rounded-lg border text-sm font-bold focus:outline-none ${
                        isDarkMode
                          ? 'bg-[#0A1610] border-[#24523A] text-white focus:border-[#6BCB37] focus:ring-2 focus:ring-[#6BCB37]/25'
                          : 'bg-white border-gray-300 text-gray-900 placeholder:text-gray-400 focus:border-[#113C2B] focus:ring-2 focus:ring-[#113C2B]/20'
                      }`}
                    />
                  </div>
                </motion.div>
              )}

              {/* Remember Me */}
              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 text-gray-700 dark:text-gray-300 font-medium cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded border-gray-300 text-[#113C2B] focus:ring-[#113C2B] accent-[#113C2B] w-4 h-4 cursor-pointer"
                  />
                  <span>Ingat akun saya di perangkat ini</span>
                </label>
              </div>
            </>
          )}

          {/* Primary Action Button */}
          <button
            type="submit"
            disabled={isLoading || (lockoutSeconds !== null && lockoutSeconds > 0)}
            className="w-full mt-4 py-3.5 px-5 rounded-xl bg-[#113C2B] hover:bg-[#0B291D] disabled:bg-gray-400 disabled:cursor-not-allowed text-white font-bold text-sm shadow-lg shadow-[#113C2B]/25 hover:shadow-xl hover:shadow-[#113C2B]/35 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : lockoutSeconds && lockoutSeconds > 0 ? (
              <span>Terkunci ({lockoutSeconds}s)</span>
            ) : (
              <>
                <span>{isRegisterMode ? 'Daftar Akun' : 'Masuk ke Akun'}</span>
                <ArrowRight className="w-4 h-4 text-[#6BCB37]" />
              </>
            )}
          </button>
        </form>

        {/* Toggle Register / Login */}
        <div className="mt-6 text-center pt-4 border-t border-gray-200 dark:border-gray-800">
          <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300">
            {isRegisterMode ? 'Sudah memiliki akun?' : 'Belum memiliki akun TO PAY?'}{' '}
            <button
              type="button"
              onClick={() => {
                setIsRegisterMode(!isRegisterMode);
                setErrorMsg(null);
                setSuccessMsg(null);
                setFieldErrors({});
                setRequiresChallenge(false);
              }}
              className="font-bold text-[#113C2B] dark:text-[#6BCB37] hover:underline cursor-pointer ml-1"
            >
              {isRegisterMode ? 'Masuk di sini' : 'Daftar Akun Baru'}
            </button>
          </p>
        </div>

        {/* Security badge */}
        <div className="mt-4 flex items-center justify-center gap-2 text-[11px] font-medium text-gray-500 dark:text-gray-400">
          <ShieldCheck className="w-3.5 h-3.5 text-[#113C2B] dark:text-[#6BCB37]" />
          <span>Enkripsi Salted PBKDF2 &amp; SHA-256 · Terdaftar Bank Indonesia</span>
        </div>
      </motion.div>
      </main>

      {/* Below-the-fold Public SEO Sections (Services, Eco Living, Security, FAQ, Footer) */}
      <div className="relative z-10">
        <PublicSeoSections
          isDarkMode={isDarkMode}
          activeSection={activeSection}
          onNavigate={onNavigate}
          onOpenLegal={onOpenLegal}
        />
      </div>
    </div>
  );
};

