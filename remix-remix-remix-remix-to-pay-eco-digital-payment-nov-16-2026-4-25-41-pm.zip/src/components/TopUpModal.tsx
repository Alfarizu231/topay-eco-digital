import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, PlusCircle, Building2, QrCode, Store, Check, Copy, Sparkles, ShieldCheck } from 'lucide-react';

interface TopUpModalProps {
  onClose: () => void;
  onTopUpSuccess: (amount: number, method: string) => void;
  isDarkMode?: boolean;
}

export const TopUpModal: React.FC<TopUpModalProps> = ({
  onClose,
  onTopUpSuccess,
  isDarkMode = false,
}) => {
  const [selectedMethod, setSelectedMethod] = useState<'bca' | 'mandiri' | 'bri' | 'qris' | 'retail'>('bca');
  const [amount, setAmount] = useState<number>(200000);
  const [customAmount, setCustomAmount] = useState('');
  const [isCustom, setIsCustom] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const methods = [
    { id: 'bca', name: 'BCA Virtual Account', icon: Building2, code: '8091 081298765432' },
    { id: 'mandiri', name: 'Mandiri Virtual Account', icon: Building2, code: '8870 081298765432' },
    { id: 'bri', name: 'BRI BRIVA', icon: Building2, code: '1289 081298765432' },
    { id: 'qris', name: 'QRIS Instan', icon: QrCode, code: 'Scan QRIS TO PAY' },
    { id: 'retail', name: 'Alfamart / Indomaret', icon: Store, code: 'TOPAY-9921-8812' },
  ];

  const presetAmounts = [50000, 100000, 200000, 500000, 1000000, 2000000];
  const activeMethodObj = methods.find((m) => m.id === selectedMethod) || methods[0];
  const finalAmount = isCustom ? Number(customAmount) || 0 : amount;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(activeMethodObj.code);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleFinish = () => {
    if (finalAmount < 10000) {
      setErrorMsg('Minimal top up saldo adalah Rp10.000.');
      return;
    }
    setErrorMsg(null);
    onTopUpSuccess(finalAmount, activeMethodObj.name);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className={`w-full max-w-lg rounded-2xl p-5 sm:p-6 shadow-2xl border ${
          isDarkMode ? 'bg-[#12281E] border-[#1E4330] text-white' : 'bg-white border-[#E2ECE5] text-[#0F2D1F]'
        }`}
      >
        <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800">
          <div>
            <h2 className="text-lg font-bold text-[#143D28] dark:text-white">
              Top Up Saldo TO PAY
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Pilih metode transfer atau pembayaran instan
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-4 max-h-[75vh] overflow-y-auto pr-1">
          {/* Method Picker */}
          <div>
            <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1.5">
              Metode Pembayaran
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {methods.map((m) => {
                const Icon = m.icon;
                const isSelected = m.id === selectedMethod;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setSelectedMethod(m.id as any)}
                    className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition-all cursor-pointer ${
                      isSelected
                        ? isDarkMode
                          ? 'bg-[#1A3D2A] border-[#6BCB37] text-white font-bold'
                          : 'bg-[#EAF6EE] border-[#143D28] text-[#143D28] font-bold shadow-xs'
                        : isDarkMode
                          ? 'bg-[#0A1610] border-[#1E4330] text-gray-300'
                          : 'bg-white border-[#E2ECE5] text-gray-700 hover:bg-[#F9FCFA]'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isSelected ? 'text-[#6BCB37]' : 'text-gray-400'}`} />
                    <span className="text-xs truncate">{m.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Virtual Account / Code Card */}
          <div className="p-3.5 rounded-xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330]">
            <div className="flex justify-between items-center text-xs">
              <span className="text-gray-500 dark:text-gray-400">Nomor Rekening / Kode Bayar:</span>
              <button
                type="button"
                onClick={handleCopyCode}
                className="text-xs font-bold text-[#143D28] dark:text-[#6BCB37] flex items-center gap-1 hover:underline cursor-pointer"
              >
                {isCopied ? <Check className="w-3 h-3 text-[#16A34A]" /> : <Copy className="w-3 h-3" />}
                {isCopied ? 'Tersalin' : 'Salin Kode'}
              </button>
            </div>
            <div className="text-base sm:text-lg font-mono font-black text-[#143D28] dark:text-white mt-1">
              {activeMethodObj.code}
            </div>
          </div>

          {/* Amount Selection */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-xs font-bold text-[#143D28] dark:text-gray-200">
                Pilih Nominal Top Up
              </label>
              <button
                type="button"
                onClick={() => setIsCustom(!isCustom)}
                className="text-xs font-semibold text-[#143D28] dark:text-[#6BCB37] hover:underline cursor-pointer"
              >
                {isCustom ? 'Gunakan Pilihan Cepat' : 'Ketik Nominal Lain'}
              </button>
            </div>

            {isCustom ? (
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-sm font-bold text-gray-500">
                  Rp
                </span>
                <input
                  type="number"
                  value={customAmount}
                  onChange={(e) => {
                    setCustomAmount(e.target.value);
                    if (errorMsg) setErrorMsg(null);
                  }}
                  placeholder="Contoh: 350000"
                  className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm font-bold focus:outline-none focus:ring-2 focus:ring-[#6BCB37] ${
                    isDarkMode
                      ? 'bg-[#0A1610] border-[#1E4330] text-white'
                      : 'bg-[#F4FAF6] border-[#D7EFE0] text-[#0F2D1F]'
                  }`}
                />
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-2">
                {presetAmounts.map((amt) => {
                  const isSelected = amount === amt;
                  return (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => {
                        setAmount(amt);
                        setIsCustom(false);
                        if (errorMsg) setErrorMsg(null);
                      }}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        isSelected
                          ? isDarkMode
                            ? 'bg-[#1A3D2A] border-[#6BCB37] text-white font-bold'
                            : 'bg-[#EAF6EE] border-[#143D28] text-[#143D28] font-bold shadow-xs'
                          : isDarkMode
                            ? 'bg-[#0A1610] border-[#1E4330] text-gray-300'
                            : 'bg-white border-[#E2ECE5] text-gray-700 hover:bg-[#F9FCFA]'
                      }`}
                    >
                      <div className="text-xs sm:text-sm font-bold">
                        Rp{amt.toLocaleString('id-ID')}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="p-3 rounded-xl bg-[#F0FAF3] dark:bg-[#1A3828] border border-[#D7EFE0] dark:border-[#204E38] flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-[#143D28] dark:text-[#A3E635]">
              <Sparkles className="w-3.5 h-3.5 text-[#6BCB37]" />
              <span>Bebas Biaya Admin</span>
            </div>
            <span className="font-bold text-[#143D28] dark:text-[#6BCB37]">Rp0</span>
          </div>

          {errorMsg && (
            <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-xs font-semibold text-rose-700 dark:text-rose-200">
              {errorMsg}
            </div>
          )}

          <button
            type="button"
            onClick={handleFinish}
            className="w-full py-3 px-4 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
          >
            <span>Konfirmasi Top Up (Rp{finalAmount.toLocaleString('id-ID')})</span>
            <Check className="w-4 h-4 text-[#6BCB37]" />
          </button>
        </div>
      </motion.div>
    </div>
  );
};
