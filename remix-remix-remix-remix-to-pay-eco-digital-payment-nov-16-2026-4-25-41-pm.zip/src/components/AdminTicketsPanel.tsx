import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Ticket,
  Clock,
  RefreshCw,
  MessageSquare,
  CheckCircle2,
  Search,
  Filter,
  Send,
  X,
  User,
  Mail,
  Hash,
  Tag,
  Image as ImageIcon,
  Copy,
  Check,
  ShieldAlert,
  Loader2,
  Receipt,
} from 'lucide-react';
import { ComplaintTicket, TicketStatus, TicketSummaryStats } from '../types';
import { TicketPriorityBadge, TicketStatusBadge } from './TicketBadges';

interface AdminTicketsPanelProps {
  fetchWithAuth: (url: string, options?: RequestInit) => Promise<Response>;
  showToast: (text: string, type?: 'success' | 'error' | 'info') => void;
}

const TICKET_CATEGORIES = [
  'Top Up',
  'QRIS',
  'Transfer',
  'E-Wallet',
  'Tagihan & Pulsa',
  'Akun & Keamanan',
  'Lainnya',
];

const TICKET_STATUSES: TicketStatus[] = ['Menunggu', 'Diproses', 'Tunggu User', 'Selesai'];

export const AdminTicketsPanel: React.FC<AdminTicketsPanelProps> = ({
  fetchWithAuth,
  showToast,
}) => {
  const [tickets, setTickets] = useState<ComplaintTicket[]>([]);
  const [summary, setSummary] = useState<TicketSummaryStats>({
    total: 0,
    menunggu: 0,
    diproses: 0,
    tungguUser: 0,
    selesai: 0,
  });
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  // Detail & Reply Modal State
  const [selectedTicket, setSelectedTicket] = useState<ComplaintTicket | null>(null);
  const [relatedOrder, setRelatedOrder] = useState<any | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [replyMessage, setReplyMessage] = useState('');
  const [replyNextStatus, setReplyNextStatus] = useState<TicketStatus>('Tunggu User');
  const [sendingReply, setSendingReply] = useState(false);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [copiedOrderId, setCopiedOrderId] = useState<string | null>(null);

  const loadTickets = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchQuery.trim()) params.set('search', searchQuery.trim());
      if (statusFilter !== 'all') params.set('status', statusFilter);
      if (priorityFilter !== 'all') params.set('priority', priorityFilter);
      if (categoryFilter !== 'all') params.set('category', categoryFilter);

      const res = await fetchWithAuth(`/api/admin/tickets?${params.toString()}`);
      const data = await res.json();
      if (res.ok && data.success) {
        setTickets(data.tickets || []);
        if (data.summary) setSummary(data.summary);
      } else {
        showToast(data.error || 'Gagal memuat daftar tiket pengaduan.', 'error');
      }
    } catch (err) {
      console.error('Load admin tickets error:', err);
      showToast('Gagal terhubung ke server tiket CS.', 'error');
    } finally {
      setLoading(false);
    }
  }, [fetchWithAuth, searchQuery, statusFilter, priorityFilter, categoryFilter, showToast]);

  useEffect(() => {
    const timer = setTimeout(() => {
      loadTickets();
    }, 180);
    return () => clearTimeout(timer);
  }, [loadTickets]);

  const openTicketDetail = async (ticketId: string) => {
    setDetailLoading(true);
    setReplyMessage('');
    setReplyNextStatus('Tunggu User');
    try {
      const res = await fetchWithAuth(`/api/admin/tickets/${ticketId}`);
      const data = await res.json();
      if (res.ok && data.success && data.ticket) {
        setSelectedTicket(data.ticket);
        setRelatedOrder(data.relatedOrder || null);
      } else {
        showToast(data.error || 'Gagal memuat detail tiket.', 'error');
      }
    } catch {
      showToast('Gagal mengambil detail tiket.', 'error');
    } finally {
      setDetailLoading(false);
    }
  };

  const handleStatusChange = async (newStatus: TicketStatus) => {
    if (!selectedTicket) return;
    setUpdatingStatus(true);
    try {
      const res = await fetchWithAuth(`/api/admin/tickets/${selectedTicket.id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: newStatus }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setSelectedTicket((prev) => (prev ? { ...prev, status: newStatus, updatedFormatted: data.ticket?.updatedFormatted } : null));
        showToast(data.message || `Status tiket diperbarui ke ${newStatus}.`, 'success');
        loadTickets();
      } else {
        showToast(data.error || 'Gagal mengubah status tiket.', 'error');
      }
    } catch {
      showToast('Kendala jaringan saat mengubah status tiket.', 'error');
    } finally {
      setUpdatingStatus(false);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !replyMessage.trim()) return;
    setSendingReply(true);
    try {
      const res = await fetchWithAuth(`/api/admin/tickets/${selectedTicket.id}/reply`, {
        method: 'POST',
        body: JSON.stringify({
          message: replyMessage.trim(),
          nextStatus: replyNextStatus,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success && data.ticket) {
        setSelectedTicket(data.ticket);
        setReplyMessage('');
        showToast(`Balasan CS terkirim. Status tiket: ${data.ticket.status}`, 'success');
        loadTickets();
      } else {
        showToast(data.error || 'Gagal mengirim balasan CS.', 'error');
      }
    } catch {
      showToast('Kendala jaringan saat mengirim balasan.', 'error');
    } finally {
      setSendingReply(false);
    }
  };

  const handleCopyOrder = (orderId: string) => {
    navigator.clipboard.writeText(orderId);
    setCopiedOrderId(orderId);
    setTimeout(() => setCopiedOrderId(null), 1800);
  };

  return (
    <div className="rounded-3xl bg-[#0B1612] border border-[#1E3A2F] text-slate-100 p-4 sm:p-6 shadow-2xl space-y-5">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#1E3A2F]">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-[#143D28] border border-[#6BCB37]/40 flex items-center justify-center shrink-0">
            <Ticket className="w-5 h-5 text-[#6BCB37]" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-white flex items-center gap-2">
              <span>Helpdesk &amp; Tiket Pengaduan CS</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#6BCB37]/15 text-[#6BCB37] border border-[#6BCB37]/30">
                Enterprise Live
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Pantau keluhan pelanggan, verifikasi ID Order, dan tanggapi tiket secara real-time
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={loadTickets}
          disabled={loading}
          className="self-start sm:self-auto px-3.5 py-2 rounded-xl bg-[#132920] hover:bg-[#19382B] border border-[#234A3B] text-xs font-bold text-[#6BCB37] flex items-center gap-1.5 cursor-pointer transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Muat Ulang Tiket</span>
        </button>
      </div>

      {/* 5 Summary Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <button
          type="button"
          onClick={() => setStatusFilter('all')}
          className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
            statusFilter === 'all'
              ? 'bg-[#132920] border-[#6BCB37]/60 ring-1 ring-[#6BCB37]/30'
              : 'bg-[#0F1E18] border-[#1E3A2F] hover:border-[#2C5444]'
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-extrabold tracking-wider text-slate-400 uppercase">
              TOTAL TIKET
            </span>
            <Ticket className="w-4 h-4 text-[#6BCB37]" />
          </div>
          <div className="text-2xl font-black text-white">{summary.total}</div>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('Menunggu')}
          className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
            statusFilter === 'Menunggu'
              ? 'bg-amber-950/40 border-amber-500/60 ring-1 ring-amber-500/30'
              : 'bg-[#0F1E18] border-[#1E3A2F] hover:border-amber-500/40'
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-extrabold tracking-wider text-amber-400 uppercase">
              MENUNGGU
            </span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-white">{summary.menunggu}</div>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('Diproses')}
          className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
            statusFilter === 'Diproses'
              ? 'bg-blue-950/40 border-blue-500/60 ring-1 ring-blue-500/30'
              : 'bg-[#0F1E18] border-[#1E3A2F] hover:border-blue-500/40'
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-extrabold tracking-wider text-blue-400 uppercase">
              DIPROSES
            </span>
            <RefreshCw className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-black text-white">{summary.diproses}</div>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('Tunggu User')}
          className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
            statusFilter === 'Tunggu User'
              ? 'bg-purple-950/40 border-purple-500/60 ring-1 ring-purple-500/30'
              : 'bg-[#0F1E18] border-[#1E3A2F] hover:border-purple-500/40'
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-extrabold tracking-wider text-purple-400 uppercase">
              TUNGGU USER
            </span>
            <MessageSquare className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-black text-white">{summary.tungguUser}</div>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('Selesai')}
          className={`col-span-2 sm:col-span-1 p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
            statusFilter === 'Selesai'
              ? 'bg-emerald-950/40 border-emerald-500/60 ring-1 ring-emerald-500/30'
              : 'bg-[#0F1E18] border-[#1E3A2F] hover:border-emerald-500/40'
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-extrabold tracking-wider text-emerald-400 uppercase">
              SELESAI
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-white">{summary.selesai}</div>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2.5 bg-[#0F1E18] p-3 rounded-2xl border border-[#1E3A2F]">
        <div className="lg:col-span-5 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari ID Tiket (TKT-...), ID Order, nama, atau pesan..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#09120E] border border-[#214234] text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#6BCB37]"
          />
        </div>

        <div className="lg:col-span-2">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            aria-label="Filter Kategori"
            className="w-full px-3 py-2 rounded-xl bg-[#09120E] border border-[#214234] text-xs text-slate-200 focus:outline-none focus:border-[#6BCB37]"
          >
            <option value="all">Semua Kategori</option>
            {TICKET_CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>

        <div className="lg:col-span-3">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            aria-label="Filter Status"
            className="w-full px-3 py-2 rounded-xl bg-[#09120E] border border-[#214234] text-xs text-slate-200 focus:outline-none focus:border-[#6BCB37]"
          >
            <option value="all">Semua Status</option>
            {TICKET_STATUSES.map((st) => (
              <option key={st} value={st}>
                {st}
              </option>
            ))}
          </select>
        </div>

        <div className="lg:col-span-2">
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            aria-label="Filter Prioritas"
            className="w-full px-3 py-2 rounded-xl bg-[#09120E] border border-[#214234] text-xs text-slate-200 focus:outline-none focus:border-[#6BCB37]"
          >
            <option value="all">Semua Prioritas</option>
            <option value="Tinggi">Tinggi</option>
            <option value="Sedang">Sedang</option>
            <option value="Rendah">Rendah</option>
          </select>
        </div>
      </div>

      {/* Tickets Table (Desktop) & Card List (Mobile-First) */}
      {loading ? (
        <div className="py-14 flex flex-col items-center justify-center text-slate-400 gap-2">
          <Loader2 className="w-7 h-7 animate-spin text-[#6BCB37]" />
          <span className="text-xs">Memuat data pengaduan CS...</span>
        </div>
      ) : tickets.length === 0 ? (
        <div className="py-14 text-center rounded-2xl bg-[#0F1E18] border border-[#1E3A2F]">
          <Filter className="w-9 h-9 text-slate-500 mx-auto mb-2" />
          <p className="text-sm font-bold text-slate-200">Tidak ada tiket pengaduan ditemukan</p>
          <p className="text-xs text-slate-400 mt-1">
            Ubah kata kunci pencarian atau reset filter untuk melihat semua tiket.
          </p>
        </div>
      ) : (
        <>
          {/* Mobile Cards View */}
          <div className="grid grid-cols-1 gap-3 lg:hidden">
            {tickets.map((t) => (
              <div
                key={t.id}
                className="p-4 rounded-2xl bg-[#0F1E18] border border-[#1E3A2F] space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="font-mono text-xs font-extrabold text-[#6BCB37]">
                      {t.ticket_code}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{t.dateFormatted}</div>
                  </div>
                  <TicketStatusBadge status={t.status} />
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                      {t.category}
                    </span>
                    <TicketPriorityBadge priority={t.priority} />
                  </div>
                  <h3 className="text-sm font-bold text-white leading-snug">{t.subject}</h3>
                </div>

                <div className="p-2.5 rounded-xl bg-[#09120E] border border-[#1E3A2F] flex items-center justify-between gap-2 text-xs">
                  <div>
                    <div className="text-[10px] text-slate-400">Pengguna</div>
                    <div className="font-bold text-slate-200">{t.user_name}</div>
                    <div className="text-[10px] text-slate-400">{t.user_email}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] text-slate-400">ID Order</div>
                    <div className="font-mono font-bold text-emerald-300">{t.order_id}</div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => openTicketDetail(t.id)}
                  className="w-full py-2.5 px-3 rounded-xl bg-[#143D28] hover:bg-[#1A4E34] text-white font-bold text-xs flex items-center justify-center gap-1.5 border border-[#6BCB37]/30 cursor-pointer transition-colors"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-[#6BCB37]" />
                  <span>Tanggapi &amp; Detail</span>
                </button>
              </div>
            ))}
          </div>

          {/* Desktop Enterprise Table View */}
          <div className="hidden lg:block overflow-x-auto rounded-2xl border border-[#1E3A2F] bg-[#0F1E18]">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#1E3A2F] bg-[#09120E] text-[11px] font-extrabold uppercase tracking-wider text-slate-400">
                  <th className="py-3.5 px-4">ID Tiket &amp; Waktu</th>
                  <th className="py-3.5 px-4">Pengguna / Akun</th>
                  <th className="py-3.5 px-4">Kategori &amp; Subjek</th>
                  <th className="py-3.5 px-4">ID Order</th>
                  <th className="py-3.5 px-4">Prioritas</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1A3329] text-xs">
                {tickets.map((t) => (
                  <tr key={t.id} className="hover:bg-[#13281F] transition-colors">
                    <td className="py-3.5 px-4 align-top whitespace-nowrap">
                      <div className="font-mono font-extrabold text-[#6BCB37]">{t.ticket_code}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">{t.dateFormatted}</div>
                    </td>

                    <td className="py-3.5 px-4 align-top">
                      <div className="font-bold text-white">{t.user_name}</div>
                      <div className="text-[11px] text-slate-400">{t.user_email}</div>
                    </td>

                    <td className="py-3.5 px-4 align-top max-w-xs">
                      <span className="inline-block px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700 mb-1">
                        {t.category}
                      </span>
                      <div className="font-semibold text-slate-100 line-clamp-2">{t.subject}</div>
                    </td>

                    <td className="py-3.5 px-4 align-top whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#09120E] border border-[#234A3B] font-mono text-[11px] font-bold text-emerald-300">
                        <span>{t.order_id}</span>
                        <button
                          type="button"
                          onClick={() => handleCopyOrder(t.order_id)}
                          className="text-slate-400 hover:text-white cursor-pointer"
                          title="Salin ID Order"
                        >
                          {copiedOrderId === t.order_id ? (
                            <Check className="w-3 h-3 text-[#6BCB37]" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 align-top whitespace-nowrap">
                      <TicketPriorityBadge priority={t.priority} />
                    </td>

                    <td className="py-3.5 px-4 align-top whitespace-nowrap">
                      <TicketStatusBadge status={t.status} />
                    </td>

                    <td className="py-3.5 px-4 align-top text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => openTicketDetail(t.id)}
                        className="px-3.5 py-2 rounded-xl bg-[#143D28] hover:bg-[#1B5136] text-white font-bold text-xs inline-flex items-center gap-1.5 border border-[#6BCB37]/30 shadow-xs cursor-pointer transition-colors"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-[#6BCB37]" />
                        <span>Tanggapi &amp; Detail</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* Modal: Tanggapi & Detail */}
      <AnimatePresence>
        {(selectedTicket || detailLoading) && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 12 }}
              className="w-full max-w-2xl rounded-3xl bg-[#0B1612] border border-[#234A3B] text-slate-100 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden"
            >
              {detailLoading || !selectedTicket ? (
                <div className="p-12 flex flex-col items-center justify-center gap-3">
                  <Loader2 className="w-8 h-8 animate-spin text-[#6BCB37]" />
                  <span className="text-xs text-slate-300">Memuat detail tiket &amp; riwayat chat...</span>
                </div>
              ) : (
                <>
                  {/* Modal Header */}
                  <div className="px-5 py-4 border-b border-[#1E3A2F] bg-[#0F1E18] flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className="font-mono text-xs font-black text-[#6BCB37]">
                          {selectedTicket.ticket_code}
                        </span>
                        <TicketPriorityBadge priority={selectedTicket.priority} />
                        <TicketStatusBadge status={selectedTicket.status} />
                      </div>
                      <h3 className="text-sm sm:text-base font-extrabold text-white leading-snug">
                        {selectedTicket.subject}
                      </h3>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSelectedTicket(null)}
                      className="p-1.5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white cursor-pointer"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Modal Body (Scrollable) */}
                  <div className="flex-1 overflow-y-auto p-5 space-y-4">
                    {/* Metadata Grid including Highlighted Order ID */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="p-3 rounded-2xl bg-[#0F1E18] border border-[#1E3A2F] space-y-1.5 text-xs">
                        <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
                          <User className="w-3.5 h-3.5 text-[#6BCB37]" />
                          <span>Pelanggan</span>
                        </div>
                        <div className="font-bold text-white">{selectedTicket.user_name}</div>
                        <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                          <Mail className="w-3 h-3" />
                          <span>{selectedTicket.user_email}</span>
                        </div>
                      </div>

                      <div className="p-3 rounded-2xl bg-[#11281E] border border-[#6BCB37]/30 space-y-1.5 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-emerald-300 text-[11px] font-bold">
                            <Hash className="w-3.5 h-3.5 text-[#6BCB37]" />
                            <span>ID Order / Transaksi Terkait</span>
                          </span>
                          <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-bold text-slate-300">
                            {selectedTicket.category}
                          </span>
                        </div>
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono text-sm font-black text-[#6BCB37]">
                            {selectedTicket.order_id}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleCopyOrder(selectedTicket.order_id)}
                            className="px-2 py-1 rounded-lg bg-[#09120E] text-[10px] font-bold text-slate-300 hover:text-white cursor-pointer flex items-center gap-1"
                          >
                            {copiedOrderId === selectedTicket.order_id ? (
                              <>
                                <Check className="w-3 h-3 text-[#6BCB37]" /> Disalin
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" /> Salin
                              </>
                            )}
                          </button>
                        </div>
                        {relatedOrder && (
                          <div className="text-[11px] text-emerald-200/80 flex items-center gap-1.5 pt-0.5">
                            <Receipt className="w-3 h-3 text-[#6BCB37]" />
                            <span>
                              {relatedOrder.title} • Rp{Number(relatedOrder.amount || 0).toLocaleString('id-ID')} ({relatedOrder.status})
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Complaint Description & Proof Attachment */}
                    <div className="p-3.5 rounded-2xl bg-[#0F1E18] border border-[#1E3A2F] space-y-2">
                      <div className="flex items-center justify-between text-[11px] text-slate-400">
                        <span className="font-bold text-slate-300">Detail Kendala Pelanggan</span>
                        <span>Dibuat: {selectedTicket.dateFormatted}</span>
                      </div>
                      <p className="text-xs text-slate-200 leading-relaxed whitespace-pre-wrap">
                        {selectedTicket.description}
                      </p>
                      {selectedTicket.attachment_url && (
                        <div className="pt-2">
                          <div className="text-[11px] font-bold text-slate-400 mb-1.5 flex items-center gap-1">
                            <ImageIcon className="w-3.5 h-3.5 text-[#6BCB37]" />
                            <span>Lampiran Bukti Pengguna</span>
                          </div>
                          <img
                            src={selectedTicket.attachment_url}
                            alt="Bukti lampiran pengaduan"
                            className="max-h-48 rounded-xl border border-[#234A3B] object-contain bg-black/40"
                          />
                        </div>
                      )}
                    </div>

                    {/* Direct Status Switcher */}
                    <div className="p-3 rounded-2xl bg-[#0F1E18] border border-[#1E3A2F] flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                      <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                        <Tag className="w-3.5 h-3.5 text-[#6BCB37]" />
                        <span>Ubah Status Tiket:</span>
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {TICKET_STATUSES.map((st) => (
                          <button
                            key={st}
                            type="button"
                            disabled={updatingStatus || selectedTicket.status === st}
                            onClick={() => handleStatusChange(st)}
                            className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold border transition-all cursor-pointer disabled:opacity-60 ${
                              selectedTicket.status === st
                                ? 'bg-[#143D28] text-[#6BCB37] border-[#6BCB37]'
                                : 'bg-[#09120E] text-slate-300 border-[#214234] hover:border-slate-500'
                            }`}
                          >
                            {st}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Threaded Live Chat History */}
                    <div className="space-y-2.5">
                      <div className="text-xs font-extrabold text-slate-300 flex items-center gap-1.5">
                        <MessageSquare className="w-3.5 h-3.5 text-[#6BCB37]" />
                        <span>Riwayat Percakapan ({selectedTicket.replies?.length || 0})</span>
                      </div>

                      <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                        {(!selectedTicket.replies || selectedTicket.replies.length === 0) ? (
                          <div className="p-4 rounded-xl bg-[#09120E] border border-[#1E3A2F] text-center text-xs text-slate-400">
                            Belum ada balasan. Kirim tanggapan pertama dari tim CS di bawah.
                          </div>
                        ) : (
                          selectedTicket.replies.map((rep) => {
                            const isAdmin = rep.sender_role === 'admin';
                            return (
                              <div
                                key={rep.id}
                                className={`flex flex-col ${isAdmin ? 'items-end' : 'items-start'}`}
                              >
                                <div
                                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs border ${
                                    isAdmin
                                      ? 'bg-[#143D28] border-[#296B48] text-white rounded-br-sm'
                                      : 'bg-[#13222E] border-slate-700 text-slate-100 rounded-bl-sm'
                                  }`}
                                >
                                  <div className="flex items-center justify-between gap-3 mb-1">
                                    <span
                                      className={`text-[10px] font-extrabold ${
                                        isAdmin ? 'text-[#6BCB37]' : 'text-sky-300'
                                      }`}
                                    >
                                      {rep.sender_name}
                                    </span>
                                    <span className="text-[10px] text-slate-400">
                                      {rep.dateFormatted}
                                    </span>
                                  </div>
                                  <p className="leading-relaxed whitespace-pre-wrap">{rep.message}</p>
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Reply Input Footer */}
                  <form
                    onSubmit={handleSendReply}
                    className="p-4 border-t border-[#1E3A2F] bg-[#0F1E18] space-y-2.5"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px]">
                      <span className="text-slate-400">
                        Kirim tanggapan sebagai <strong className="text-[#6BCB37]">Admin CS TO PAY</strong>
                      </span>
                      <label className="flex items-center gap-2 text-slate-300">
                        <span>Status setelah kirim:</span>
                        <select
                          value={replyNextStatus}
                          onChange={(e) => setReplyNextStatus(e.target.value as TicketStatus)}
                          className="px-2.5 py-1 rounded-lg bg-[#09120E] border border-[#234A3B] text-xs font-bold text-white focus:outline-none focus:border-[#6BCB37]"
                        >
                          <option value="Tunggu User">Tunggu User (Otomatis)</option>
                          <option value="Diproses">Tetap Diproses</option>
                          <option value="Selesai">Tandai Selesai</option>
                        </select>
                      </label>
                    </div>

                    <div className="flex gap-2">
                      <textarea
                        rows={2}
                        value={replyMessage}
                        onChange={(e) => setReplyMessage(e.target.value)}
                        placeholder="Tulis balasan solusi atau konfirmasi untuk pelanggan..."
                        className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#09120E] border border-[#234A3B] text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#6BCB37] resize-none"
                      />
                      <button
                        type="submit"
                        disabled={sendingReply || !replyMessage.trim()}
                        className="px-4 py-2.5 rounded-xl bg-[#143D28] hover:bg-[#1B5136] disabled:opacity-50 text-white font-bold text-xs border border-[#6BCB37]/40 flex items-center justify-center gap-1.5 cursor-pointer shrink-0 transition-colors"
                      >
                        {sendingReply ? (
                          <Loader2 className="w-4 h-4 animate-spin text-[#6BCB37]" />
                        ) : (
                          <>
                            <Send className="w-4 h-4 text-[#6BCB37]" />
                            <span>Kirim</span>
                          </>
                        )}
                      </button>
                    </div>
                  </form>
                </>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
