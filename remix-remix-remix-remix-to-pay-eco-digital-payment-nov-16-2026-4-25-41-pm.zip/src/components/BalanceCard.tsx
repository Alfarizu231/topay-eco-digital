import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Eye, EyeOff, PlusCircle, ArrowUpRight, Leaf, ShieldCheck, Sparkles, Activity } from 'lucide-react';

interface BalanceCardProps {
  balance: number;
  ecoPoints?: number;
  treesPlanted?: number;
  onTopUpClick: () => void;
  onTransferClick: () => void;
  onSecurityClick?: () => void;
  onCashFlowClick?: () => void;
  isDarkMode?: boolean;
}

export const BalanceCard: React.FC<BalanceCardProps> = ({
  balance,
  ecoPoints = 0,
  treesPlanted = 0,
  onTopUpClick,
  onTransferClick,
  onSecurityClick,
  onCashFlowClick,
}) => {
  const [showBalance, setShowBalance] = useState(true);

  const formattedBalance = new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(balance);

  return (
    <motion.div
      initial={{ scale: 0.98, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="relative w-full rounded-2xl bg-gradient-to-br from-[#143D28] via-[#16422F] to-[#0E2C1D] text-white p-5 sm:p-6 shadow-lg shadow-[#143D28]/15 overflow-hidden border border-[#20553A]"
    >
      {/* Subtle organic pattern lines inspired by leaf veins and squirrel tail curve */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" preserveAspectRatio="none">
          {/* Subtle curved leaf tail contours */}
          <path
            d="M-20 180 C 120 160, 220 40, 420 20"
            stroke="#6BCB37"
            strokeWidth="3"
            strokeDasharray="6 6"
          />
          <path
            d="M-10 220 C 150 190, 260 90, 430 80"
            stroke="#FFFFFF"
            strokeWidth="1.5"
          />
          <path
            d="M260 -20 C 280 80, 360 140, 420 180"
            stroke="#6BCB37"
            strokeWidth="2"
          />
          {/* Faint leaf silhouette */}
          <circle cx="360" cy="40" r="70" fill="rgba(107, 203, 55, 0.08)" />
          <circle cx="40" cy="180" r="90" fill="rgba(255, 255, 255, 0.03)" />
        </svg>
      </div>

      {/* Top row: Label + Eye toggle + Eco badge & Cash flow */}
      <div className="relative z-10 flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-2">
          <span className="text-xs sm:text-sm font-medium text-emerald-100/90 tracking-wide">
            Saldo TO PAY
          </span>
          <button
            onClick={() => setShowBalance(!showBalance)}
            className="p-1 rounded-md hover:bg-white/10 text-emerald-200 transition-colors cursor-pointer"
            aria-label="Toggle Balance Visibility"
          >
            {showBalance ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          {onCashFlowClick && (
            <button
              onClick={onCashFlowClick}
              className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#6BCB37]/20 hover:bg-[#6BCB37]/30 text-[11px] font-bold text-[#A3E635] border border-[#6BCB37]/30 transition-all cursor-pointer"
            >
              <Activity className="w-3 h-3 text-[#6BCB37]" />
              <span>Arus Kas</span>
            </button>
          )}

          <button
            onClick={onSecurityClick}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm text-[11px] font-semibold text-emerald-200 border border-white/10 transition-all cursor-pointer"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#6BCB37]" />
            <span className="hidden xs:inline">Terlindungi</span>
          </button>
        </div>
      </div>

      {/* Main Balance Display */}
      <div className="relative z-10 my-3">
        <AnimatePresence mode="wait">
          {showBalance ? (
            <motion.div
              key="visible"
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 4 }}
              className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white flex items-baseline gap-1"
            >
              <span>{formattedBalance}</span>
            </motion.div>
          ) : (
            <motion.div
              key="hidden"
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 4 }}
              className="text-2xl sm:text-3xl font-extrabold tracking-widest text-emerald-200/90"
            >
              Rp••••••••
            </motion.div>
          )}
        </AnimatePresence>

        {/* Eco points mini ticker */}
        <div className="flex items-center gap-3 mt-2 text-xs text-emerald-100/80">
          <div className="flex items-center gap-1">
            <Leaf className="w-3.5 h-3.5 text-[#6BCB37]" />
            <span className="font-semibold text-white">{ecoPoints.toLocaleString('id-ID')}</span>
            <span className="text-[11px] text-emerald-200/80">Eco Points</span>
          </div>
          <span className="text-white/30">•</span>
          <div className="flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-[#6BCB37]" />
            <span className="font-semibold text-white">{treesPlanted} Pohon</span>
            <span className="text-[11px] text-emerald-200/80">Ditanam</span>
          </div>
        </div>
      </div>

      {/* Action Buttons: Top Up and Transfer (White buttons with green text as requested) */}
      <div className="relative z-10 grid grid-cols-2 gap-3 pt-3 border-t border-white/10">
        <button
          onClick={onTopUpClick}
          className="w-full py-2.5 px-3 rounded-xl bg-white hover:bg-[#F2FBF5] text-[#143D28] font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm hover:shadow transition-all cursor-pointer active:scale-[0.98]"
        >
          <div className="w-5 h-5 rounded-full bg-[#EAF6EE] flex items-center justify-center text-[#143D28]">
            <PlusCircle className="w-3.5 h-3.5 text-[#143D28]" />
          </div>
          <span>Top Up</span>
        </button>

        <button
          onClick={onTransferClick}
          className="w-full py-2.5 px-3 rounded-xl bg-white hover:bg-[#F2FBF5] text-[#143D28] font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm hover:shadow transition-all cursor-pointer active:scale-[0.98]"
        >
          <div className="w-5 h-5 rounded-full bg-[#EAF6EE] flex items-center justify-center text-[#143D28]">
            <ArrowUpRight className="w-3.5 h-3.5 text-[#143D28]" />
          </div>
          <span>Transfer</span>
        </button>
      </div>
    </motion.div>
  );
};
