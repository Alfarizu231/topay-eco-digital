import React from 'react';
import { PlusCircle, Send, QrCode, CreditCard } from 'lucide-react';

interface QuickActionsProps {
  onSelectAction: (action: 'topup' | 'transfer' | 'qris' | 'pay') => void;
  isDarkMode?: boolean;
}

export const QuickActions: React.FC<QuickActionsProps> = ({ onSelectAction, isDarkMode = false }) => {
  const actions = [
    {
      id: 'topup' as const,
      label: 'Top Up',
      sublabel: 'Isi Saldo',
      icon: PlusCircle,
    },
    {
      id: 'transfer' as const,
      label: 'Transfer',
      sublabel: 'Kirim Uang',
      icon: Send,
    },
    {
      id: 'qris' as const,
      label: 'QRIS',
      sublabel: 'Bayar Cepat',
      icon: QrCode,
      highlight: true,
    },
    {
      id: 'pay' as const,
      label: 'Bayar',
      sublabel: 'Tagihan',
      icon: CreditCard,
    },
  ];

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-bold text-[#143D28] dark:text-white">
          Quick Access
        </h2>
        <span className="text-[11px] font-medium text-[#2D5A40] dark:text-[#6BCB37]">
          Transaksi Instan
        </span>
      </div>

      <div className="grid grid-cols-4 gap-2.5 sm:gap-3">
        {actions.map((act) => {
          const Icon = act.icon;
          return (
            <button
              key={act.id}
              onClick={() => onSelectAction(act.id)}
              className={`group flex flex-col items-center justify-center p-3 rounded-xl border transition-all duration-200 cursor-pointer active:scale-95 ${
                act.highlight
                  ? isDarkMode
                    ? 'bg-[#163826] border-[#6BCB37]/50 shadow-sm shadow-[#6BCB37]/10'
                    : 'bg-[#EBF7EE] border-[#6BCB37] shadow-sm shadow-[#6BCB37]/10'
                  : isDarkMode
                    ? 'bg-[#12281E] border-[#1E4330] hover:bg-[#183628]'
                    : 'bg-white border-[#E2ECE5] hover:bg-[#F2FAF5]'
              }`}
            >
              <div
                className={`relative w-10 h-10 rounded-xl flex items-center justify-center mb-1.5 transition-transform duration-200 group-hover:scale-110 ${
                  act.highlight
                    ? 'bg-[#143D28] text-white'
                    : isDarkMode
                      ? 'bg-[#183628] text-[#6BCB37]'
                      : 'bg-[#EAF6EE] text-[#143D28]'
                }`}
              >
                <Icon className={`w-5 h-5 ${act.highlight ? 'text-[#6BCB37]' : 'text-[#143D28] dark:text-[#6BCB37]'}`} />
                {act.highlight && (
                  <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-[#6BCB37] border-2 border-white dark:border-[#143D28]" />
                )}
              </div>
              <span className="text-xs font-bold text-[#143D28] dark:text-gray-100 group-hover:text-[#143D28] dark:group-hover:text-[#6BCB37] text-center">
                {act.label}
              </span>
              <span className="text-[10px] text-gray-500 dark:text-gray-400 text-center leading-tight">
                {act.sublabel}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
