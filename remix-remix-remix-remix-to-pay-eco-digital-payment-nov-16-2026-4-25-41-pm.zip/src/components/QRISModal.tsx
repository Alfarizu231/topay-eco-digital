import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  QrCode,
  Scan,
  Flashlight,
  Image as ImageIcon,
  Share2,
  Download,
  CheckCircle2,
  Store,
  Leaf,
  Sparkles,
  AlertCircle,
  Loader2,
  Lock,
  ArrowRight,
  ShieldCheck,
  Building2,
  RotateCcw,
  Copy,
  Info,
} from 'lucide-react';
import jsQR from 'jsqr';
import { authFetch } from '../utils/authFetch';
import QRCode from 'qrcode';
import { ToPayLogo } from './ToPayLogo';
import { QRISMerchantInfo, UserProfile, Transaction } from '../types';
import { parseQRISString } from '../utils/qris';
import { ForgotPinModal } from './ForgotPinModal';

interface QRISModalProps {
  onClose: () => void;
  onPaymentComplete: (tx: Transaction) => void;
  user: UserProfile;
  isDarkMode?: boolean;
}

export const QRISModal: React.FC<QRISModalProps> = ({
  onClose,
  onPaymentComplete,
  user,
  isDarkMode = false,
}) => {
  const [activeTab, setActiveTab] = useState<'scan' | 'myqr'>('scan');
  
  // Scanner state
  const [cameraActive, setCameraActive] = useState<boolean>(true);
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [torchOn, setTorchOn] = useState<boolean>(false);
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null);
  const [scannerError, setScannerError] = useState<string | null>(null);
  const [isProcessingScan, setIsProcessingScan] = useState<boolean>(false);

  // Merchant & Payment flow state
  const [merchantInfo, setMerchantInfo] = useState<QRISMerchantInfo | null>(null);
  const [payAmount, setPayAmount] = useState<number>(0);
  const [note, setNote] = useState<string>('');
  const [paymentStep, setPaymentStep] = useState<'scan' | 'confirm' | 'pin' | 'processing'>('scan');
  
  // PIN Verification State
  const [pin, setPin] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [isVerifyingPin, setIsVerifyingPin] = useState<boolean>(false);
  const [showForgotPin, setShowForgotPin] = useState<boolean>(false);

  // My QR Generation State
  const [myQrAmount, setMyQrAmount] = useState<string>('');
  const [myQrDataUrl, setMyQrDataUrl] = useState<string>('');
  const [isCopiedMyQr, setIsCopiedMyQr] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scanLoopRef = useRef<number | null>(null);

  // Initialize Camera Stream
  useEffect(() => {
    if (activeTab === 'scan' && paymentStep === 'scan' && cameraActive) {
      let isMounted = true;

      const startCamera = async () => {
        try {
          if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            setHasCameraPermission(false);
            setScannerError('Kamera tidak didukung pada browser ini. Silakan unggah foto kode QRIS dari galeri.');
            return;
          }

          const stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
          });

          if (!isMounted) {
            stream.getTracks().forEach((track) => track.stop());
            return;
          }

          setMediaStream(stream);
          setHasCameraPermission(true);
          setScannerError(null);

          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.setAttribute('playsinline', 'true');
            await videoRef.current.play();
            requestAnimationFrame(scanQRCodeFrame);
          }
        } catch (err: any) {
          console.warn('Camera access denied or unavailable:', err);
          if (isMounted) {
            setHasCameraPermission(false);
            setScannerError('Akses kamera tidak diizinkan atau tidak tersedia. Gunakan tombol Pilih dari Galeri untuk memindai gambar QRIS.');
          }
        }
      };

      startCamera();

      return () => {
        isMounted = false;
        if (scanLoopRef.current) {
          cancelAnimationFrame(scanLoopRef.current);
        }
        if (mediaStream) {
          mediaStream.getTracks().forEach((t) => t.stop());
        }
      };
    } else {
      if (mediaStream) {
        mediaStream.getTracks().forEach((t) => t.stop());
        setMediaStream(null);
      }
    }
  }, [activeTab, paymentStep, cameraActive]);

  // Frame scanner loop
  const scanQRCodeFrame = () => {
    if (!videoRef.current || !canvasRef.current || paymentStep !== 'scan' || isProcessingScan) {
      return;
    }

    const video = videoRef.current;
    const canvas = canvasRef.current;

    if (video.readyState === video.HAVE_ENOUGH_DATA) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });

      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert',
        });

        if (code && code.data) {
          handleQRDetected(code.data);
          return;
        }
      }
    }

    scanLoopRef.current = requestAnimationFrame(scanQRCodeFrame);
  };

  // Toggle Torch/Flashlight
  const handleToggleTorch = async () => {
    if (!mediaStream) return;
    const track = mediaStream.getVideoTracks()[0];
    if (track) {
      const capabilities: any = track.getCapabilities ? track.getCapabilities() : {};
      if (capabilities.torch) {
        try {
          await track.applyConstraints({
            advanced: [{ torch: !torchOn } as any],
          });
          setTorchOn(!torchOn);
        } catch (err) {
          console.warn('Torch toggle error:', err);
        }
      } else {
        setTorchOn(!torchOn);
      }
    }
  };

  // Handle scanned raw payload
  const handleQRDetected = async (rawPayload: string) => {
    setIsProcessingScan(true);
    setScannerError(null);

    // Call server endpoint or fallback to client parser
    try {
      const response = await authFetch('/api/qris/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payload: rawPayload }),
      });
      const res = await response.json();

      if (response.ok && res.success && res.merchant) {
        handleMerchantLoaded(res.merchant);
      } else {
        // Try client parser fallback
        const parsed = parseQRISString(rawPayload);
        if (parsed.valid && parsed.data) {
          handleMerchantLoaded(parsed.data);
        } else {
          setScannerError(res.error || parsed.error || 'QRIS ini belum dapat diproses oleh TO PAY.');
          setIsProcessingScan(false);
        }
      }
    } catch (err) {
      // Local parser
      const parsed = parseQRISString(rawPayload);
      if (parsed.valid && parsed.data) {
        handleMerchantLoaded(parsed.data);
      } else {
        setScannerError('Gagal memproses kode QR. Pastikan format QRIS valid.');
        setIsProcessingScan(false);
      }
    }
  };

  const handleMerchantLoaded = (merchant: QRISMerchantInfo) => {
    setMerchantInfo(merchant);
    setPayAmount(merchant.defaultAmount || 50000);
    setNote(merchant.isDynamic ? 'Pembayaran Tagihan QRIS' : 'Pembayaran Merchant Ramah Lingkungan');
    setPaymentStep('confirm');
    setIsProcessingScan(false);
  };

  // Handle Image File Upload Scan
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, img.width, img.height);
          const imgData = ctx.getImageData(0, 0, img.width, img.height);
          const qrCode = jsQR(imgData.data, imgData.width, imgData.height);
          if (qrCode && qrCode.data) {
            handleQRDetected(qrCode.data);
          } else {
            setScannerError('Tidak ditemukan kode QRIS yang valid pada gambar yang diunggah.');
          }
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Generate My QR
  useEffect(() => {
    if (activeTab === 'myqr') {
      const numAmt = myQrAmount ? Number(myQrAmount) : 0;
      const qrPayload = JSON.stringify({
        type: 'topay_qris',
        merchantName: user.name,
        username: user.username,
        phone: user.phone,
        city: 'Jakarta',
        amount: numAmt > 0 ? numAmt : undefined,
      });

      QRCode.toDataURL(qrPayload, {
        width: 280,
        margin: 2,
        color: {
          dark: '#064e3b', // Deep emerald
          light: '#ffffff',
        },
      })
        .then((url) => setMyQrDataUrl(url))
        .catch((err) => console.error('Error generating QR:', err));
    }
  }, [activeTab, myQrAmount, user]);

  // Handle PIN Keypad Press
  const handlePinPress = (digit: string) => {
    if (pin.length < 6) {
      const newPin = pin + digit;
      setPin(newPin);
      setPinError(null);
      if (newPin.length === 6) {
        executePayment(newPin);
      }
    }
  };

  const handlePinBackspace = () => {
    setPin((prev) => prev.slice(0, -1));
    setPinError(null);
  };

  // Confirm Payment with Backend
  const executePayment = async (submittedPin: string) => {
    if (!merchantInfo) return;

    if (payAmount <= 0) {
      setPinError('Nominal pembayaran tidak valid.');
      return;
    }

    if (user.balance < payAmount + (merchantInfo.fee || 0)) {
      setPinError(`Saldo tidak mencukupi (Saldo: Rp${user.balance.toLocaleString('id-ID')}).`);
      return;
    }

    setIsVerifyingPin(true);
    setPinError(null);

    const idempotencyKey = `IDEM-QRIS-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

    try {
      const response = await authFetch('/api/qris/payment/confirm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          merchantName: merchantInfo.merchantName,
          nmid: merchantInfo.nmid,
          amount: payAmount,
          fee: merchantInfo.fee || 0,
          note: note.trim() || 'Pembayaran QRIS Merchant',
          idempotencyKey,
          pin: submittedPin,
        }),
      });

      const result = await response.json();

      if (response.ok && result.success && result.transaction) {
        onPaymentComplete(result.transaction);
      } else {
        setPin('');
        setPinError(result.error || 'Pembayaran gagal. Silakan periksa kembali PIN Anda.');
      }
    } catch (err) {
      console.error('Error confirming QRIS payment:', err);
      setPin('');
      setPinError('Gagal menghubungi server keamanan. Silakan coba beberapa saat lagi.');
    } finally {
      setIsVerifyingPin(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-emerald-950/70 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className={`w-full max-w-md rounded-3xl shadow-2xl border flex flex-col my-auto overflow-hidden ${
          isDarkMode ? 'bg-[#0f241a] border-emerald-900 text-white' : 'bg-white border-emerald-100 text-slate-900'
        }`}
      >
        {/* Hidden Canvas for QR video frame processing */}
        <canvas ref={canvasRef} className="hidden" />
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleImageUpload}
        />

        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
              <QrCode className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-extrabold leading-tight">QRIS TO PAY</h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-400 text-emerald-950">
                  Standar BI
                </span>
              </div>
              <p className="text-[11px] text-emerald-200">Pindai & bayar tanpa kontak di semua merchant</p>
            </div>
          </div>
          <button
            id="btn-close-qris-modal"
            onClick={onClose}
            className="p-2 rounded-xl text-emerald-200 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher (Only on initial scan step) */}
        {paymentStep === 'scan' && (
          <div className="grid grid-cols-2 p-1.5 mx-5 mt-4 bg-emerald-50 dark:bg-emerald-950/50 rounded-2xl border border-emerald-100 dark:border-emerald-900/50">
            <button
              type="button"
              id="tab-scan-qr"
              onClick={() => setActiveTab('scan')}
              className={`py-2 text-xs font-bold rounded-xl flex items-center justify-center space-x-1.5 transition-all ${
                activeTab === 'scan'
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-emerald-800'
              }`}
            >
              <Scan className="w-4 h-4 text-emerald-300" />
              <span>Pindai QRIS</span>
            </button>
            <button
              type="button"
              id="tab-my-qr"
              onClick={() => setActiveTab('myqr')}
              className={`py-2 text-xs font-bold rounded-xl flex items-center justify-center space-x-1.5 transition-all ${
                activeTab === 'myqr'
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-emerald-800'
              }`}
            >
              <QrCode className="w-4 h-4 text-emerald-300" />
              <span>QRIS Saya</span>
            </button>
          </div>
        )}

        {/* Main Content Areas based on Step */}
        <div className="p-5 overflow-y-auto max-h-[75vh]">
          {/* STEP 1: SCANNER VIEW */}
          {paymentStep === 'scan' && activeTab === 'scan' && (
            <div className="flex flex-col items-center">
              {/* Camera Scanner Container */}
              <div className="relative w-full aspect-square max-w-[280px] rounded-3xl bg-black overflow-hidden flex items-center justify-center shadow-xl border-2 border-emerald-800">
                {/* Live Video Feed */}
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  autoPlay
                  muted
                  playsInline
                />

                {/* Animated Green Scanning Laser */}
                <div className="absolute inset-x-4 h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_15px_#34d399] animate-scan-beam" />

                {/* Target Frame with 4 Rounded Corner Brackets */}
                <div className="absolute w-48 h-48 rounded-2xl border border-white/20 flex flex-col justify-between p-1.5 pointer-events-none">
                  <div className="flex justify-between">
                    <div className="w-7 h-7 border-t-3 border-l-3 border-emerald-400 rounded-tl-xl" />
                    <div className="w-7 h-7 border-t-3 border-r-3 border-emerald-400 rounded-tr-xl" />
                  </div>
                  <div className="flex justify-center opacity-40">
                    <ToPayLogo size="sm" showText={false} variant="white" />
                  </div>
                  <div className="flex justify-between">
                    <div className="w-7 h-7 border-b-3 border-l-3 border-emerald-400 rounded-bl-xl" />
                    <div className="w-7 h-7 border-b-3 border-r-3 border-emerald-400 rounded-br-xl" />
                  </div>
                </div>

                {isProcessingScan && (
                  <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex flex-col items-center justify-center text-white space-y-2">
                    <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
                    <span className="text-xs font-bold">Memverifikasi QRIS...</span>
                  </div>
                )}

                <div className="absolute bottom-3 text-[11px] font-semibold text-white/90 bg-emerald-950/80 px-3 py-1 rounded-full backdrop-blur-sm border border-white/10">
                  Arahkan kamera ke kode QRIS
                </div>
              </div>

              {/* Controls (Torch & Gallery Upload) */}
              <div className="flex items-center space-x-3 mt-4">
                <button
                  type="button"
                  id="btn-toggle-flash"
                  onClick={handleToggleTorch}
                  className={`p-3 rounded-2xl border transition-all flex items-center space-x-2 text-xs font-semibold ${
                    torchOn
                      ? 'bg-emerald-400 border-emerald-400 text-emerald-950 shadow-md'
                      : 'bg-slate-100 dark:bg-emerald-950 border-slate-200 dark:border-emerald-900 text-slate-700 dark:text-emerald-200'
                  }`}
                >
                  <Flashlight className="w-4 h-4" />
                  <span>{torchOn ? 'Flash Nyala' : 'Flash'}</span>
                </button>

                <button
                  type="button"
                  id="btn-upload-qr-image"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-3 rounded-2xl bg-slate-100 dark:bg-emerald-950 border border-slate-200 dark:border-emerald-900 text-slate-700 dark:text-emerald-200 hover:bg-slate-200 transition-all flex items-center space-x-2 text-xs font-semibold"
                >
                  <ImageIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>Pilih dari Galeri</span>
                </button>
              </div>

              {/* Error Banner */}
              {scannerError && (
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="w-full mt-3 p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 flex items-start space-x-2.5 text-rose-800 dark:text-rose-200 text-xs"
                >
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{scannerError}</span>
                </motion.div>
              )}

              <p className="mt-4 text-[11px] text-center text-slate-500 dark:text-emerald-300/70">
                Pindai kode QRIS resmi menggunakan kamera atau unggah gambar QRIS dari galeri perangkat Anda.
              </p>
            </div>
          )}

          {/* STEP 2: MERCHANT DETAIL & PAYMENT AMOUNT CONFIRMATION */}
          {paymentStep === 'confirm' && merchantInfo && (
            <div className="space-y-4">
              {/* Merchant Identity Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50/60 dark:from-emerald-950/60 dark:to-teal-950/40 border border-emerald-200/80 dark:border-emerald-800">
                <div className="flex items-start space-x-3">
                  <div className="w-11 h-11 rounded-2xl bg-emerald-800 text-white flex items-center justify-center shrink-0 shadow-md">
                    <Building2 className="w-6 h-6 text-emerald-300" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-1.5">
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                        {merchantInfo.merchantName}
                      </h3>
                      <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    </div>
                    <p className="text-xs text-slate-500 dark:text-emerald-300/80">{merchantInfo.city}</p>
                    <p className="text-[11px] font-mono text-slate-400 mt-0.5">NMID: {merchantInfo.nmid}</p>
                  </div>
                </div>
              </div>

              {/* Amount Input */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-emerald-200 mb-1.5">
                  Nominal Pembayaran
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-base font-bold text-emerald-800 dark:text-emerald-400">
                    Rp
                  </span>
                  <input
                    id="input-qris-amount"
                    type="number"
                    value={payAmount || ''}
                    disabled={merchantInfo.isDynamic}
                    onChange={(e) => setPayAmount(Math.max(0, Number(e.target.value)))}
                    placeholder="0"
                    className="w-full pl-12 pr-4 py-3 bg-slate-50 dark:bg-emerald-950/60 border border-slate-200 dark:border-emerald-800 rounded-2xl text-lg font-extrabold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600 disabled:opacity-80"
                  />
                </div>
                {merchantInfo.isDynamic ? (
                  <p className="text-[11px] text-emerald-700 dark:text-emerald-300 mt-1 flex items-center space-x-1">
                    <Info className="w-3.5 h-3.5" />
                    <span>Nominal ditentukan secara otomatis oleh kasir/QRIS Dinamis</span>
                  </p>
                ) : (
                  <div className="grid grid-cols-4 gap-1.5 mt-2">
                    {[20000, 50000, 100000, 200000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setPayAmount(amt)}
                        className={`py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                          payAmount === amt
                            ? 'bg-emerald-800 text-white border-emerald-800'
                            : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-emerald-200 border-slate-200 dark:border-emerald-800 hover:border-emerald-500'
                        }`}
                      >
                        {(amt / 1000).toFixed(0)}k
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Note Input */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-emerald-200 mb-1.5">
                  Catatan Transaksi (Opsional)
                </label>
                <input
                  id="input-qris-note"
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Contoh: Belanja bahan organik..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-emerald-950/60 border border-slate-200 dark:border-emerald-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              {/* Eco Impact & Balance Info */}
              <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200/70 dark:border-emerald-900 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500 dark:text-emerald-300/80">Saldo TO PAY Anda:</span>
                  <span className="font-extrabold text-slate-900 dark:text-white">
                    Rp{user.balance.toLocaleString('id-ID')}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500 dark:text-emerald-300/80">Biaya Layanan Admin:</span>
                  <span className="font-bold text-emerald-700 dark:text-emerald-400">Gratis (Rp0)</span>
                </div>
                <div className="pt-2 border-t border-emerald-200/60 dark:border-emerald-800 flex items-center justify-between text-xs font-bold text-emerald-900 dark:text-emerald-300">
                  <div className="flex items-center space-x-1.5">
                    <Leaf className="w-4 h-4 text-emerald-600" />
                    <span>Dampak Ramah Lingkungan:</span>
                  </div>
                  <span>+{Math.max(10, Math.round(payAmount / 5000))} Eco Points</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2.5 pt-1">
                <button
                  type="button"
                  id="btn-re-scan"
                  onClick={() => {
                    setPaymentStep('scan');
                    setMerchantInfo(null);
                  }}
                  className="py-3 px-3 rounded-2xl border border-slate-200 dark:border-emerald-800 text-xs font-bold text-slate-700 dark:text-emerald-200 hover:bg-slate-100 transition-colors flex items-center justify-center space-x-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Pindai Ulang</span>
                </button>

                <button
                  type="button"
                  id="btn-proceed-pin"
                  disabled={payAmount <= 0}
                  onClick={() => {
                    setPin('');
                    setPinError(null);
                    setPaymentStep('pin');
                  }}
                  className="py-3 px-3 rounded-2xl bg-emerald-800 hover:bg-emerald-900 disabled:bg-slate-300 text-white text-xs font-bold shadow-lg shadow-emerald-900/20 transition-all flex items-center justify-center space-x-1.5"
                >
                  <span>Lanjut PIN</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: SECURE 6-DIGIT PIN KEYPAD */}
          {paymentStep === 'pin' && (
            <div className="flex flex-col items-center space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 flex items-center justify-center shadow-inner">
                <Lock className="w-6 h-6" />
              </div>

              <div className="text-center">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Masukkan 6 Digit PIN</h3>
                <p className="text-xs text-slate-500 dark:text-emerald-300/80 mt-0.5">
                  Konfirmasi pembayaran Rp{payAmount.toLocaleString('id-ID')} ke {merchantInfo?.merchantName}
                </p>
              </div>

              {/* 6 Masked Dots */}
              <div className="flex space-x-3 my-2">
                {[0, 1, 2, 3, 4, 5].map((idx) => (
                  <div
                    key={idx}
                    className={`w-3.5 h-3.5 rounded-full transition-all ${
                      idx < pin.length
                        ? 'bg-emerald-600 scale-110 shadow-sm'
                        : 'bg-slate-200 dark:bg-emerald-900'
                    }`}
                  />
                ))}
              </div>

              {pinError && (
                <motion.div
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center space-x-2"
                >
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{pinError}</span>
                </motion.div>
              )}

              {/* Numeric Keypad Grid */}
              <div className="grid grid-cols-3 gap-3 w-full max-w-[280px]">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
                  <button
                    key={num}
                    type="button"
                    disabled={isVerifyingPin}
                    onClick={() => handlePinPress(num)}
                    className="h-12 rounded-2xl bg-slate-50 dark:bg-emerald-950/80 border border-slate-200 dark:border-emerald-800 text-lg font-bold text-slate-800 dark:text-white hover:bg-emerald-50 active:scale-95 transition-all shadow-xs"
                  >
                    {num}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => {
                    setPaymentStep('confirm');
                    setPin('');
                  }}
                  className="h-12 rounded-2xl text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors"
                >
                  Batal
                </button>
                <button
                  type="button"
                  disabled={isVerifyingPin}
                  onClick={() => handlePinPress('0')}
                  className="h-12 rounded-2xl bg-slate-50 dark:bg-emerald-950/80 border border-slate-200 dark:border-emerald-800 text-lg font-bold text-slate-800 dark:text-white hover:bg-emerald-50 active:scale-95 transition-all shadow-xs"
                >
                  0
                </button>
                <button
                  type="button"
                  onClick={handlePinBackspace}
                  className="h-12 rounded-2xl bg-slate-50 dark:bg-emerald-950/80 border border-slate-200 dark:border-emerald-800 text-slate-600 dark:text-emerald-200 hover:bg-slate-200 active:scale-95 transition-all flex items-center justify-center shadow-xs"
                >
                  ⌫
                </button>
              </div>

              {isVerifyingPin && (
                <div className="flex items-center space-x-2 text-xs font-semibold text-emerald-700 dark:text-emerald-300">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Memproses transaksi & enkripsi keamanan...</span>
                </div>
              )}

              <button
                type="button"
                onClick={() => setShowForgotPin(true)}
                className="text-[11px] font-bold text-emerald-700 dark:text-[#6BCB37] hover:underline cursor-pointer pt-1"
              >
                Lupa PIN Transaksi?
              </button>
            </div>
          )}

          {/* TAB 2: MY QR SCREEN (TERIMA PEMBAYARAN) */}
          {activeTab === 'myqr' && paymentStep === 'scan' && (
            <div className="flex flex-col items-center space-y-4">
              {/* QR Code Presentation Frame */}
              <div className="relative p-5 rounded-3xl bg-white border-2 border-emerald-800 shadow-xl flex flex-col items-center max-w-[280px]">
                <div className="flex items-center space-x-1.5 mb-2">
                  <ToPayLogo size="sm" showText={true} />
                </div>

                {myQrDataUrl ? (
                  <div className="w-48 h-48 p-2 rounded-2xl border border-emerald-100 bg-white flex items-center justify-center shadow-inner">
                    <img src={myQrDataUrl} alt="QRIS Saya" className="w-full h-full object-contain" />
                  </div>
                ) : (
                  <div className="w-48 h-48 bg-emerald-50 rounded-2xl flex items-center justify-center">
                    <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
                  </div>
                )}

                <div className="text-center mt-3">
                  <div className="text-sm font-extrabold text-emerald-950">{user.name}</div>
                  <div className="text-xs font-mono text-emerald-700 font-semibold">{user.username}</div>
                  <div className="text-[11px] text-slate-400">{user.phone}</div>
                </div>
              </div>

              {/* Set Custom Amount Option */}
              <div className="w-full">
                <label className="block text-xs font-bold text-slate-700 dark:text-emerald-200 mb-1">
                  Atur Nominal Tetap (Opsional)
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-xs font-bold text-slate-400">
                    Rp
                  </span>
                  <input
                    type="number"
                    value={myQrAmount}
                    onChange={(e) => setMyQrAmount(e.target.value)}
                    placeholder="Biarkan kosong untuk nominal bebas"
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-emerald-950/60 border border-slate-200 dark:border-emerald-800 rounded-xl text-xs text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3 w-full">
                <button
                  type="button"
                  id="btn-copy-my-qr"
                  onClick={() => {
                    navigator.clipboard.writeText(`topay://pay?user=${encodeURIComponent(user.username)}&amount=${myQrAmount}`);
                    setIsCopiedMyQr(true);
                    setTimeout(() => setIsCopiedMyQr(false), 2000);
                  }}
                  className="py-2.5 px-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-bold border border-emerald-200 dark:border-emerald-900 hover:bg-emerald-100 transition-colors flex items-center justify-center space-x-1.5"
                >
                  {isCopiedMyQr ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  <span>{isCopiedMyQr ? 'Tersalin!' : 'Salin Tautan'}</span>
                </button>

                <a
                  href={myQrDataUrl}
                  download={`QRIS-TO-PAY-${user.name.replace(/\s+/g, '-')}.png`}
                  className="py-2.5 px-3 rounded-2xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold shadow-md transition-colors flex items-center justify-center space-x-1.5"
                >
                  <Download className="w-4 h-4 text-emerald-300" />
                  <span>Unduh QR</span>
                </a>
              </div>
            </div>
          )}
        </div>
      </motion.div>

      {/* Forgot PIN Modal */}
      {showForgotPin && (
        <ForgotPinModal
          isOpen={showForgotPin}
          onClose={() => setShowForgotPin(false)}
          onPinResetSuccess={() => {
            setShowForgotPin(false);
            setPin('');
            setPinError(null);
          }}
          isDarkMode={isDarkMode}
        />
      )}
    </div>
  );
};
