import React, { useState } from 'react';
import {
  QrCode,
  Send,
  PlusCircle,
  ShieldCheck,
  Leaf,
  Smartphone,
  Zap,
  HeartPulse,
  Droplets,
  Globe,
  Gamepad2,
  Wallet,
  Tv,
  Receipt,
  ChevronDown,
  ChevronUp,
  Lock,
  Fingerprint,
  Mail,
  Phone,
  MessageCircle,
} from 'lucide-react';
import { serviceItems, promoItems, ewalletProviders } from '../data/mockData';
import { PUBLIC_CONTACT } from '../config/publicContact';

interface PublicSeoSectionsProps {
  isDarkMode?: boolean;
  activeSection?: 'home' | 'layanan' | 'promo' | 'keamanan' | 'faq';
  onNavigate?: (path: string, sectionId?: string) => void;
  onOpenLegal?: (type: 'terms' | 'privacy') => void;
}

const PUBLIC_FAQS = [
  {
    id: 'faq-1',
    category: 'Akun',
    question: 'Bagaimana cara mengubah profil dan nomor HP di TO PAY?',
    answer:
      'Anda dapat memperbarui nama, username, nomor HP, email, bio, dan foto profil kapan saja melalui menu Profil > Edit Profil. Tekan tombol Simpan Profil untuk memperbarui data secara permanen.',
  },
  {
    id: 'faq-2',
    category: 'Keamanan',
    question: 'Bagaimana cara mengubah PIN keamanan transaksi?',
    answer:
      'Buka menu Pengaturan > Ubah PIN. Masukkan 6-digit PIN lama Anda, lalu masukkan 6-digit PIN baru dan konfirmasi. PIN baru akan aktif seketika untuk semua transaksi.',
  },
  {
    id: 'faq-3',
    category: 'QRIS',
    question: 'Apakah QRIS TO PAY mendukung semua merchant Bank Indonesia?',
    answer:
      'Ya, QRIS TO PAY 100% kompatibel dengan standar nasional EMVCo QRIS Bank Indonesia (ASPI). Anda dapat memindai QRIS Statis maupun Dinamis di semua gerai dan merchant.',
  },
  {
    id: 'faq-4',
    category: 'Top Up',
    question: 'Berapa batas minimum dan biaya Top Up Saldo?',
    answer:
      'Minimum top up adalah Rp10.000. Top Up melalui BCA, BRI, Mandiri Virtual Account dan Gerai Retail bebas biaya admin (Rp0) untuk pengguna Eco Member.',
  },
  {
    id: 'faq-5',
    category: 'Transfer',
    question: 'Apakah transfer antar pengguna TO PAY gratis?',
    answer:
      'Transfer sesama pengguna TO PAY 100% Bebas Biaya Admin tanpa batas kuota harian dan diproses secara instan (real-time 24/7).',
  },
  {
    id: 'faq-6',
    category: 'Keamanan',
    question: 'Apa yang harus dilakukan jika ada perangkat tidak dikenal di akun saya?',
    answer:
      'Buka Pengaturan > Perangkat Terhubung, temukan perangkat yang mencurigakan, lalu tekan "Keluarkan Perangkat". Sesi perangkat tersebut akan segera dicabut secara permanen.',
  },
];

const iconMap: Record<string, React.ElementType> = {
  Smartphone,
  Wifi: Smartphone,
  Zap,
  HeartPulse,
  Droplets,
  Globe,
  Gamepad2,
  Wallet,
  Tv,
  Receipt,
};

export const PublicSeoSections: React.FC<PublicSeoSectionsProps> = ({
  isDarkMode = false,
  onNavigate,
  onOpenLegal,
}) => {
  const [openFaqId, setOpenFaqId] = useState<string | null>('faq-3');

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, path: string, sectionId?: string) => {
    if (onNavigate) {
      e.preventDefault();
      onNavigate(path, sectionId);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 sm:px-6 pb-14 pt-6 space-y-10">
      {/* Section 1: Layanan Pembayaran Digital TO PAY */}
      <section
        id="layanan"
        aria-labelledby="heading-layanan"
        className={`rounded-3xl p-6 sm:p-8 border ${
          isDarkMode
            ? 'bg-[#12281E] border-[#1E4330]'
            : 'bg-white border-gray-200 shadow-sm'
        }`}
      >
        <div className="max-w-2xl mb-6">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#113C2B] dark:text-[#6BCB37] tracking-wide mb-1.5">
            <QrCode className="w-3.5 h-3.5 text-[#113C2B] dark:text-[#6BCB37]" />
            <span>Ekosistem Pembayaran Lengkap</span>
          </div>
          <h2
            id="heading-layanan"
            className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white tracking-tight text-balance"
          >
            Layanan Pembayaran Digital &amp; Dompet Elektronik TO PAY
          </h2>
          <p className="text-sm text-gray-600 dark:text-gray-300 mt-1.5 leading-relaxed">
            Satu aplikasi pembayaran digital untuk transaksi QRIS nasional Bank Indonesia, transfer
            antar pengguna bebas biaya admin, top up e-wallet, serta pembayaran tagihan harian.
          </p>
        </div>

        {/* Core Pillars - High Contrast Cards with Dark Forest Green Icon Box & Bright Lime Icon */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <article
            className={`p-5 rounded-2xl border transition-all ${
              isDarkMode
                ? 'bg-[#0D1E16] border-[#1E4330]'
                : 'bg-white border-gray-200 shadow-sm hover:shadow-md'
            }`}
          >
            <div className="w-11 h-11 rounded-xl bg-[#113C2B] flex items-center justify-center mb-3.5 shadow-xs">
              <QrCode className="w-5 h-5 text-[#6BCB37]" />
            </div>
            <h3 className="text-base font-bold text-gray-900 dark:text-white">
              Pembayaran QRIS Nasional
            </h3>
            <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mt-1.5 leading-relaxed">
              Pindai QRIS Statis maupun Dinamis berstandar EMVCo Bank Indonesia (ASPI) di seluruh
              merchant secara instan dan tercatat otomatis.
            </p>
          </article>

          <article
            className={`p-5 rounded-2xl border transition-all ${
              isDarkMode
                ? 'bg-[#0D1E16] border-[#1E4330]'
                : 'bg-white border-gray-200 shadow-sm hover:shadow-md'
            }`}
          >
            <div className="w-11 h-11 rounded-xl bg-[#113C2B] flex items-center justify-center mb-3.5 shadow-xs">
              <Send className="w-5 h-5 text-[#6BCB37]" />
            </div>
            <h3 className="text-base font-bold text-gray-900 dark:text-white">
              Transfer &amp; Top Up Saldo Cepat
            </h3>
            <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mt-1.5 leading-relaxed">
              Kirim uang sesama pengguna TO PAY bebas biaya admin 24/7 serta transfer ke BCA,
              Mandiri, BRI, BNI, SeaBank, Bank Jago, CIMB Niaga, dan Bank Permata.
            </p>
          </article>

          <article
            className={`p-5 rounded-2xl border transition-all ${
              isDarkMode
                ? 'bg-[#0D1E16] border-[#1E4330]'
                : 'bg-white border-gray-200 shadow-sm hover:shadow-md'
            }`}
          >
            <div className="w-11 h-11 rounded-xl bg-[#113C2B] flex items-center justify-center mb-3.5 shadow-xs">
              <PlusCircle className="w-5 h-5 text-[#6BCB37]" />
            </div>
            <h3 className="text-base font-bold text-gray-900 dark:text-white">
              Top Up E-Wallet &amp; Tagihan Harian
            </h3>
            <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mt-1.5 leading-relaxed">
              Isi saldo {ewalletProviders.map((e) => e.name).join(', ')}, pulsa, paket data, token
              listrik PLN, BPJS, PDAM, internet, hingga voucher game dalam satu tempat.
            </p>
          </article>
        </div>

        {/* 10 Services List */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          {serviceItems.map((srv) => {
            const Icon = iconMap[srv.iconName] || Receipt;
            return (
              <div
                key={srv.id}
                className={`p-3 rounded-xl border flex items-center gap-2.5 transition-all ${
                  isDarkMode
                    ? 'bg-[#0D1E16] border-[#1E4330]'
                    : 'bg-gray-50/80 hover:bg-white border-gray-200 shadow-2xs'
                }`}
              >
                <div className="w-8 h-8 rounded-lg bg-[#113C2B] flex items-center justify-center shrink-0">
                  <Icon className="w-4 h-4 text-[#6BCB37]" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-gray-900 dark:text-white truncate">
                    {srv.title}
                  </div>
                  <div className="text-[11px] text-gray-600 dark:text-gray-400 truncate">
                    {srv.description}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Section 2: Promo & Eco Living */}
      <section
        id="promo"
        aria-labelledby="heading-promo"
        className={`rounded-3xl p-6 sm:p-8 border ${
          isDarkMode
            ? 'bg-[#12281E] border-[#1E4330]'
            : 'bg-white border-gray-200 shadow-sm'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#113C2B] dark:text-[#6BCB37] tracking-wide mb-1.5">
              <Leaf className="w-3.5 h-3.5 text-[#113C2B] dark:text-[#6BCB37]" />
              <span>Pay Simple · Live Green</span>
            </div>
            <h2
              id="heading-promo"
              className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white tracking-tight text-balance"
            >
              Promo Spesial &amp; Program Eco Living TO PAY
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-300 mt-1.5 leading-relaxed">
              Setiap transaksi digital membantu mengumpulkan Eco Points, melacak penghematan emisi
              CO₂, dan berkontribusi pada penanaman bibit mangrove.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {promoItems.map((promo) => (
            <article
              key={promo.id}
              className={`p-5 rounded-2xl border transition-all ${
                isDarkMode
                  ? 'bg-[#0D1E16] border-[#1E4330]'
                  : 'bg-white border-gray-200 shadow-sm hover:shadow-md'
              }`}
            >
              <div className="flex items-center justify-between gap-2 mb-1.5 text-xs">
                <span className="font-bold text-gray-500 dark:text-gray-400">
                  {promo.category}
                </span>
                <span className="font-extrabold text-[#113C2B] dark:text-[#6BCB37]">
                  {promo.discount}
                </span>
              </div>
              <h3 className="text-base font-bold text-gray-900 dark:text-white">{promo.title}</h3>
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mt-1.5 leading-relaxed">
                {promo.description}
              </p>
            </article>
          ))}
        </div>
      </section>

      {/* Section 3: Keamanan Akun */}
      <section
        id="keamanan"
        aria-labelledby="heading-keamanan"
        className={`rounded-3xl p-6 sm:p-8 border ${
          isDarkMode
            ? 'bg-[#12281E] border-[#1E4330]'
            : 'bg-white border-gray-200 shadow-sm'
        }`}
      >
        <div className="max-w-2xl mb-6">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#113C2B] dark:text-[#6BCB37] tracking-wide mb-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-[#113C2B] dark:text-[#6BCB37]" />
            <span>Perlindungan Berlapis</span>
          </div>
          <h2
            id="heading-keamanan"
            className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white tracking-tight text-balance"
          >
            Standar Keamanan Transaksi &amp; Proteksi Data
          </h2>
          <p className="text-sm text-gray-600 dark:text-gray-300 mt-1.5 leading-relaxed">
            TO PAY dirancang dengan arsitektur keamanan berlapis untuk melindungi saldo, PIN, dan
            privasi setiap transaksi keuangan Anda.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div
            className={`p-5 rounded-2xl border transition-all ${
              isDarkMode
                ? 'bg-[#0D1E16] border-[#1E4330]'
                : 'bg-white border-gray-200 shadow-sm hover:shadow-md'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-[#113C2B] flex items-center justify-center mb-3">
              <Lock className="w-5 h-5 text-[#6BCB37]" />
            </div>
            <h3 className="text-base font-bold text-gray-900 dark:text-white">
              Enkripsi PIN PBKDF2 &amp; SHA-256
            </h3>
            <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mt-1.5 leading-relaxed">
              Setiap transaksi finansial wajib diautentikasi dengan 6-digit PIN yang terenkripsi
              Salted SHA-256 dan PBKDF2 di sisi server.
            </p>
          </div>

          <div
            className={`p-5 rounded-2xl border transition-all ${
              isDarkMode
                ? 'bg-[#0D1E16] border-[#1E4330]'
                : 'bg-white border-gray-200 shadow-sm hover:shadow-md'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-[#113C2B] flex items-center justify-center mb-3">
              <Fingerprint className="w-5 h-5 text-[#6BCB37]" />
            </div>
            <h3 className="text-base font-bold text-gray-900 dark:text-white">
              Biometrik &amp; Kontrol Perangkat
            </h3>
            <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mt-1.5 leading-relaxed">
              Pantau perangkat yang terhubung ke akun Anda dan cabut sesi perangkat yang tidak
              dikenali secara real-time melalui Pusat Keamanan.
            </p>
          </div>

          <div
            className={`p-5 rounded-2xl border transition-all ${
              isDarkMode
                ? 'bg-[#0D1E16] border-[#1E4330]'
                : 'bg-white border-gray-200 shadow-sm hover:shadow-md'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-[#113C2B] flex items-center justify-center mb-3">
              <ShieldCheck className="w-5 h-5 text-[#6BCB37]" />
            </div>
            <h3 className="text-base font-bold text-gray-900 dark:text-white">
              Standar QRIS Bank Indonesia
            </h3>
            <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mt-1.5 leading-relaxed">
              Dioperasikan oleh PT TO PAY Digital Lestari dengan dukungan standar nasional EMVCo
              QRIS Bank Indonesia &amp; ASPI serta proteksi anti-fraud.
            </p>
          </div>
        </div>
      </section>

      {/* Section 4: FAQ */}
      <section
        id="faq"
        aria-labelledby="heading-faq"
        className={`rounded-3xl p-6 sm:p-8 border ${
          isDarkMode
            ? 'bg-[#12281E] border-[#1E4330]'
            : 'bg-white border-gray-200 shadow-sm'
        }`}
      >
        <div className="mb-5">
          <h2
            id="heading-faq"
            className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white tracking-tight"
          >
            Pertanyaan yang Sering Diajukan (FAQ TO PAY)
          </h2>
          <p className="text-sm text-gray-600 dark:text-gray-300 mt-1.5">
            Informasi cepat seputar pendaftaran akun, top up saldo, QRIS, transfer, dan keamanan.
          </p>
        </div>

        <div className="space-y-3">
          {PUBLIC_FAQS.map((faq) => {
            const isOpen = openFaqId === faq.id;
            return (
              <div
                key={faq.id}
                className={`rounded-2xl border overflow-hidden transition-colors ${
                  isDarkMode
                    ? 'bg-[#0D1E16] border-[#1E4330]'
                    : 'bg-white border-gray-200 shadow-2xs'
                }`}
              >
                <button
                  type="button"
                  aria-expanded={isOpen}
                  onClick={() => setOpenFaqId(isOpen ? null : faq.id)}
                  className="w-full p-4 text-left flex items-center justify-between gap-3 cursor-pointer hover:bg-gray-50/70 dark:hover:bg-[#142D21] transition-colors"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2.5">
                    <span className="text-xs font-bold text-[#113C2B] dark:text-[#6BCB37] shrink-0">
                      {faq.category} ·
                    </span>
                    <h3 className="text-sm font-bold text-gray-900 dark:text-white">
                      {faq.question}
                    </h3>
                  </div>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-[#113C2B] dark:text-[#6BCB37] shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-gray-500 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 pt-2.5 text-xs sm:text-sm text-gray-600 dark:text-gray-300 leading-relaxed border-t border-gray-100 dark:border-[#1E4330]">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* Semantic Footer with Internal Links */}
      <footer
        className={`rounded-3xl p-6 border text-xs ${
          isDarkMode
            ? 'bg-[#12281E] border-[#1E4330] text-gray-300'
            : 'bg-white border-gray-200 shadow-sm text-gray-600'
        }`}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-gray-200 dark:border-[#1E4330]">
          <div>
            <p className="font-extrabold text-sm text-gray-900 dark:text-white">
              TO PAY – Pay Simple. Live Green.
            </p>
            <p className="mt-1 text-gray-600 dark:text-gray-300">
              Dioperasikan oleh PT TO PAY Digital Lestari · Berizin &amp; diawasi Bank Indonesia.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <a
              href={PUBLIC_CONTACT.mailtoHref}
              className="inline-flex items-center gap-1.5 font-bold text-[#113C2B] dark:text-[#6BCB37] hover:underline"
            >
              <Mail className="w-4 h-4" />
              <span>{PUBLIC_CONTACT.email}</span>
            </a>
            <a
              href={PUBLIC_CONTACT.phoneHref}
              className="inline-flex items-center gap-1.5 font-bold text-[#113C2B] dark:text-[#6BCB37] hover:underline"
            >
              <Phone className="w-4 h-4" />
              <span>{PUBLIC_CONTACT.phoneDisplay}</span>
            </a>
            <a
              href={PUBLIC_CONTACT.whatsappHref}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 font-bold text-[#113C2B] dark:text-[#6BCB37] hover:underline"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp CS</span>
            </a>
          </div>
        </div>

        <div className="pt-4 flex flex-wrap items-center justify-between gap-3">
          <nav aria-label="Navigasi Halaman Publik" className="flex flex-wrap items-center gap-5">
            <a
              href="/"
              onClick={(e) => handleLinkClick(e, '/')}
              className="font-semibold text-gray-700 dark:text-gray-300 hover:text-[#113C2B] dark:hover:text-[#6BCB37] hover:underline"
            >
              Beranda
            </a>
            <a
              href="/layanan"
              onClick={(e) => handleLinkClick(e, '/layanan', 'layanan')}
              className="font-semibold text-gray-700 dark:text-gray-300 hover:text-[#113C2B] dark:hover:text-[#6BCB37] hover:underline"
            >
              Layanan
            </a>
            <a
              href="/promo"
              onClick={(e) => handleLinkClick(e, '/promo', 'promo')}
              className="font-semibold text-gray-700 dark:text-gray-300 hover:text-[#113C2B] dark:hover:text-[#6BCB37] hover:underline"
            >
              Promo
            </a>
            <a
              href="/keamanan"
              onClick={(e) => handleLinkClick(e, '/keamanan', 'keamanan')}
              className="font-semibold text-gray-700 dark:text-gray-300 hover:text-[#113C2B] dark:hover:text-[#6BCB37] hover:underline"
            >
              Keamanan
            </a>
            <a
              href="/faq"
              onClick={(e) => handleLinkClick(e, '/faq', 'faq')}
              className="font-semibold text-gray-700 dark:text-gray-300 hover:text-[#113C2B] dark:hover:text-[#6BCB37] hover:underline"
            >
              FAQ
            </a>
          </nav>

          <div className="flex items-center gap-4">
            {onOpenLegal && (
              <>
                <button
                  type="button"
                  onClick={() => onOpenLegal('terms')}
                  className="font-semibold text-gray-700 dark:text-gray-300 hover:text-[#113C2B] dark:hover:text-[#6BCB37] hover:underline cursor-pointer"
                >
                  Syarat &amp; Ketentuan
                </button>
                <button
                  type="button"
                  onClick={() => onOpenLegal('privacy')}
                  className="font-semibold text-gray-700 dark:text-gray-300 hover:text-[#113C2B] dark:hover:text-[#6BCB37] hover:underline cursor-pointer"
                >
                  Kebijakan Privasi
                </button>
              </>
            )}
          </div>
        </div>
      </footer>
    </div>
  );
};
