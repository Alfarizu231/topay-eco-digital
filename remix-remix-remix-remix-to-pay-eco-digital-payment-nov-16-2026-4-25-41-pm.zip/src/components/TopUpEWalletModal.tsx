import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Check, ArrowRight, ShieldCheck, Phone, Sparkles } from 'lucide-react';
import { EWalletProvider } from '../types';

interface TopUpEWalletModalProps {
  providers: EWalletProvider[];
  userPhone: string;
  onClose: () => void;
  onSubmitTopUp: (data: {
    provider: EWalletProvider;
    amount: number;
    phone: string;
    adminFee: number;
  }) => void;
  isDarkMode?: boolean;
}

export const TopUpEWalletModal: React.FC<TopUpEWalletModalProps> = ({
  providers,
  userPhone,
  onClose,
  onSubmitTopUp,
  isDarkMode = false,
}) => {
  const [selectedProviderId, setSelectedProviderId] = useState<string>('gopay');
  const [targetPhone, setTargetPhone] = useState<string>(userPhone.replace('+62 ', '0'));
  const [selectedAmount, setSelectedAmount] = useState<number>(100000);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [isCustom, setIsCustom] = useState<boolean>(false);
  const [step, setStep] = useState<'select' | 'confirm'>('select');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const presetAmounts = [20000, 50000, 100000, 200000, 500000, 1000000];

  const selectedProvider = providers.find((p) => p.id === selectedProviderId) || providers[0];
  const finalAmount = isCustom ? Number(customAmount) || 0 : selectedAmount;
  const adminFee = selectedProvider.fee;
  const totalPayment = finalAmount + adminFee;

  const handleContinue = () => {
    if (finalAmount < selectedProvider.minAmount) {
      setErrorMsg(`Minimal top up adalah Rp${selectedProvider.minAmount.toLocaleString('id-ID')}.`);
      return;
    }
    if (!targetPhone || targetPhone.replace(/\D/g, '').length < 9) {
      setErrorMsg('Masukkan nomor telepon tujuan yang valid.');
      return;
    }
    setErrorMsg(null);
    setStep('confirm');
  };

  const handleFinalSubmit = () => {
    onSubmitTopUp({
      provider: selectedProvider,
      amount: finalAmount,
      phone: targetPhone,
      adminFee,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className={`w-full max-w-lg rounded-2xl p-5 sm:p-6 shadow-2xl border ${
          isDarkMode ? 'bg-[#12281E] border-[#1E4330] text-white' : 'bg-white border-[#E2ECE5] text-[#0F2D1F]'
        }`}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-gray-100 dark:border-gray-800">
          <div>
            <h2 className="text-lg font-bold text-[#143D28] dark:text-white">
              {step === 'select' ? 'Top Up E-Wallet' : 'Konfirmasi Pembayaran'}
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Isi saldo dompet digital instan & aman
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {step === 'select' ? (
          <div className="mt-4 space-y-4 max-h-[75vh] overflow-y-auto pr-1">
            {/* E-Wallet Grid Selector */}
            <div>
              <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-2">
                Pilih E-Wallet
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {providers.map((p) => {
                  const isSelected = p.id === selectedProviderId;
                  return (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setSelectedProviderId(p.id)}
                      className={`p-3 rounded-xl border flex flex-col items-center justify-center transition-all cursor-pointer ${
                        isSelected
                          ? isDarkMode
                            ? 'bg-[#1A3D2A] border-[#6BCB37] ring-2 ring-[#6BCB37]/40 text-white font-bold'
                            : 'bg-[#EAF6EE] border-[#143D28] ring-2 ring-[#143D28]/20 text-[#143D28] font-bold shadow-xs'
                          : isDarkMode
                            ? 'bg-[#0A1610] border-[#1E4330] text-gray-300 hover:bg-[#163826]'
                            : 'bg-white border-[#E2ECE5] text-gray-700 hover:bg-[#F8FAF8]'
                      }`}
                    >
                      <div
                        className={`w-9 h-9 rounded-full flex items-center justify-center font-black text-sm mb-1.5 ${
                          isSelected
                            ? 'bg-[#143D28] text-[#6BCB37]'
                            : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300'
                        }`}
                      >
                        {p.logoText}
                      </div>
                      <span className="text-xs">{isSelected ? `✓ ${p.name}` : p.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Target Phone Input */}
            <div>
              <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1.5">
                Nomor HP {selectedProvider.name}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                  <Phone className="w-4 h-4 text-[#143D28] dark:text-[#6BCB37]" />
                </div>
                <input
                  type="text"
                  value={targetPhone}
                  onChange={(e) => setTargetPhone(e.target.value)}
                  placeholder="0812xxxx"
                  className={`w-full pl-9 pr-3.5 py-2.5 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-[#6BCB37] ${
                    isDarkMode
                      ? 'bg-[#0A1610] border-[#1E4330] text-white'
                      : 'bg-[#F4FAF6] border-[#D7EFE0] text-[#0F2D1F]'
                  }`}
                />
              </div>
            </div>

            {/* Preset Nominal Grid */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-bold text-[#143D28] dark:text-gray-200">
                  Pilih Nominal
                </label>
                <button
                  type="button"
                  onClick={() => setIsCustom(!isCustom)}
                  className="text-xs font-semibold text-[#143D28] dark:text-[#6BCB37] hover:underline cursor-pointer"
                >
                  {isCustom ? 'Gunakan Pilihan Cepat' : 'Ketik Nominal Lain'}
                </button>
              </div>

              {isCustom ? (
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-sm font-bold text-gray-500">
                    Rp
                  </span>
                  <input
                    type="number"
                    value={customAmount}
                    onChange={(e) => setCustomAmount(e.target.value)}
                    placeholder="Contoh: 150000"
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#6BCB37] ${
                      isDarkMode
                        ? 'bg-[#0A1610] border-[#1E4330] text-white'
                        : 'bg-[#F4FAF6] border-[#D7EFE0] text-[#0F2D1F]'
                    }`}
                  />
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-2.5">
                  {presetAmounts.map((amt) => {
                    const isSelected = selectedAmount === amt;
                    return (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => {
                          setSelectedAmount(amt);
                          setIsCustom(false);
                        }}
                        className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                          isSelected
                            ? isDarkMode
                              ? 'bg-[#1A3D2A] border-[#6BCB37] text-white font-bold'
                              : 'bg-[#EAF6EE] border-[#143D28] text-[#143D28] font-bold shadow-xs'
                            : isDarkMode
                              ? 'bg-[#0A1610] border-[#1E4330] text-gray-300 hover:bg-[#163826]'
                              : 'bg-white border-[#E2ECE5] text-gray-700 hover:bg-[#F8FAF8]'
                        }`}
                      >
                        <div className="text-xs sm:text-sm font-bold">
                          Rp{amt.toLocaleString('id-ID')}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Eco summary banner */}
            <div className="p-3 rounded-xl bg-[#F0FAF3] dark:bg-[#1A3828] border border-[#D7EFE0] dark:border-[#204E38] flex items-center justify-between text-xs text-[#143D28] dark:text-[#A3E635]">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#6BCB37]" />
                <span>Bonus 10 Eco Points untuk transaksi ini</span>
              </div>
              <span className="font-bold">Biaya Admin: Rp{adminFee.toLocaleString('id-ID')}</span>
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-xs font-semibold text-rose-700 dark:text-rose-200">
                {errorMsg}
              </div>
            )}

            {/* Submit Button */}
            <button
              type="button"
              onClick={handleContinue}
              className="w-full py-3 px-4 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
            >
              <span>Lanjutkan</span>
              <ArrowRight className="w-4 h-4 text-[#6BCB37]" />
            </button>
          </div>
        ) : (
          /* Confirmation Screen */
          <div className="mt-4 space-y-4">
            <div className="p-4 rounded-xl bg-[#F4FAF6] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] space-y-3">
              <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400">
                <span>E-Wallet Tujuan</span>
                <span className="font-bold text-[#143D28] dark:text-white flex items-center gap-1">
                  <Check className="w-3.5 h-3.5 text-[#6BCB37]" />
                  {selectedProvider.name}
                </span>
              </div>

              <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400">
                <span>Nomor Tujuan</span>
                <span className="font-bold text-[#143D28] dark:text-white font-mono">
                  {targetPhone}
                </span>
              </div>

              <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400">
                <span>Nominal Top Up</span>
                <span className="font-bold text-[#143D28] dark:text-white">
                  Rp{finalAmount.toLocaleString('id-ID')}
                </span>
              </div>

              <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400">
                <span>Biaya Transaksi</span>
                <span className="font-bold text-[#143D28] dark:text-white">
                  Rp{adminFee.toLocaleString('id-ID')}
                </span>
              </div>

              <div className="pt-2 border-t border-gray-200 dark:border-gray-800 flex justify-between items-center">
                <span className="text-sm font-bold text-[#143D28] dark:text-white">
                  Total Pembayaran
                </span>
                <span className="text-base font-extrabold text-[#143D28] dark:text-[#6BCB37]">
                  Rp{totalPayment.toLocaleString('id-ID')}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
              <ShieldCheck className="w-4 h-4 text-[#6BCB37]" />
              <span>Diverifikasi dengan PIN Keamanan TO PAY</span>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep('select')}
                className="py-2.5 px-3 rounded-xl border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 font-semibold text-xs hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
              >
                Kembali
              </button>
              <button
                type="button"
                onClick={handleFinalSubmit}
                className="py-2.5 px-3 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4 text-[#6BCB37]" />
                Konfirmasi & Bayar
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};
