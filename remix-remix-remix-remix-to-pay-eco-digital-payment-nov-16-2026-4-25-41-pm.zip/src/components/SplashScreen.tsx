import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { ToPayLogo } from './ToPayLogo';

interface SplashScreenProps {
  onFinish: () => void;
  isDarkMode?: boolean;
}

const BRAND_LOGO_SRC = '/assets/aistudio/IMG-20261113-WA0018_542ce974.jpg';

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish, isDarkMode = false }) => {
  const [progress, setProgress] = useState(0);
  const [logoImgFailed, setLogoImgFailed] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onFinish, 400);
          return 100;
        }
        return prev + 20;
      });
    }, 280);

    return () => clearInterval(timer);
  }, [onFinish]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-between p-8 ${
        isDarkMode ? 'bg-[#0A1610] text-white' : 'bg-[#F5F9F6] text-gray-900'
      }`}
    >
      <div className="w-full flex justify-end">
        <span className="text-xs font-semibold text-gray-600 dark:text-[#6BCB37]">
          Eco Digital Payment
        </span>
      </div>

      {/* Center Logo & Tagline */}
      <div className="flex flex-col items-center text-center space-y-5 max-w-sm">
        <motion.div
          initial={{ scale: 0.88, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.45, ease: 'easeOut' }}
        >
          {!logoImgFailed ? (
            <img
              src={BRAND_LOGO_SRC}
              alt="TO PAY Logo"
              onError={() => setLogoImgFailed(true)}
              className={`w-36 h-auto object-contain mx-auto ${
                isDarkMode
                  ? 'bg-white/95 rounded-2xl p-3'
                  : 'mix-blend-multiply'
              }`}
            />
          ) : (
            <ToPayLogo
              size="xl"
              showText={true}
              variant={isDarkMode ? 'white' : 'default'}
            />
          )}
        </motion.div>

        <motion.div
          initial={{ y: 12, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.15, duration: 0.35 }}
          className="space-y-1.5"
        >
          <p className="text-sm md:text-base font-bold text-[#113C2B] dark:text-[#A3E635]">
            Pay Simple. Live Green.
          </p>
          <p className="text-xs text-gray-600 dark:text-gray-300 max-w-xs leading-relaxed">
            Aplikasi pembayaran digital cerdas, cepat, dan ramah lingkungan.
          </p>
        </motion.div>

        {/* Progress Bar */}
        <div className="w-48 space-y-2.5 pt-2">
          <div className="h-1.5 w-full bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-[#113C2B] dark:bg-[#6BCB37] rounded-full"
              initial={{ width: '0%' }}
              animate={{ width: `${progress}%` }}
              transition={{ ease: 'easeInOut' }}
            />
          </div>
          <p className="text-[11px] font-medium text-gray-600 dark:text-gray-400">
            Memuat sistem aman... {progress}%
          </p>
        </div>
      </div>

      {/* Footer info */}
      <div className="text-center space-y-1">
        <button
          type="button"
          onClick={onFinish}
          className="text-xs font-bold text-[#113C2B] dark:text-[#6BCB37] hover:underline cursor-pointer py-2 px-4"
        >
          Lewati Intro →
        </button>
        <p className="text-[10px] text-gray-500 dark:text-gray-400">
          Berlisensi &amp; diawasi Bank Indonesia • Standar Keamanan ISO 27001
        </p>
      </div>
    </motion.div>
  );
};
