import React, { useState, useEffect } from 'react';
import { authFetch } from '../utils/authFetch';
import { motion } from 'motion/react';
import {
  X,
  ArrowDownLeft,
  ArrowUpRight,
  PieChart as PieIcon,
  ShieldCheck,
  Activity,
  Loader2,
} from 'lucide-react';
import { CashFlowSummary } from '../types';

interface CashFlowDashboardModalProps {
  onClose: () => void;
  isDarkMode?: boolean;
  onRefreshData?: () => void;
}

export const CashFlowDashboardModal: React.FC<CashFlowDashboardModalProps> = ({
  onClose,
  isDarkMode = false,
}) => {
  const [chartPeriod, setChartPeriod] = useState<'daily' | 'weekly' | 'monthly'>('weekly');
  const [cashFlowData, setCashFlowData] = useState<CashFlowSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = async () => {
    try {
      setIsLoading(true);
      const cfRes = await authFetch('/api/cashflow/summary');
      if (cfRes.ok) {
        const cfJson = await cfRes.json();
        if (cfJson.success && cfJson.summary) {
          setCashFlowData(cfJson.summary);
        }
      }
    } catch (err) {
      console.error('Failed to load personal cash flow:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const chartPoints = cashFlowData?.chartData?.[chartPeriod] || [];
  const hasChartActivity = chartPoints.some((p) => p.income > 0 || p.expense > 0);
  const maxVal = hasChartActivity
    ? Math.max(...chartPoints.map((p) => Math.max(p.income, p.expense, 1)))
    : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/65 backdrop-blur-xs">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className={`w-full max-w-3xl max-h-[92vh] flex flex-col rounded-2xl shadow-2xl border overflow-hidden ${
          isDarkMode ? 'bg-[#0E2018] border-[#1E4330] text-white' : 'bg-[#FAFCFA] border-[#D7EFE0] text-[#0F2D1F]'
        }`}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#E2ECE5] dark:border-[#1E4330] flex items-center justify-between bg-white dark:bg-[#12281E] flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#EAF6EE] dark:bg-[#183827] flex items-center justify-center text-[#143D28] dark:text-[#6BCB37]">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-[#143D28] dark:text-white">
                Ringkasan Arus Kas Pribadi
              </h2>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Pantau pemasukan dan pengeluaran pribadi akun TO PAY Anda
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {isLoading ? (
            <div className="py-16 flex flex-col items-center justify-center gap-2 text-xs text-gray-500 dark:text-gray-400">
              <Loader2 className="w-6 h-6 animate-spin text-[#16A34A]" />
              <span>Memuat ringkasan arus kas...</span>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Metric Cards Top */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Inflow Card */}
                <div className="p-4 rounded-xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs">
                  <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                    <span className="font-semibold">Total Pemasukan</span>
                    <div className="w-7 h-7 rounded-lg bg-[#EAF6EE] dark:bg-[#183827] flex items-center justify-center text-[#16A34A]">
                      <ArrowDownLeft className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-[#16A34A] dark:text-[#6BCB37] mt-2">
                    +Rp{(cashFlowData?.totalIncome || 0).toLocaleString('id-ID')}
                  </div>
                  <div className="text-[11px] text-gray-500 mt-1">
                    {cashFlowData?.incomeCount || 0} transaksi masuk
                  </div>
                </div>

                {/* Outflow Card */}
                <div className="p-4 rounded-xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330] shadow-xs">
                  <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                    <span className="font-semibold">Total Pengeluaran</span>
                    <div className="w-7 h-7 rounded-lg bg-rose-50 dark:bg-rose-950/40 flex items-center justify-center text-rose-600">
                      <ArrowUpRight className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-rose-600 dark:text-rose-400 mt-2">
                    -Rp{(cashFlowData?.totalExpense || 0).toLocaleString('id-ID')}
                  </div>
                  <div className="text-[11px] text-gray-500 mt-1">
                    {cashFlowData?.expenseCount || 0} transaksi keluar
                  </div>
                </div>

                {/* Net Flow Card */}
                <div className="p-4 rounded-xl bg-gradient-to-br from-[#143D28] to-[#0E2C1D] text-white shadow-md border border-[#20553A]">
                  <div className="flex items-center justify-between text-xs text-emerald-100/90">
                    <span className="font-semibold">Saldo Akun Saat Ini</span>
                    <ShieldCheck className="w-4 h-4 text-[#A3E635]" />
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-white mt-2">
                    Rp{(cashFlowData?.currentBalance || 0).toLocaleString('id-ID')}
                  </div>
                  <div className="text-[11px] text-emerald-200/90 mt-1 flex items-center gap-1">
                    <span>Selisih Arus Kas:</span>
                    <span className="font-bold">
                      {(cashFlowData?.netCashFlow || 0) >= 0 ? '+' : ''}
                      Rp{(cashFlowData?.netCashFlow || 0).toLocaleString('id-ID')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Cash Flow Visual Bar Chart */}
              <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330]">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-gray-100 dark:border-gray-800">
                  <div>
                    <h3 className="text-sm font-extrabold text-[#143D28] dark:text-white flex items-center gap-1.5">
                      <PieIcon className="w-4 h-4 text-[#16A34A] dark:text-[#6BCB37]" />
                      <span>Grafik Pemasukan vs Pengeluaran</span>
                    </h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Perbandingan aktivitas keuangan pribadi Anda
                    </p>
                  </div>

                  <div className="flex items-center gap-1 bg-[#F4FAF6] dark:bg-[#0A1610] p-1 rounded-lg border border-[#D7EFE0] dark:border-[#1E4330]">
                    {(['daily', 'weekly', 'monthly'] as const).map((p) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => setChartPeriod(p)}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-bold capitalize transition-all cursor-pointer ${
                          chartPeriod === p
                            ? 'bg-[#143D28] text-white shadow-xs'
                            : 'text-gray-500 hover:text-gray-900 dark:hover:text-white'
                        }`}
                      >
                        {p === 'daily' ? 'Harian' : p === 'weekly' ? 'Mingguan' : 'Bulanan'}
                      </button>
                    ))}
                  </div>
                </div>

                {!hasChartActivity ? (
                  <div className="py-12 text-center text-xs text-gray-500 dark:text-gray-400">
                    Belum ada aktivitas pemasukan atau pengeluaran yang tercatat pada periode ini.
                  </div>
                ) : (
                  <div className="pt-6 pb-2">
                    <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 sm:gap-4 items-end h-48">
                      {chartPoints.map((item, idx) => {
                        const incHeight = maxVal > 0 ? (item.income / maxVal) * 100 : 0;
                        const expHeight = maxVal > 0 ? (item.expense / maxVal) * 100 : 0;
                        return (
                          <div key={idx} className="flex flex-col items-center gap-2 h-full justify-end">
                            <div className="flex items-end gap-1 sm:gap-1.5 h-36 w-full justify-center">
                              {/* Income Bar */}
                              <div
                                style={{ height: `${item.income > 0 ? Math.max(8, incHeight) : 2}%` }}
                                className="w-3.5 sm:w-5 bg-[#16A34A] rounded-t-md transition-all hover:opacity-85 relative group"
                              >
                                <div className="absolute -top-7 left-1/2 -translate-x-1/2 hidden group-hover:block bg-black text-white text-[10px] px-1.5 py-0.5 rounded whitespace-nowrap z-20 font-mono">
                                  +Rp{item.income.toLocaleString('id-ID')}
                                </div>
                              </div>
                              {/* Expense Bar */}
                              <div
                                style={{ height: `${item.expense > 0 ? Math.max(8, expHeight) : 2}%` }}
                                className="w-3.5 sm:w-5 bg-[#EF4444] rounded-t-md transition-all hover:opacity-85 relative group"
                              >
                                <div className="absolute -top-7 left-1/2 -translate-x-1/2 hidden group-hover:block bg-black text-white text-[10px] px-1.5 py-0.5 rounded whitespace-nowrap z-20 font-mono">
                                  -Rp{item.expense.toLocaleString('id-ID')}
                                </div>
                              </div>
                            </div>
                            <span className="text-[11px] font-bold text-gray-500 dark:text-gray-400 truncate">
                              {item.period}
                            </span>
                          </div>
                        );
                      })}
                    </div>

                    <div className="flex items-center justify-center gap-6 mt-4 pt-3 border-t border-gray-100 dark:border-gray-800 text-xs">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-xs bg-[#16A34A]" />
                        <span className="text-gray-600 dark:text-gray-300 font-medium">Uang Masuk</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-xs bg-[#EF4444]" />
                        <span className="text-gray-600 dark:text-gray-300 font-medium">Uang Keluar</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Category Breakdowns */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Expense Categories */}
                <div className="p-4 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330]">
                  <h4 className="text-xs font-bold text-[#143D28] dark:text-white uppercase tracking-wider mb-3">
                    Distribusi Pengeluaran
                  </h4>
                  <div className="space-y-2.5">
                    {cashFlowData?.categoryBreakdown?.expense && cashFlowData.categoryBreakdown.expense.length > 0 ? (
                      cashFlowData.categoryBreakdown.expense.map((cat, i) => (
                        <div key={i} className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="font-semibold text-gray-700 dark:text-gray-300">{cat.category}</span>
                            <span className="font-mono font-bold text-rose-600 dark:text-rose-400">
                              Rp{cat.amount.toLocaleString('id-ID')} ({cat.percentage}%)
                            </span>
                          </div>
                          <div className="h-1.5 w-full bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                            <div
                              style={{ width: `${cat.percentage}%`, backgroundColor: cat.color }}
                              className="h-full rounded-full transition-all"
                            />
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-gray-400">Belum ada data pengeluaran.</p>
                    )}
                  </div>
                </div>

                {/* Income Categories */}
                <div className="p-4 rounded-2xl bg-white dark:bg-[#12281E] border border-[#E2ECE5] dark:border-[#1E4330]">
                  <h4 className="text-xs font-bold text-[#143D28] dark:text-white uppercase tracking-wider mb-3">
                    Sumber Pemasukan
                  </h4>
                  <div className="space-y-2.5">
                    {cashFlowData?.categoryBreakdown?.income && cashFlowData.categoryBreakdown.income.length > 0 ? (
                      cashFlowData.categoryBreakdown.income.map((cat, i) => (
                        <div key={i} className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="font-semibold text-gray-700 dark:text-gray-300">{cat.category}</span>
                            <span className="font-mono font-bold text-[#16A34A] dark:text-[#6BCB37]">
                              Rp{cat.amount.toLocaleString('id-ID')} ({cat.percentage}%)
                            </span>
                          </div>
                          <div className="h-1.5 w-full bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                            <div
                              style={{ width: `${cat.percentage}%`, backgroundColor: cat.color }}
                              className="h-full rounded-full transition-all"
                            />
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-gray-400">Belum ada data pemasukan.</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
