import React, { useState } from 'react';
import { authFetch } from '../utils/authFetch';
import { motion } from 'motion/react';
import {
  User,
  ShieldCheck,
  KeyRound,
  Fingerprint,
  Smartphone,
  Bell,
  HelpCircle,
  FileText,
  Lock,
  LogOut,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { UserProfile } from '../types';

interface ProfileScreenProps {
  user: UserProfile;
  onOpenSecurity: () => void;
  onOpenEditProfile: () => void;
  onOpenChangePin: () => void;
  onOpenConnectedDevices: () => void;
  onOpenHelpCenter: () => void;
  onOpenLegalTerms: () => void;
  onOpenLegalPrivacy: () => void;
  onLogout: () => void;
  onNotificationToggled?: (val: boolean) => void;
  onBiometricToggled?: (val: boolean) => void;
  isDarkMode?: boolean;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  user,
  onOpenSecurity,
  onOpenEditProfile,
  onOpenChangePin,
  onOpenConnectedDevices,
  onOpenHelpCenter,
  onOpenLegalTerms,
  onOpenLegalPrivacy,
  onLogout,
  onNotificationToggled,
  onBiometricToggled,
  isDarkMode = false,
}) => {
  const [activeNotification, setActiveNotification] = useState(
    user.isNotificationActive !== undefined ? user.isNotificationActive : true
  );
  const [activeBiometric, setActiveBiometric] = useState(user.isBiometricActive);
  const [showConfirmLogout, setShowConfirmLogout] = useState(false);

  // Handle Notification Toggle
  const handleToggleNotification = async () => {
    const nextVal = !activeNotification;
    setActiveNotification(nextVal);
    if (onNotificationToggled) onNotificationToggled(nextVal);

    try {
      await authFetch('/api/settings/notifications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: nextVal }),
      });
    } catch (err) {
      console.error('Error saving notification preference:', err);
    }
  };

  // Handle Biometric Toggle
  const handleToggleBiometric = async () => {
    const nextVal = !activeBiometric;
    setActiveBiometric(nextVal);
    if (onBiometricToggled) onBiometricToggled(nextVal);

    try {
      await authFetch('/api/settings/biometric', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: nextVal }),
      });
    } catch (err) {
      console.error('Error saving biometric preference:', err);
    }
  };

  const menuItems = [
    {
      id: 'personal',
      label: 'Data Pribadi',
      sublabel: 'Ubah nama, username, nomor HP & email',
      icon: User,
      action: onOpenEditProfile,
    },
    {
      id: 'security',
      label: 'Pusat Keamanan Akun',
      sublabel: `Skor Proteksi: ${user.securityScore}/100`,
      icon: ShieldCheck,
      highlight: true,
      action: onOpenSecurity,
    },
    {
      id: 'pin',
      label: 'Ubah PIN',
      sublabel: 'Ganti 6-digit PIN keamanan transaksi',
      icon: KeyRound,
      action: onOpenChangePin,
    },
    {
      id: 'biometric',
      label: 'Biometric Login & Transaksi',
      sublabel: activeBiometric ? 'Aktif (Fingerprint & Face ID)' : 'Nonaktif',
      icon: Fingerprint,
      toggle: true,
      toggleValue: activeBiometric,
      action: handleToggleBiometric,
    },
    {
      id: 'devices',
      label: 'Perangkat Terhubung',
      sublabel: 'Kelola & cabut akses sesi perangkat login',
      icon: Smartphone,
      action: onOpenConnectedDevices,
    },
    {
      id: 'notifications',
      label: 'Notifikasi & Pengingat',
      sublabel: activeNotification ? 'Aktif (Transaksi & Promo Hijau)' : 'Nonaktif',
      icon: Bell,
      toggle: true,
      toggleValue: activeNotification,
      action: handleToggleNotification,
    },
    {
      id: 'help',
      label: 'Pusat Bantuan & CS 24 Jam',
      sublabel: 'FAQ, panduan transaksi & CS WhatsApp',
      icon: HelpCircle,
      action: onOpenHelpCenter,
    },
    {
      id: 'terms',
      label: 'Syarat & Ketentuan',
      sublabel: 'Ketentuan layanan & standar transaksi',
      icon: FileText,
      action: onOpenLegalTerms,
    },
    {
      id: 'privacy',
      label: 'Kebijakan Privasi',
      sublabel: 'Perlindungan data pribadi & enkripsi',
      icon: Lock,
      action: onOpenLegalPrivacy,
    },
  ];

  return (
    <div className="w-full space-y-4">
      {/* Title */}
      <div>
        <h1 className="text-xl font-extrabold text-[#143D28] dark:text-white">
          Akun & Pengaturan
        </h1>
        <p className="text-xs text-gray-500 dark:text-gray-400">
          Kelola profil, keamanan, dan preferensi akun TO PAY Anda
        </p>
      </div>

      {/* User Profile Card */}
      <div className={`p-4 sm:p-5 rounded-2xl border ${
        isDarkMode
          ? 'bg-[#12281E] border-[#1E4330]'
          : 'bg-white border-[#E2ECE5] shadow-xs'
      }`}>
        <div className="flex items-start justify-between gap-3.5">
          <div className="flex items-center gap-3.5">
            {/* Avatar with Lime ring and click to edit */}
            <div
              onClick={onOpenEditProfile}
              className="relative cursor-pointer group"
              title="Klik untuk ubah foto & profil"
            >
              {user.avatarUrl ? (
                <img
                  src={user.avatarUrl}
                  alt={user.name || 'Profil Pengguna'}
                  className="w-14 h-14 rounded-2xl object-cover ring-2 ring-[#6BCB37] border-2 border-white dark:border-[#143D28] group-hover:opacity-90 transition-opacity"
                />
              ) : (
                <div className="w-14 h-14 rounded-2xl bg-[#143D28] text-[#6BCB37] font-extrabold text-lg flex items-center justify-center ring-2 ring-[#6BCB37] border-2 border-white dark:border-[#143D28]">
                  {(user.name || 'U').trim().charAt(0).toUpperCase()}
                </div>
              )}
              <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-[#143D28] border-2 border-white dark:border-[#12281E] flex items-center justify-center text-[9px] text-[#6BCB37]">
                ✓
              </span>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-base font-extrabold text-[#143D28] dark:text-white truncate">
                  {user.name}
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#EAF6EE] text-[#143D28] dark:bg-[#1B3A29] dark:text-[#6BCB37] border border-[#D7EFE0] dark:border-[#224E38]">
                  {user.membershipTier}
                </span>
              </div>
              <p className="text-xs font-semibold text-emerald-700 dark:text-[#6BCB37]">
                {user.username}
              </p>
              <p className="text-xs font-mono text-gray-500 dark:text-gray-400 mt-0.5">
                {user.phone} • {user.email}
              </p>
            </div>
          </div>

          {/* Quick Edit Profile Button */}
          <button
            id="btn-edit-profile-card"
            onClick={onOpenEditProfile}
            className="px-3 py-1.5 rounded-xl bg-[#EAF6EE] dark:bg-[#1A3828] text-[#143D28] dark:text-[#6BCB37] hover:bg-[#D7EFE0] text-xs font-bold transition-all shrink-0 border border-[#D7EFE0] dark:border-[#224E38] cursor-pointer"
          >
            Edit Profil
          </button>
        </div>

        {/* Eco impact summary card */}
        <div className="mt-3.5 pt-3.5 border-t border-gray-100 dark:border-gray-800 grid grid-cols-3 gap-2 text-center">
          <div className="p-2 rounded-xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330]">
            <div className="text-[10px] text-gray-500 dark:text-gray-400">Eco Points</div>
            <div className="text-xs sm:text-sm font-black text-[#143D28] dark:text-[#6BCB37]">
              {user.ecoPoints.toLocaleString('id-ID')}
            </div>
          </div>
          <div className="p-2 rounded-xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330]">
            <div className="text-[10px] text-gray-500 dark:text-gray-400">Pohon Ditanam</div>
            <div className="text-xs sm:text-sm font-black text-[#143D28] dark:text-[#6BCB37]">
              {user.treesPlanted} Bibit
            </div>
          </div>
          <div className="p-2 rounded-xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330]">
            <div className="text-[10px] text-gray-500 dark:text-gray-400">Hemat CO₂</div>
            <div className="text-xs sm:text-sm font-black text-[#143D28] dark:text-[#6BCB37]">
              {user.co2SavedKg} kg
            </div>
          </div>
        </div>
      </div>

      {/* Profile Menu List */}
      <div className={`rounded-2xl border divide-y divide-gray-100 dark:divide-gray-800 overflow-hidden ${
        isDarkMode ? 'bg-[#12281E] border-[#1E4330]' : 'bg-white border-[#E2ECE5] shadow-xs'
      }`}>
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.id}
              onClick={item.action}
              className={`p-3.5 sm:p-4 flex items-center justify-between transition-colors cursor-pointer ${
                isDarkMode ? 'hover:bg-[#183827]' : 'hover:bg-[#F8FAF8]'
              } ${item.highlight ? 'bg-[#F0FAF3]/60 dark:bg-[#1A3828]/40' : ''}`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  item.highlight
                    ? 'bg-[#143D28] text-[#6BCB37]'
                    : isDarkMode
                      ? 'bg-[#1A3828] text-[#6BCB37]'
                      : 'bg-[#EAF6EE] text-[#143D28]'
                }`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs sm:text-sm font-bold text-[#143D28] dark:text-white">
                    {item.label}
                  </div>
                  <div className="text-[11px] text-gray-500 dark:text-gray-400">
                    {item.sublabel}
                  </div>
                </div>
              </div>

              {item.toggle ? (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    item.action();
                  }}
                  className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                    item.toggleValue ? 'bg-[#143D28]' : 'bg-gray-300 dark:bg-gray-700'
                  }`}
                >
                  <span
                    className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${
                      item.toggleValue ? 'right-0.5' : 'left-0.5'
                    }`}
                  />
                </button>
              ) : (
                <ChevronRight className="w-4 h-4 text-gray-400" />
              )}
            </div>
          );
        })}

        {/* Logout Menu */}
        <div
          id="btn-profile-logout"
          onClick={() => setShowConfirmLogout(true)}
          className={`p-3.5 sm:p-4 flex items-center justify-between text-rose-600 transition-colors cursor-pointer ${
            isDarkMode ? 'hover:bg-[#183827]' : 'hover:bg-rose-50/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/30 flex items-center justify-center text-rose-600">
              <LogOut className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold">Keluar Akun</div>
              <div className="text-[11px] text-gray-400">Keluar dari sesi akun saat ini</div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-gray-400" />
        </div>
      </div>

      {/* Confirmation Modal Logout */}
      {showConfirmLogout && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            className={`w-full max-w-sm rounded-2xl p-5 sm:p-6 shadow-xl border ${
              isDarkMode ? 'bg-[#12281E] border-[#1E4330] text-white' : 'bg-white border-gray-100 text-slate-900'
            }`}
          >
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-200 dark:border-rose-900/50">
              <LogOut className="w-6 h-6" />
            </div>

            <h3 className="text-base sm:text-lg font-bold text-center mb-1.5">
              Apakah kamu yakin ingin keluar dari akun?
            </h3>
            <p className="text-xs text-center text-gray-500 dark:text-gray-400 mb-6 leading-relaxed">
              Anda dapat masuk kembali kapan saja. Saldo, foto profil, dan seluruh riwayat transaksi Anda tetap aman tersimpan.
            </p>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                id="btn-cancel-logout"
                onClick={() => setShowConfirmLogout(false)}
                className={`w-full py-2.5 px-4 rounded-xl text-xs sm:text-sm font-semibold border transition-all cursor-pointer ${
                  isDarkMode
                    ? 'bg-[#1A3828] hover:bg-[#224A35] border-[#25543B] text-gray-200'
                    : 'bg-gray-100 hover:bg-gray-200 border-gray-200 text-gray-700'
                }`}
              >
                Batal
              </button>
              <button
                type="button"
                id="btn-confirm-logout"
                onClick={() => {
                  setShowConfirmLogout(false);
                  onLogout();
                }}
                className="w-full py-2.5 px-4 rounded-xl text-xs sm:text-sm font-semibold bg-rose-600 hover:bg-rose-700 text-white shadow-sm hover:shadow transition-all cursor-pointer"
              >
                Keluar
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};
