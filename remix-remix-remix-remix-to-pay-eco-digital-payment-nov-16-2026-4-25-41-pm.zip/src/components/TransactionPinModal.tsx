import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Lock,
  Delete,
  ShieldCheck,
  AlertCircle,
  Loader2,
  HelpCircle,
  Clock,
  ArrowRight,
  Sparkles,
  Wallet,
  ShieldAlert,
} from 'lucide-react';
import { Transaction } from '../types';
import { ForgotPinModal } from './ForgotPinModal';
import { authFetch } from '../utils/authFetch';

export interface TransactionSummaryData {
  title: string;
  recipientOrSender: string;
  accountNumber?: string;
  amount: number;
  fee?: number;
  type: string;
  category: string;
  note?: string;
  merchantNmid?: string;
  direction?: 'in' | 'out';
}

interface TransactionPinModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactionData: TransactionSummaryData;
  userBalance?: number;
  onSuccess: (result: { transaction: Transaction; newBalance: number }) => void;
  isDarkMode?: boolean;
}

export const TransactionPinModal: React.FC<TransactionPinModalProps> = ({
  isOpen,
  onClose,
  transactionData,
  userBalance = 0,
  onSuccess,
  isDarkMode = false,
}) => {
  const [pin, setPin] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [remainingAttempts, setRemainingAttempts] = useState<number | null>(null);
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [lockoutSeconds, setLockoutSeconds] = useState<number | null>(null);
  const [shake, setShake] = useState<boolean>(false);
  const [showForgotPin, setShowForgotPin] = useState<boolean>(false);

  // Generate unique idempotency key for this transaction instance
  const [idempotencyKey] = useState<string>(() => `topay_tx_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`);

  const amount = transactionData.amount || 0;
  const fee = transactionData.fee || 0;
  const totalDeduction = amount + fee;
  const balanceAfter = Math.max(0, userBalance - totalDeduction);

  // Countdown timer for lockout
  useEffect(() => {
    if (lockoutSeconds === null || lockoutSeconds <= 0) return;
    const interval = setInterval(() => {
      setLockoutSeconds((prev) => {
        if (prev === null || prev <= 1) {
          setIsLocked(false);
          setErrorMessage(null);
          return null;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [lockoutSeconds]);

  // Reset state when modal opens
  useEffect(() => {
    if (isOpen) {
      setPin('');
      setErrorMessage(null);
      setIsProcessing(false);
    }
  }, [isOpen]);

  // Trigger PIN verification when 6 digits are entered
  const executeTransactionWithPin = useCallback(
    async (pinToVerify: string) => {
      if (pinToVerify.length !== 6 || isProcessing || isLocked) return;

      setIsProcessing(true);
      setErrorMessage(null);

      try {
        let endpoint = '/api/transactions/create';
        let bodyPayload: any = {
          title: transactionData.title,
          category: transactionData.category,
          type: transactionData.type,
          amount: transactionData.amount,
          fee: transactionData.fee || 0,
          direction: transactionData.direction || (transactionData.type === 'topup' ? 'in' : 'out'),
          recipientOrSender: transactionData.recipientOrSender,
          accountNumber: transactionData.accountNumber,
          note: transactionData.note,
          pin: pinToVerify,
          idempotencyKey,
        };

        if (transactionData.type === 'qris') {
          endpoint = '/api/qris/payment/confirm';
          bodyPayload = {
            merchantName: transactionData.title,
            nmid: transactionData.merchantNmid || 'ID102938475610',
            amount: transactionData.amount,
            fee: transactionData.fee || 0,
            note: transactionData.note,
            pin: pinToVerify,
            idempotencyKey,
          };
        }

        const res = await authFetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(bodyPayload),
        });

        const data = await res.json();

        if (res.ok && data.success && data.transaction) {
          onSuccess({
            transaction: data.transaction,
            newBalance: data.newBalance !== undefined ? data.newBalance : balanceAfter,
          });
        } else {
          // Failure handling
          setShake(true);
          setTimeout(() => setShake(false), 600);
          setPin('');

          if (data.isLocked || res.status === 429) {
            setIsLocked(true);
            const remainingMins = data.lockedUntil ? Math.ceil((data.lockedUntil - Date.now()) / 1000) : 900;
            setLockoutSeconds(Math.max(60, remainingMins));
            setErrorMessage(data.error || 'Verifikasi PIN terkunci sementara karena 3 kali percobaan salah.');
          } else {
            if (data.remainingAttempts !== undefined) {
              setRemainingAttempts(data.remainingAttempts);
              setErrorMessage(`${data.error || 'PIN transaksi salah.'} (Sisa percobaan: ${data.remainingAttempts} kali)`);
            } else {
              setErrorMessage(data.error || 'PIN transaksi tidak sesuai. Silakan coba lagi.');
            }
          }
        }
      } catch (err) {
        console.error('Transaction execution error:', err);
        setErrorMessage('Terjadi gangguan jaringan saat memproses transaksi.');
        setPin('');
      } finally {
        setIsProcessing(false);
      }
    },
    [transactionData, isProcessing, isLocked, idempotencyKey, onSuccess, balanceAfter]
  );

  const handleDigitClick = (digit: string) => {
    if (pin.length >= 6 || isProcessing || isLocked) return;
    const newPin = pin + digit;
    setPin(newPin);
    setErrorMessage(null);

    if (newPin.length === 6) {
      executeTransactionWithPin(newPin);
    }
  };

  const handleDeleteDigit = () => {
    if (pin.length === 0 || isProcessing || isLocked) return;
    setPin((prev) => prev.slice(0, -1));
    setErrorMessage(null);
  };

  const handleClearPin = () => {
    if (isProcessing || isLocked) return;
    setPin('');
    setErrorMessage(null);
  };

  // Keyboard capture for desktop users
  useEffect(() => {
    if (!isOpen || showForgotPin) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (isProcessing || isLocked) return;

      if (e.key >= '0' && e.key <= '9') {
        if (pin.length < 6) {
          const newPin = pin + e.key;
          setPin(newPin);
          setErrorMessage(null);
          if (newPin.length === 6) {
            executeTransactionWithPin(newPin);
          }
        }
      } else if (e.key === 'Backspace') {
        handleDeleteDigit();
      } else if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, pin, isProcessing, isLocked, showForgotPin, executeTransactionWithPin, onClose]);

  if (!isOpen) return null;

  const formatLockoutTimer = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs">
        <motion.div
          initial={{ scale: 0.94, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.94, opacity: 0, y: 20 }}
          className={`w-full max-w-sm sm:max-w-md rounded-3xl p-5 sm:p-6 shadow-2xl border relative overflow-hidden ${
            isDarkMode
              ? 'bg-[#12281E] border-[#1E4330] text-white'
              : 'bg-white border-[#E2ECE5] text-[#0F2D1F]'
          }`}
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            disabled={isProcessing}
            className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 dark:hover:text-white transition-colors cursor-pointer disabled:opacity-50"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header Title */}
          <div className="flex items-center gap-2.5 pb-3 border-b border-gray-100 dark:border-gray-800">
            <div className="w-9 h-9 rounded-xl bg-[#EAF6EE] dark:bg-[#1A3828] text-[#143D28] dark:text-[#6BCB37] flex items-center justify-center shrink-0">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#143D28] dark:text-white">
                Verifikasi PIN Transaksi
              </h2>
              <p className="text-[11px] text-gray-500 dark:text-gray-400">
                Wajib untuk keamanan pemrosesan saldo
              </p>
            </div>
          </div>

          {/* Compact Transaction Preview */}
          <div className="mt-3.5 p-3.5 rounded-2xl bg-[#F4FAF6] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] space-y-2 text-xs">
            <div className="flex justify-between items-center text-gray-500 dark:text-gray-400">
              <span>Layanan / Penerima</span>
              <span className="font-bold text-[#143D28] dark:text-white truncate max-w-[180px]">
                {transactionData.recipientOrSender || transactionData.title}
              </span>
            </div>

            <div className="flex justify-between items-center text-gray-500 dark:text-gray-400">
              <span>Nominal Transaksi</span>
              <span className="font-bold text-[#143D28] dark:text-white">
                Rp{amount.toLocaleString('id-ID')}
              </span>
            </div>

            {fee > 0 && (
              <div className="flex justify-between items-center text-gray-500 dark:text-gray-400">
                <span>Biaya Admin</span>
                <span className="font-bold text-[#143D28] dark:text-white">
                  Rp{fee.toLocaleString('id-ID')}
                </span>
              </div>
            )}

            <div className="pt-2 border-t border-gray-200 dark:border-gray-800 flex justify-between items-center">
              <span className="font-bold text-gray-700 dark:text-gray-300">
                {transactionData.direction === 'in' || transactionData.type === 'topup' ? 'Total Penambahan Saldo' : 'Total Potong Saldo'}
              </span>
              <span className="text-sm font-extrabold text-[#143D28] dark:text-[#6BCB37]">
                Rp{totalDeduction.toLocaleString('id-ID')}
              </span>
            </div>
          </div>

          {/* Error / Lockout Alerts */}
          <AnimatePresence>
            {isLocked && lockoutSeconds !== null && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-3 p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/60 text-xs text-amber-800 dark:text-amber-300 flex items-start gap-2"
              >
                <Clock className="w-4 h-4 shrink-0 mt-0.5 text-amber-600 dark:text-amber-400 animate-pulse" />
                <div>
                  <div className="font-bold">Verifikasi PIN Terkunci Sementara</div>
                  <div className="mt-0.5">
                    Maksimal 3 kali percobaan tercapai. Buka kembali dalam{' '}
                    <span className="font-mono font-bold text-amber-900 dark:text-amber-200">
                      {formatLockoutTimer(lockoutSeconds)}
                    </span>{' '}
                    atau gunakan menu <span className="font-semibold underline cursor-pointer" onClick={() => setShowForgotPin(true)}>Lupa PIN</span>.
                  </div>
                </div>
              </motion.div>
            )}

            {!isLocked && errorMessage && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-3 p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 flex items-center gap-2 text-xs text-rose-700 dark:text-rose-300"
              >
                <AlertCircle className="w-4 h-4 shrink-0" />
                <div className="flex-1 font-medium">{errorMessage}</div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* 6-Digit PIN Indicator Dots with Shake animation */}
          <div className="my-4 text-center">
            <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-3">
              Masukkan 6 digit PIN TO PAY Anda
            </p>
            <motion.div
              animate={shake ? { x: [-10, 10, -10, 10, -5, 5, 0] } : {}}
              transition={{ duration: 0.4 }}
              className="flex items-center justify-center gap-3.5 sm:gap-4"
            >
              {[0, 1, 2, 3, 4, 5].map((index) => {
                const isFilled = pin.length > index;
                const isCurrent = pin.length === index;
                return (
                  <div
                    key={index}
                    className={`w-4 h-4 sm:w-5 sm:h-5 rounded-full transition-all duration-200 flex items-center justify-center border-2 ${
                      isFilled
                        ? isDarkMode
                          ? 'bg-[#6BCB37] border-[#6BCB37] scale-110 shadow-[0_0_10px_rgba(107,203,55,0.4)]'
                          : 'bg-[#143D28] border-[#143D28] scale-110 shadow-xs'
                        : isCurrent
                          ? isDarkMode
                            ? 'border-[#6BCB37] bg-transparent scale-105 animate-pulse'
                            : 'border-[#143D28] bg-transparent scale-105'
                          : isDarkMode
                            ? 'border-gray-700 bg-transparent'
                            : 'border-gray-300 bg-transparent'
                    }`}
                  >
                    {isFilled && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                  </div>
                );
              })}
            </motion.div>
          </div>

          {/* Processing Loading Overlay */}
          {isProcessing && (
            <div className="py-6 flex flex-col items-center justify-center gap-2">
              <Loader2 className="w-8 h-8 animate-spin text-[#143D28] dark:text-[#6BCB37]" />
              <p className="text-xs font-bold text-[#143D28] dark:text-[#6BCB37]">
                Memverifikasi PIN & Memproses Transaksi...
              </p>
            </div>
          )}

          {/* Virtual Numeric Keypad */}
          {!isProcessing && (
            <div className="space-y-2">
              <div className="grid grid-cols-3 gap-2">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                  <button
                    key={digit}
                    type="button"
                    onClick={() => handleDigitClick(digit)}
                    disabled={isLocked || pin.length >= 6}
                    className={`py-3 rounded-2xl font-bold text-lg transition-all active:scale-95 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed ${
                      isDarkMode
                        ? 'bg-[#0A1610] hover:bg-[#1A3D2A] text-white border border-[#1E4330]'
                        : 'bg-[#F4FAF6] hover:bg-[#EAF6EE] text-[#0F2D1F] border border-[#E2ECE5]'
                    }`}
                  >
                    {digit}
                  </button>
                ))}

                {/* Clear / Reset button */}
                <button
                  type="button"
                  onClick={handleClearPin}
                  disabled={isLocked || pin.length === 0}
                  className={`py-3 rounded-2xl font-bold text-xs transition-all active:scale-95 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed ${
                    isDarkMode
                      ? 'bg-[#0A1610] hover:bg-[#1A3D2A] text-gray-400 border border-[#1E4330]'
                      : 'bg-[#F4FAF6] hover:bg-[#EAF6EE] text-gray-500 border border-[#E2ECE5]'
                  }`}
                >
                  Hapus Semua
                </button>

                {/* Zero Digit */}
                <button
                  type="button"
                  onClick={() => handleDigitClick('0')}
                  disabled={isLocked || pin.length >= 6}
                  className={`py-3 rounded-2xl font-bold text-lg transition-all active:scale-95 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed ${
                    isDarkMode
                      ? 'bg-[#0A1610] hover:bg-[#1A3D2A] text-white border border-[#1E4330]'
                      : 'bg-[#F4FAF6] hover:bg-[#EAF6EE] text-[#0F2D1F] border border-[#E2ECE5]'
                  }`}
                >
                  0
                </button>

                {/* Backspace Button */}
                <button
                  type="button"
                  onClick={handleDeleteDigit}
                  disabled={isLocked || pin.length === 0}
                  className={`py-3 rounded-2xl font-bold text-xs flex items-center justify-center transition-all active:scale-95 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed ${
                    isDarkMode
                      ? 'bg-[#0A1610] hover:bg-[#1A3D2A] text-gray-300 border border-[#1E4330]'
                      : 'bg-[#F4FAF6] hover:bg-[#EAF6EE] text-[#0F2D1F] border border-[#E2ECE5]'
                  }`}
                >
                  <Delete className="w-5 h-5" />
                </button>
              </div>

              {/* Forgot PIN & Security Info Footer */}
              <div className="pt-2 flex items-center justify-between text-xs">
                <button
                  type="button"
                  onClick={() => setShowForgotPin(true)}
                  className="font-bold text-[#143D28] dark:text-[#6BCB37] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>Lupa PIN?</span>
                </button>

                <div className="flex items-center gap-1 text-[11px] text-gray-400">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#16A34A] dark:text-[#6BCB37]" />
                  <span>Enkripsi Kriptografis</span>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </div>

      {/* Forgot PIN Modal Recovery */}
      {showForgotPin && (
        <ForgotPinModal
          isOpen={showForgotPin}
          onClose={() => setShowForgotPin(false)}
          onPinResetSuccess={() => {
            setIsLocked(false);
            setLockoutSeconds(null);
            setRemainingAttempts(3);
            setErrorMessage(null);
            setPin('');
          }}
          isDarkMode={isDarkMode}
        />
      )}
    </>
  );
};
