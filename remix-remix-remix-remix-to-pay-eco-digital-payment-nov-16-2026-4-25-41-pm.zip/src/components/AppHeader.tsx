import React, { useState } from 'react';
import { Bell, Moon, Sun, Monitor } from 'lucide-react';
import { ToPayLogo } from './ToPayLogo';
import { UserProfile } from '../types';

interface AppHeaderProps {
  user: UserProfile;
  onProfileClick: () => void;
  onNotificationsClick: () => void;
  onToggleDarkMode: () => void;
  onSwitchToAdmin: () => void;
  isDarkMode?: boolean;
  isHomeTab?: boolean;
}

const BRAND_LOGO_SRC = '/assets/aistudio/IMG-20261113-WA0018_542ce974.jpg';

export const AppHeader: React.FC<AppHeaderProps> = ({
  user,
  onProfileClick,
  onNotificationsClick,
  onToggleDarkMode,
  onSwitchToAdmin,
  isDarkMode = false,
  isHomeTab = true,
}) => {
  const [logoImgFailed, setLogoImgFailed] = useState(false);

  return (
    <header className="w-full flex items-center justify-between gap-3 pb-3 pt-1">
      {/* Left side: Official Brand Logo + Greeting */}
      <div className="flex items-center gap-3 min-w-0">
        {!logoImgFailed ? (
          <img
            src={BRAND_LOGO_SRC}
            alt="TO PAY Logo"
            onError={() => setLogoImgFailed(true)}
            className={`h-11 w-auto object-contain shrink-0 transition-transform duration-200 hover:scale-105 ${
              isDarkMode
                ? 'bg-white/95 rounded-xl px-1.5 py-0.5'
                : 'mix-blend-multiply'
            }`}
          />
        ) : (
          <ToPayLogo
            size="sm"
            showText={true}
            showTagline={false}
            variant={isDarkMode ? 'white' : 'default'}
          />
        )}

        <div className="flex flex-col min-w-0 border-l border-gray-200 dark:border-[#1E4330] pl-3">
          {isHomeTab ? (
            <h1 className="text-sm sm:text-base font-extrabold text-gray-900 dark:text-white leading-tight truncate">
              Halo, {user.name}
            </h1>
          ) : (
            <p className="text-sm sm:text-base font-extrabold text-gray-900 dark:text-white leading-tight truncate">
              Halo, {user.name}
            </p>
          )}
          <p className="text-[11px] font-medium text-gray-600 dark:text-gray-300 truncate">
            Selamat datang kembali
          </p>
        </div>
      </div>

      {/* Right side: Admin switch, Dark mode toggle, Notifications, Avatar */}
      <div className="flex items-center gap-2 shrink-0">
        {/* Admin Dashboard switch button */}
        <button
          type="button"
          onClick={onSwitchToAdmin}
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-[#EAF6EE] hover:bg-[#D7EFE0] dark:bg-[#1A3828] dark:hover:bg-[#204E38] text-[#113C2B] dark:text-[#6BCB37] text-xs font-bold transition-all cursor-pointer border border-[#D7EFE0] dark:border-[#224E38]"
          title="Buka Web Admin Dashboard"
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>Web Admin</span>
        </button>

        {/* Theme toggle */}
        <button
          type="button"
          onClick={onToggleDarkMode}
          className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-[#12281E] dark:hover:bg-[#1A3828] text-[#113C2B] dark:text-[#6BCB37] transition-colors cursor-pointer border border-gray-200 dark:border-[#1E4330]"
          title={isDarkMode ? 'Beralih ke Light Mode' : 'Beralih ke Dark Mode'}
        >
          {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Notifications */}
        <button
          type="button"
          onClick={onNotificationsClick}
          className="relative p-2 rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-[#12281E] dark:hover:bg-[#1A3828] text-[#113C2B] dark:text-[#6BCB37] transition-colors cursor-pointer border border-gray-200 dark:border-[#1E4330]"
          title="Notifikasi"
        >
          <Bell className="w-4 h-4" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#6BCB37] ring-2 ring-white dark:ring-[#12281E]" />
        </button>

        {/* Avatar */}
        <button
          type="button"
          onClick={onProfileClick}
          className="relative rounded-full ring-2 ring-[#6BCB37] p-0.5 transition-transform hover:scale-105 cursor-pointer"
        >
          {user.avatarUrl ? (
            <img
              src={user.avatarUrl}
              alt={user.name || 'Profil Pengguna'}
              className="w-9 h-9 rounded-full object-cover"
            />
          ) : (
            <div className="w-9 h-9 rounded-full bg-[#143D28] text-[#6BCB37] font-extrabold text-xs flex items-center justify-center">
              {(user.name || 'U').trim().charAt(0).toUpperCase()}
            </div>
          )}
        </button>
      </div>
    </header>
  );
};
