import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, FileText, Lock, ShieldCheck, ArrowLeft, Loader2 } from 'lucide-react';
import { LegalDocument } from '../types';

interface LegalDocModalProps {
  type: 'terms' | 'privacy';
  isOpen: boolean;
  onClose: () => void;
  isDarkMode?: boolean;
}

export const LegalDocModal: React.FC<LegalDocModalProps> = ({
  type,
  isOpen,
  onClose,
  isDarkMode = false,
}) => {
  const [doc, setDoc] = useState<LegalDocument | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (isOpen) {
      setIsLoading(true);
      const endpoint = type === 'terms' ? '/api/legal/terms' : '/api/legal/privacy';
      fetch(endpoint)
        .then((res) => res.json())
        .then((data) => {
          if (data.success && data.document) {
            setDoc(data.document);
          }
        })
        .catch((err) => console.error('Error fetching legal doc:', err))
        .finally(() => setIsLoading(false));
    }
  }, [isOpen, type]);

  if (!isOpen) return null;

  const isTerms = type === 'terms';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs">
      <motion.div
        initial={{ scale: 0.94, opacity: 0, y: 15 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.94, opacity: 0, y: 15 }}
        className={`w-full max-w-xl rounded-3xl p-5 sm:p-6 shadow-2xl border relative overflow-hidden flex flex-col max-h-[90vh] ${
          isDarkMode
            ? 'bg-[#12281E] border-[#1E4330] text-white'
            : 'bg-white border-[#E2ECE5] text-[#0F2D1F]'
        }`}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 dark:hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 pb-4 border-b border-gray-100 dark:border-gray-800">
          <div className="w-11 h-11 rounded-2xl bg-[#EAF6EE] dark:bg-[#1A3828] text-[#143D28] dark:text-[#6BCB37] flex items-center justify-center shrink-0">
            {isTerms ? <FileText className="w-6 h-6" /> : <Lock className="w-6 h-6" />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-extrabold text-[#143D28] dark:text-white">
                {isTerms ? 'Syarat & Ketentuan' : 'Kebijakan Privasi'}
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#EAF6EE] text-[#143D28] dark:bg-[#1B3A29] dark:text-[#6BCB37]">
                v2.4.0
              </span>
            </div>
            <p className="text-[11px] text-gray-500 dark:text-gray-400">
              Terakhir diperbarui: 15 Agustus 2026 • Berlaku resmi
            </p>
          </div>
        </div>

        {/* Content Document */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1 text-xs">
          {isLoading ? (
            <div className="py-16 flex flex-col items-center justify-center text-gray-400 gap-2">
              <Loader2 className="w-6 h-6 animate-spin text-[#6BCB37]" />
              <span>Memuat dokumen legal...</span>
            </div>
          ) : doc ? (
            <div className="space-y-4">
              <div className="p-3 rounded-2xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] flex items-center gap-2 text-[11px] text-gray-600 dark:text-gray-300">
                <ShieldCheck className="w-4 h-4 text-[#16A34A] dark:text-[#6BCB37] shrink-0" />
                <span>
                  Dokumen ini mengatur hak dan kewajiban Anda sebagai pengguna terdaftar dompet digital TO PAY.
                </span>
              </div>

              {doc.sections.map((section, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-2xl border ${
                    isDarkMode ? 'bg-[#0A1610] border-[#1E4330]' : 'bg-gray-50/70 border-gray-100'
                  }`}
                >
                  <h3 className="text-xs sm:text-sm font-bold text-[#143D28] dark:text-white mb-1.5">
                    {section.heading}
                  </h3>
                  <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                    {section.content}
                  </p>
                </div>
              ))}
            </div>
          ) : null}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between">
          <span className="text-[10px] text-gray-400">
            PT TO PAY Digital Lestari • Berizin Bank Indonesia
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-[#143D28] text-white hover:bg-[#0E2C1D] text-xs font-bold transition-colors cursor-pointer"
          >
            Tutup Dokumen
          </button>
        </div>
      </motion.div>
    </div>
  );
};
