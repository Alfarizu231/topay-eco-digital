import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Send, Building2, UserCheck, ArrowRight, ShieldCheck, Check, Sparkles } from 'lucide-react';
import { BankProvider } from '../types';

interface TransferModalProps {
  bankList: BankProvider[];
  userBalance: number;
  onClose: () => void;
  onTransferComplete: (txData: {
    type: 'topay' | 'bank';
    recipient: string;
    accountNumber: string;
    bankName?: string;
    amount: number;
    note: string;
    fee: number;
  }) => void;
  isDarkMode?: boolean;
}

export const TransferModal: React.FC<TransferModalProps> = ({
  bankList,
  userBalance,
  onClose,
  onTransferComplete,
  isDarkMode = false,
}) => {
  const [transferType, setTransferType] = useState<'topay' | 'bank'>('topay');
  const [toPayUsernameOrPhone, setToPayUsernameOrPhone] = useState('');
  const [selectedBankId, setSelectedBankId] = useState(bankList[0].id);
  const [bankAccountNumber, setBankAccountNumber] = useState('');
  const [amount, setAmount] = useState<number>(0);
  const [note, setNote] = useState<string>('');
  const [step, setStep] = useState<'input' | 'confirm'>('input');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const selectedBank = bankList.find((b) => b.id === selectedBankId) || bankList[0];
  const fee = 0; // Bebas biaya admin

  const handleNext = () => {
    const targetRecipient = transferType === 'topay' ? toPayUsernameOrPhone.trim() : bankAccountNumber.trim();
    if (!targetRecipient) {
      setErrorMsg(
        transferType === 'topay'
          ? 'Masukkan Nomor HP atau TO PAY ID penerima.'
          : 'Masukkan nomor rekening bank tujuan.'
      );
      return;
    }
    if (!amount || amount <= 0) {
      setErrorMsg('Masukkan nominal transfer yang valid.');
      return;
    }
    if (amount > userBalance) {
      setErrorMsg('Saldo TO PAY Anda tidak mencukupi untuk nominal ini.');
      return;
    }
    setErrorMsg(null);
    setStep('confirm');
  };

  const handleExecute = () => {
    onTransferComplete({
      type: transferType,
      recipient:
        transferType === 'topay'
          ? `Pengguna TO PAY (${toPayUsernameOrPhone.trim()})`
          : `${selectedBank.name} - Rek ${bankAccountNumber.trim()}`,
      accountNumber: transferType === 'topay' ? toPayUsernameOrPhone.trim() : bankAccountNumber.trim(),
      bankName: transferType === 'bank' ? selectedBank.name : undefined,
      amount,
      note: note.trim(),
      fee,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className={`w-full max-w-lg rounded-2xl p-5 sm:p-6 shadow-2xl border ${
          isDarkMode ? 'bg-[#12281E] border-[#1E4330] text-white' : 'bg-white border-[#E2ECE5] text-[#0F2D1F]'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-gray-100 dark:border-gray-800">
          <div>
            <h2 className="text-lg font-bold text-[#143D28] dark:text-white">
              {step === 'input' ? 'Transfer Uang' : 'Konfirmasi Transfer'}
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Kirim uang instan bebas biaya admin
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {step === 'input' ? (
          <div className="mt-4 space-y-4 max-h-[75vh] overflow-y-auto pr-1">
            {/* Method Switcher: Transfer TO PAY vs Transfer Bank */}
            <div className="grid grid-cols-2 p-1 bg-[#EAF6EE] dark:bg-[#0A1610] rounded-xl">
              <button
                type="button"
                onClick={() => setTransferType('topay')}
                className={`py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  transferType === 'topay'
                    ? 'bg-[#143D28] text-white shadow-sm'
                    : 'text-gray-600 dark:text-gray-400 hover:text-[#143D28]'
                }`}
              >
                <UserCheck className="w-4 h-4 text-[#6BCB37]" />
                <span>Transfer TO PAY</span>
              </button>
              <button
                type="button"
                onClick={() => setTransferType('bank')}
                className={`py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  transferType === 'bank'
                    ? 'bg-[#143D28] text-white shadow-sm'
                    : 'text-gray-600 dark:text-gray-400 hover:text-[#143D28]'
                }`}
              >
                <Building2 className="w-4 h-4 text-[#6BCB37]" />
                <span>Transfer Bank</span>
              </button>
            </div>

            {/* Form Input fields */}
            {transferType === 'topay' ? (
              <div>
                <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1.5">
                  Nomor HP atau TO PAY ID
                </label>
                <input
                  type="text"
                  value={toPayUsernameOrPhone}
                  onChange={(e) => {
                    setToPayUsernameOrPhone(e.target.value);
                    if (errorMsg) setErrorMsg(null);
                  }}
                  placeholder="0812xxxx atau @username"
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-[#6BCB37] ${
                    isDarkMode
                      ? 'bg-[#0A1610] border-[#1E4330] text-white'
                      : 'bg-[#F4FAF6] border-[#D7EFE0] text-[#0F2D1F]'
                  }`}
                />
              </div>
            ) : (
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1.5">
                    Pilih Bank Tujuan
                  </label>
                  <select
                    value={selectedBankId}
                    onChange={(e) => setSelectedBankId(e.target.value)}
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#6BCB37] cursor-pointer ${
                      isDarkMode
                        ? 'bg-[#0A1610] border-[#1E4330] text-white'
                        : 'bg-[#F4FAF6] border-[#D7EFE0] text-[#0F2D1F]'
                    }`}
                  >
                    {bankList.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1.5">
                    Nomor Rekening
                  </label>
                  <input
                    type="text"
                    value={bankAccountNumber}
                    onChange={(e) => setBankAccountNumber(e.target.value)}
                    placeholder="Contoh: 8091 2341 55"
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#6BCB37] ${
                      isDarkMode
                        ? 'bg-[#0A1610] border-[#1E4330] text-white'
                        : 'bg-[#F4FAF6] border-[#D7EFE0] text-[#0F2D1F]'
                    }`}
                  />
                </div>
              </div>
            )}

            {/* Nominal Amount */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-xs font-bold text-[#143D28] dark:text-gray-200">
                  Nominal Transfer
                </label>
                <span className="text-[11px] text-gray-500">
                  Saldo: Rp{userBalance.toLocaleString('id-ID')}
                </span>
              </div>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-sm font-bold text-gray-500">
                  Rp
                </span>
                <input
                  type="number"
                  value={amount || ''}
                  onChange={(e) => {
                    setAmount(Number(e.target.value));
                    if (errorMsg) setErrorMsg(null);
                  }}
                  placeholder="0"
                  className={`w-full pl-10 pr-3 py-2.5 rounded-xl border text-base font-bold focus:outline-none focus:ring-2 focus:ring-[#6BCB37] ${
                    isDarkMode
                      ? 'bg-[#0A1610] border-[#1E4330] text-white'
                      : 'bg-[#F4FAF6] border-[#D7EFE0] text-[#0F2D1F]'
                  }`}
                />
              </div>
            </div>

            {/* Note */}
            <div>
              <label className="block text-xs font-bold text-[#143D28] dark:text-gray-200 mb-1.5">
                Catatan (Opsional)
              </label>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Tulis pesan..."
                className={`w-full px-3.5 py-2 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-[#6BCB37] ${
                  isDarkMode
                    ? 'bg-[#0A1610] border-[#1E4330] text-white'
                    : 'bg-[#F4FAF6] border-[#D7EFE0] text-[#0F2D1F]'
                }`}
              />
            </div>

            {/* Free fee green banner */}
            <div className="p-3 rounded-xl bg-[#F0FAF3] dark:bg-[#1A3828] border border-[#D7EFE0] dark:border-[#204E38] flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-[#143D28] dark:text-[#A3E635]">
                <Sparkles className="w-4 h-4 text-[#6BCB37]" />
                <span>Bebas Biaya Admin</span>
              </div>
              <span className="font-bold text-[#143D28] dark:text-[#6BCB37]">Rp0</span>
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-xs font-semibold text-rose-700 dark:text-rose-200">
                {errorMsg}
              </div>
            )}

            {/* Action */}
            <button
              type="button"
              onClick={handleNext}
              className="w-full py-3 px-4 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
            >
              <span>Lanjutkan</span>
              <ArrowRight className="w-4 h-4 text-[#6BCB37]" />
            </button>
          </div>
        ) : (
          /* Confirmation Step */
          <div className="mt-4 space-y-4">
            <div className="p-4 rounded-xl bg-[#F4FAF6] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] space-y-2.5 text-xs">
              <div className="flex justify-between items-center text-gray-500 dark:text-gray-400">
                <span>Tipe Transfer</span>
                <span className="font-bold text-[#143D28] dark:text-white">
                  {transferType === 'topay' ? 'Sesama TO PAY' : selectedBank.name}
                </span>
              </div>

              <div className="flex justify-between items-center text-gray-500 dark:text-gray-400">
                <span>Penerima</span>
                <span className="font-bold text-[#143D28] dark:text-white">
                  {transferType === 'topay' ? toPayUsernameOrPhone : bankAccountNumber}
                </span>
              </div>

              <div className="flex justify-between items-center text-gray-500 dark:text-gray-400">
                <span>Nominal</span>
                <span className="font-bold text-[#143D28] dark:text-white">
                  Rp{amount.toLocaleString('id-ID')}
                </span>
              </div>

              <div className="flex justify-between items-center text-gray-500 dark:text-gray-400">
                <span>Biaya Transaksi</span>
                <span className="font-bold text-[#6BCB37]">Gratis (Rp0)</span>
              </div>

              <div className="pt-2 border-t border-gray-200 dark:border-gray-800 flex justify-between items-center text-sm">
                <span className="font-bold text-[#143D28] dark:text-white">Total Debet</span>
                <span className="font-extrabold text-[#143D28] dark:text-[#6BCB37]">
                  Rp{amount.toLocaleString('id-ID')}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
              <ShieldCheck className="w-4 h-4 text-[#6BCB37]" />
              <span>Divalidasi dengan enkripsi finansial BI-FAST</span>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep('input')}
                className="py-2.5 px-3 rounded-xl border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 font-semibold text-xs hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
              >
                Ubah Data
              </button>
              <button
                type="button"
                onClick={handleExecute}
                className="py-2.5 px-3 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4 text-[#6BCB37]" />
                Transfer Sekarang
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};
