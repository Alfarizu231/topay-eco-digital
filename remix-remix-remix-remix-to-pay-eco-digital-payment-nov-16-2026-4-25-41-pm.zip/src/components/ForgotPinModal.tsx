import React, { useState } from 'react';
import { authFetch } from '../utils/authFetch';
import { motion, AnimatePresence } from 'motion/react';
import { X, KeyRound, ShieldCheck, Eye, EyeOff, AlertCircle, CheckCircle2, Lock, Loader2, Key } from 'lucide-react';
import { ToPayLogo } from './ToPayLogo';

interface ForgotPinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPinResetSuccess?: () => void;
  isDarkMode?: boolean;
}

export const ForgotPinModal: React.FC<ForgotPinModalProps> = ({
  isOpen,
  onClose,
  onPinResetSuccess,
  isDarkMode = false,
}) => {
  const [step, setStep] = useState<'verify' | 'new_pin'>('verify');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [showNewPin, setShowNewPin] = useState(false);
  const [showConfirmPin, setShowConfirmPin] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleVerifyPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) {
      setErrorMessage('Kata sandi akun wajib diisi untuk verifikasi keamanan.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await authFetch('/api/auth/pin/forgot-verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();

      if (res.ok && data.success) {
        setStep('new_pin');
      } else {
        setErrorMessage(data.error || 'Kata sandi tidak sesuai. Silakan coba lagi.');
      }
    } catch (err) {
      console.error('Forgot PIN verification error:', err);
      setErrorMessage('Terjadi gangguan jaringan. Coba beberapa saat lagi.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetPin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (newPin.length !== 6 || !/^\d{6}$/.test(newPin)) {
      setErrorMessage('PIN baru harus terdiri dari 6 digit angka.');
      return;
    }

    if (newPin !== confirmPin) {
      setErrorMessage('Konfirmasi PIN baru tidak sesuai.');
      return;
    }

    setIsLoading(true);

    try {
      const res = await authFetch('/api/auth/pin/reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          password,
          newPin,
          confirmPin,
        }),
      });
      const data = await res.json();

      if (res.ok && data.success) {
        setSuccessMessage('PIN transaksi berhasil diatur ulang dan pemblokiran telah dibuka.');
        if (onPinResetSuccess) onPinResetSuccess();
        setTimeout(() => {
          onClose();
        }, 2000);
      } else {
        setErrorMessage(data.error || 'Gagal mengatur ulang PIN.');
      }
    } catch (err) {
      console.error('Reset PIN error:', err);
      setErrorMessage('Gagal terhubung ke server.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDigitInput = (val: string, setter: (v: string) => void) => {
    const cleaned = val.replace(/\D/g, '').slice(0, 6);
    setter(cleaned);
    setErrorMessage(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xs">
      <motion.div
        initial={{ scale: 0.94, opacity: 0, y: 15 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.94, opacity: 0, y: 15 }}
        className={`w-full max-w-md rounded-3xl p-5 sm:p-6 shadow-2xl border relative overflow-hidden ${
          isDarkMode
            ? 'bg-[#12281E] border-[#1E4330] text-white'
            : 'bg-white border-[#E2ECE5] text-[#0F2D1F]'
        }`}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          disabled={isLoading}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 dark:hover:text-white transition-colors cursor-pointer disabled:opacity-50"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 pb-4 border-b border-gray-100 dark:border-gray-800">
          <div className="w-11 h-11 rounded-2xl bg-[#EAF6EE] dark:bg-[#1A3828] text-[#143D28] dark:text-[#6BCB37] flex items-center justify-center shrink-0">
            <Key className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-[#143D28] dark:text-white">
              Pemulihan / Lupa PIN
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {step === 'verify'
                ? 'Verifikasi kata sandi akun TO PAY Anda'
                : 'Buat 6 digit PIN transaksi baru'}
            </p>
          </div>
        </div>

        {/* Alerts */}
        <AnimatePresence>
          {errorMessage && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-3 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 flex items-start gap-2 text-xs text-rose-700 dark:text-rose-300"
            >
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{errorMessage}</div>
            </motion.div>
          )}

          {successMessage && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-3 p-3.5 rounded-xl bg-emerald-50 dark:bg-[#1A3828] border border-emerald-200 dark:border-[#224E38] flex items-center gap-2 text-xs text-emerald-800 dark:text-[#6BCB37]"
            >
              <CheckCircle2 className="w-5 h-5 shrink-0 text-[#16A34A] dark:text-[#6BCB37]" />
              <div className="flex-1 font-bold">{successMessage}</div>
            </motion.div>
          )}
        </AnimatePresence>

        {step === 'verify' ? (
          <form onSubmit={handleVerifyPassword} className="mt-4 space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                Kata Sandi Akun (Password)
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Masukkan kata sandi akun Anda"
                  disabled={isLoading}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm transition-all outline-none ${
                    isDarkMode
                      ? 'bg-[#0A1610] border-[#1E4330] text-white focus:border-[#6BCB37]'
                      : 'bg-white border-[#D7EFE0] text-[#0F2D1F] focus:border-[#143D28] focus:ring-2 focus:ring-[#143D28]/10'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-600 dark:hover:text-white cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] flex items-center gap-2 text-[11px] text-gray-500 dark:text-gray-400">
              <ShieldCheck className="w-4 h-4 text-[#16A34A] dark:text-[#6BCB37] shrink-0" />
              <span>Verifikasi ini memastikan hanya pemilik akun sah yang dapat mereset PIN.</span>
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={onClose}
                disabled={isLoading}
                className="flex-1 py-2.5 px-4 rounded-xl border border-gray-200 dark:border-gray-700 font-bold text-xs hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                disabled={isLoading || !password.trim()}
                className="flex-1 py-2.5 px-4 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white font-extrabold text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-[#6BCB37]" />
                    <span>Memverifikasi...</span>
                  </>
                ) : (
                  <span>Lanjutkan</span>
                )}
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleResetPin} className="mt-4 space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                PIN Baru (6 Digit Angka)
              </label>
              <div className="relative">
                <input
                  type={showNewPin ? 'text' : 'password'}
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={6}
                  value={newPin}
                  onChange={(e) => handleDigitInput(e.target.value, setNewPin)}
                  placeholder="Masukkan 6 digit PIN baru"
                  disabled={isLoading || !!successMessage}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-mono tracking-widest transition-all outline-none ${
                    isDarkMode
                      ? 'bg-[#0A1610] border-[#1E4330] text-white focus:border-[#6BCB37]'
                      : 'bg-white border-[#D7EFE0] text-[#0F2D1F] focus:border-[#143D28] focus:ring-2 focus:ring-[#143D28]/10'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowNewPin(!showNewPin)}
                  className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-600 dark:hover:text-white cursor-pointer"
                >
                  {showNewPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                Konfirmasi PIN Baru
              </label>
              <div className="relative">
                <input
                  type={showConfirmPin ? 'text' : 'password'}
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={6}
                  value={confirmPin}
                  onChange={(e) => handleDigitInput(e.target.value, setConfirmPin)}
                  placeholder="Ulangi 6 digit PIN"
                  disabled={isLoading || !!successMessage}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-mono tracking-widest transition-all outline-none ${
                    isDarkMode
                      ? 'bg-[#0A1610] border-[#1E4330] text-white focus:border-[#6BCB37]'
                      : 'bg-white border-[#D7EFE0] text-[#0F2D1F] focus:border-[#143D28] focus:ring-2 focus:ring-[#143D28]/10'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPin(!showConfirmPin)}
                  className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-600 dark:hover:text-white cursor-pointer"
                >
                  {showConfirmPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setStep('verify')}
                disabled={isLoading || !!successMessage}
                className="flex-1 py-2.5 px-4 rounded-xl border border-gray-200 dark:border-gray-700 font-bold text-xs hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
              >
                Kembali
              </button>
              <button
                type="submit"
                disabled={isLoading || !!successMessage || newPin.length !== 6 || confirmPin.length !== 6}
                className="flex-1 py-2.5 px-4 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white font-extrabold text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-[#6BCB37]" />
                    <span>Menyimpan PIN...</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3.5 h-3.5 text-[#6BCB37]" />
                    <span>Simpan & Aktifkan</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </motion.div>
    </div>
  );
};
