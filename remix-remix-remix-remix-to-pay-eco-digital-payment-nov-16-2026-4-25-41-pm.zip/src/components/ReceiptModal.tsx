import React, { useState } from 'react';
import { authFetch } from '../utils/authFetch';
import { motion } from 'motion/react';
import { X, CheckCircle2, Share2, Download, Leaf, ShieldCheck, RotateCcw, AlertCircle } from 'lucide-react';
import { Transaction } from '../types';
import { ToPayLogo } from './ToPayLogo';

interface ReceiptModalProps {
  transaction: Transaction;
  onClose: () => void;
  onRefundSuccess?: (newBalance: number) => void;
  isDarkMode?: boolean;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  transaction,
  onClose,
  onRefundSuccess,
  isDarkMode = false,
}) => {
  const [isRefunding, setIsRefunding] = useState(false);
  const [confirmRefund, setConfirmRefund] = useState(false);
  const [refundStatus, setRefundStatus] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const isIncome = transaction.direction === 'in';
  const isRefundable =
    !isIncome &&
    transaction.status !== 'REFUNDED' &&
    transaction.status !== 'FAILED' &&
    transaction.status !== 'CANCELLED';

  const handleProcessRefund = async () => {
    try {
      setIsRefunding(true);
      setErrorMsg(null);
      const res = await authFetch('/api/transactions/refund', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          transactionId: transaction.id,
          reason: 'Permintaan pengembalian dana oleh pemilik akun',
        }),
      });

      const data = await res.json();
      if (data.success) {
        setConfirmRefund(false);
        setRefundStatus(`Pengembalian dana berhasil. Saldo bertambah Rp${transaction.amount.toLocaleString('id-ID')}.`);
        if (onRefundSuccess && data.newBalance !== undefined) {
          onRefundSuccess(data.newBalance);
        }
      } else {
        setErrorMsg(data.error || 'Gagal memproses pengembalian dana.');
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Terjadi kesalahan jaringan.');
    } finally {
      setIsRefunding(false);
    }
  };

  const handleShareReceipt = async () => {
    const receiptSummary = [
      `RESI TRANSAKSI TO PAY`,
      `Status: ${transaction.status === 'REFUNDED' ? 'Direfund' : 'Berhasil'}`,
      `Transaksi: ${transaction.title}`,
      `Nominal: ${isIncome ? '+' : '-'}Rp${transaction.amount.toLocaleString('id-ID')}`,
      `Pihak Terkait: ${transaction.recipientOrSender}`,
      `Referensi: ${transaction.referenceNumber}`,
      `Tanggal: ${transaction.date}`,
    ].join('\n');

    try {
      if (navigator.share) {
        await navigator.share({
          title: `Resi TO PAY - ${transaction.title}`,
          text: receiptSummary,
        });
        setActionMessage('Resi transaksi berhasil dibagikan.');
      } else if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(receiptSummary);
        setActionMessage('Detail resi transaksi disalin ke clipboard.');
      }
    } catch {
      // User cancelled share or clipboard blocked
    }
    setTimeout(() => setActionMessage(null), 3000);
  };

  const handleDownloadReceipt = () => {
    const content = [
      '========================================',
      '           RESI RESMI TO PAY            ',
      '========================================',
      `Status         : ${transaction.status === 'REFUNDED' ? 'TRANSAKSI DIREFUND' : 'TRANSAKSI BERHASIL'}`,
      `Tanggal        : ${transaction.date}`,
      `Judul          : ${transaction.title}`,
      `Kategori       : ${transaction.category}`,
      `Pihak Terkait  : ${transaction.recipientOrSender}`,
      `Nomor Referensi: ${transaction.referenceNumber}`,
      `Nominal        : ${isIncome ? '+' : '-'}Rp${transaction.amount.toLocaleString('id-ID')}`,
      `Biaya Admin    : ${transaction.fee === 0 ? 'Gratis (Rp0)' : `Rp${transaction.fee.toLocaleString('id-ID')}`}`,
      transaction.note ? `Catatan        : ${transaction.note}` : null,
      '========================================',
      'TO PAY — Digital Eco Payment',
    ]
      .filter(Boolean)
      .join('\n');

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Resi-TOPAY-${transaction.referenceNumber || transaction.id}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setActionMessage('Bukti transaksi berhasil diunduh.');
    setTimeout(() => setActionMessage(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs">
      <motion.div
        initial={{ scale: 0.92, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.92, opacity: 0 }}
        className={`w-full max-w-md rounded-2xl p-5 sm:p-6 shadow-2xl border relative overflow-hidden ${
          isDarkMode ? 'bg-[#12281E] border-[#1E4330] text-white' : 'bg-white border-[#E2ECE5] text-[#0F2D1F]'
        }`}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 dark:hover:text-white cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top brand header */}
        <div className="flex flex-col items-center text-center pb-4 border-b border-gray-100 dark:border-gray-800">
          <ToPayLogo size="sm" showText={true} />

          <div className="w-12 h-12 rounded-full bg-[#EAF6EE] dark:bg-[#1A3828] flex items-center justify-center mt-3 mb-2">
            <CheckCircle2 className="w-7 h-7 text-[#16A34A] dark:text-[#6BCB37]" />
          </div>

          <span
            className={`text-xs font-bold uppercase tracking-wider ${
              transaction.status === 'REFUNDED' ? 'text-amber-600 dark:text-amber-400' : 'text-[#16A34A] dark:text-[#6BCB37]'
            }`}
          >
            {transaction.status === 'REFUNDED' ? 'Transaksi Direfund' : 'Transaksi Berhasil'}
          </span>
          <div className="text-2xl font-black text-[#143D28] dark:text-white mt-1">
            {isIncome ? '+' : '-'}Rp{transaction.amount.toLocaleString('id-ID')}
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{transaction.date}</p>
        </div>

        {refundStatus && (
          <div className="mt-3 p-2.5 rounded-xl bg-[#EAF6EE] dark:bg-[#183827] border border-[#16A34A]/30 text-xs text-[#143D28] dark:text-[#A3E635] flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#16A34A] flex-shrink-0" />
            <span>{refundStatus}</span>
          </div>
        )}

        {actionMessage && (
          <div className="mt-3 p-2.5 rounded-xl bg-[#EAF6EE] dark:bg-[#183827] border border-[#16A34A]/30 text-xs text-[#143D28] dark:text-[#A3E635] flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#16A34A] flex-shrink-0" />
            <span>{actionMessage}</span>
          </div>
        )}

        {errorMsg && (
          <div className="mt-3 p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 text-xs text-rose-600 dark:text-rose-400 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Details list */}
        <div className="py-3.5 space-y-2 text-xs">
          <div className="flex justify-between items-center text-gray-500 dark:text-gray-400">
            <span>Judul Transaksi</span>
            <span className="font-bold text-[#143D28] dark:text-white text-right truncate max-w-[200px]">
              {transaction.title}
            </span>
          </div>

          <div className="flex justify-between items-center text-gray-500 dark:text-gray-400">
            <span>Pihak Terkait</span>
            <span className="font-semibold text-[#143D28] dark:text-white text-right truncate max-w-[200px]">
              {transaction.recipientOrSender}
            </span>
          </div>

          <div className="flex justify-between items-center text-gray-500 dark:text-gray-400">
            <span>Kategori & Tipe</span>
            <span className="font-semibold text-[#143D28] dark:text-white">
              {transaction.category} ({transaction.direction === 'in' ? 'Uang Masuk' : 'Uang Keluar'})
            </span>
          </div>

          <div className="flex justify-between items-center text-gray-500 dark:text-gray-400">
            <span>Nomor Referensi</span>
            <span className="font-mono font-semibold text-[#143D28] dark:text-gray-200">
              {transaction.referenceNumber}
            </span>
          </div>

          <div className="flex justify-between items-center text-gray-500 dark:text-gray-400">
            <span>Biaya Transaksi</span>
            <span className="font-bold text-[#16A34A] dark:text-[#6BCB37]">
              {transaction.fee === 0 ? 'Gratis (Rp0)' : `Rp${transaction.fee.toLocaleString('id-ID')}`}
            </span>
          </div>

          {transaction.balanceBefore !== undefined && transaction.balanceAfter !== undefined && (
            <div className="p-2.5 rounded-xl bg-[#F4FAF6] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] space-y-1 my-1">
              <div className="flex justify-between text-[11px] text-gray-500">
                <span>Saldo Sebelum:</span>
                <span className="font-mono font-semibold text-gray-700 dark:text-gray-300">
                  Rp{transaction.balanceBefore.toLocaleString('id-ID')}
                </span>
              </div>
              <div className="flex justify-between text-[11px] text-gray-500">
                <span>Saldo Sesudah:</span>
                <span className="font-mono font-bold text-[#143D28] dark:text-white">
                  Rp{transaction.balanceAfter.toLocaleString('id-ID')}
                </span>
              </div>
            </div>
          )}

          {transaction.note && (
            <div className="flex justify-between items-start text-gray-500 dark:text-gray-400 pt-0.5">
              <span>Catatan</span>
              <span className="font-medium text-[#143D28] dark:text-gray-300 text-right max-w-[220px]">
                "{transaction.note}"
              </span>
            </div>
          )}

          {transaction.ecoImpact && (
            <div className="mt-2 p-2.5 rounded-xl bg-[#F0FAF3] dark:bg-[#0A1610] border border-[#D7EFE0] dark:border-[#1E4330] flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-[#143D28] dark:text-[#A3E635]">
                <Leaf className="w-3.5 h-3.5 text-[#6BCB37]" />
                <span>Kontribusi Karbon Hijau</span>
              </div>
              <span className="font-bold text-[#143D28] dark:text-white">
                +{transaction.ecoImpact.ecoPoints} Poin
              </span>
            </div>
          )}
        </div>

        {/* Security badge */}
        <div className="flex items-center justify-center gap-1.5 text-[11px] text-gray-400 py-1">
          <ShieldCheck className="w-3.5 h-3.5 text-[#6BCB37]" />
          <span>Resi Resmi Digital Terotentikasi TO PAY</span>
        </div>

        {/* Refund Button for Debit Transactions */}
        {isRefundable && !refundStatus && (
          <div className="pt-2">
            {confirmRefund ? (
              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 space-y-2 text-xs">
                <p className="font-semibold text-amber-900 dark:text-amber-200">
                  Ajukan pengembalian dana sebesar Rp{transaction.amount.toLocaleString('id-ID')} ke saldo TO PAY?
                </p>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setConfirmRefund(false)}
                    disabled={isRefunding}
                    className="flex-1 py-1.5 rounded-lg border border-amber-300 text-amber-900 dark:text-amber-200 font-semibold cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    onClick={handleProcessRefund}
                    disabled={isRefunding}
                    className="flex-1 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold cursor-pointer disabled:opacity-50"
                  >
                    {isRefunding ? 'Memproses...' : 'Ya, Kembalikan'}
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmRefund(true)}
                className="w-full py-2 px-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 hover:bg-amber-100 text-amber-800 dark:text-amber-300 text-xs font-bold border border-amber-200 dark:border-amber-800 transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Ajukan Pengembalian Dana (Refund)</span>
              </button>
            )}
          </div>
        )}

        {/* Bottom Actions */}
        <div className="grid grid-cols-2 gap-2.5 pt-2">
          <button
            type="button"
            onClick={handleShareReceipt}
            className="py-2.5 px-3 rounded-xl bg-[#EAF6EE] dark:bg-[#1A3828] text-[#143D28] dark:text-[#6BCB37] text-xs font-bold hover:bg-[#D7EFE0] transition-colors cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Share2 className="w-3.5 h-3.5" />
            Bagikan Resi
          </button>
          <button
            type="button"
            onClick={handleDownloadReceipt}
            className="py-2.5 px-3 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white text-xs font-bold shadow-md transition-colors cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5 text-[#6BCB37]" />
            Unduh Bukti
          </button>
        </div>
      </motion.div>
    </div>
  );
};
