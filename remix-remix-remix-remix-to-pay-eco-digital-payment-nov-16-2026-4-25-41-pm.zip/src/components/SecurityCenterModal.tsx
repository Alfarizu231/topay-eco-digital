import React from 'react';
import { motion } from 'motion/react';
import { X, ShieldCheck, CheckCircle2, AlertCircle, Fingerprint, Lock, Phone, Mail, Sparkles } from 'lucide-react';
import { UserProfile } from '../types';

interface SecurityCenterModalProps {
  user: UserProfile;
  onClose: () => void;
  isDarkMode?: boolean;
}

export const SecurityCenterModal: React.FC<SecurityCenterModalProps> = ({
  user,
  onClose,
  isDarkMode = false,
}) => {
  const checklist = [
    {
      title: 'Nomor HP Terverifikasi',
      desc: user.phone,
      active: user.isPhoneVerified,
      icon: Phone,
    },
    {
      title: 'PIN Transaksi Aktif',
      desc: '6 Digit PIN Keamanan Terproteksi',
      active: user.isPinActive,
      icon: Lock,
    },
    {
      title: 'Email Terverifikasi',
      desc: user.email,
      active: user.isEmailVerified,
      icon: Mail,
    },
    {
      title: 'Biometric Login Aktif',
      desc: 'Fingerprint & Face Recognition',
      active: user.isBiometricActive,
      icon: Fingerprint,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className={`w-full max-w-md rounded-2xl p-5 sm:p-6 shadow-2xl border ${
          isDarkMode ? 'bg-[#12281E] border-[#1E4330] text-white' : 'bg-white border-[#E2ECE5] text-[#0F2D1F]'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#EAF6EE] dark:bg-[#1A3828] flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-[#143D28] dark:text-[#6BCB37]" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-[#143D28] dark:text-white">
                TO PAY Security
              </h2>
              <p className="text-[11px] text-gray-500 dark:text-gray-400">
                Pusat Keamanan & Proteksi Akun
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Security Score Banner */}
        <div className="my-4 p-4 rounded-2xl bg-gradient-to-br from-[#143D28] to-[#1C4E35] text-white relative overflow-hidden border border-[#20553A]">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-emerald-200">
                Security Score Akun
              </span>
              <div className="text-3xl font-black text-white mt-0.5 flex items-baseline gap-1">
                <span>{user.securityScore}</span>
                <span className="text-sm font-bold text-emerald-200">/ 100</span>
              </div>
              <p className="text-xs text-[#A3E635] mt-1 font-semibold flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>
                  Status Akun:{' '}
                  {user.securityScore >= 80
                    ? 'Sangat Aman & Terproteksi'
                    : user.securityScore >= 50
                      ? 'Cukup Aman — Lengkapi Proteksi'
                      : 'Perlu Pengamanan Tambahan'}
                </span>
              </p>
            </div>

            {/* Shield Icon in pure Green */}
            <div className="w-16 h-16 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center">
              <ShieldCheck className="w-10 h-10 text-[#6BCB37]" />
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-2 bg-black/20 rounded-full mt-3 overflow-hidden">
            <div
              className="h-full bg-[#6BCB37] rounded-full transition-all duration-500"
              style={{ width: `${user.securityScore}%` }}
            />
          </div>
        </div>

        {/* Checklist */}
        <div className="space-y-2.5">
          <div className="text-xs font-bold text-[#143D28] dark:text-gray-200">
            Checklist Keamanan:
          </div>

          {checklist.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className={`p-3 rounded-xl border flex items-center justify-between ${
                  isDarkMode
                    ? 'bg-[#0A1610] border-[#1E4330]'
                    : 'bg-[#F9FCFA] border-[#E2ECE5]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#EAF6EE] dark:bg-[#1A3828] flex items-center justify-center">
                    <Icon className="w-4 h-4 text-[#143D28] dark:text-[#6BCB37]" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-[#143D28] dark:text-white">
                      {item.title}
                    </div>
                    <div className="text-[10px] text-gray-500 dark:text-gray-400">
                      {item.desc || '-'}
                    </div>
                  </div>
                </div>

                {item.active ? (
                  <div className="flex items-center gap-1 text-xs font-bold text-[#16A34A] dark:text-[#6BCB37]">
                    <CheckCircle2 className="w-4 h-4 text-[#6BCB37]" />
                    <span>Aktif</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1 text-xs font-bold text-amber-600 dark:text-amber-400">
                    <AlertCircle className="w-4 h-4" />
                    <span>Belum Aktif</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full mt-4 py-2.5 rounded-xl bg-[#143D28] hover:bg-[#0E2C1D] text-white font-bold text-xs shadow-md cursor-pointer transition-colors"
        >
          Selesai
        </button>
      </motion.div>
    </div>
  );
};
