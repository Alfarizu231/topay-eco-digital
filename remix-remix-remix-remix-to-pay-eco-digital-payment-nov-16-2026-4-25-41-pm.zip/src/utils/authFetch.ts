export function getUserAuthToken(): string | null {
  if (typeof window === 'undefined') return null;
  return (
    localStorage.getItem('topay_auth_token') ||
    sessionStorage.getItem('topay_auth_token')
  );
}

export function getAuthHeaders(extra?: Record<string, string>): Record<string, string> {
  const token = getUserAuthToken();
  const headers: Record<string, string> = {
    ...(extra || {}),
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

export function authFetch(input: RequestInfo | URL, init: RequestInit = {}): Promise<Response> {
  const token = getUserAuthToken();
  const headers = new Headers(init.headers || {});
  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }
  return fetch(input, {
    ...init,
    headers,
    credentials: 'same-origin',
  });
}
