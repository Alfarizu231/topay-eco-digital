export type TransactionType = 'topup' | 'transfer' | 'qris' | 'bill' | 'ewallet' | 'pulsa' | 'data' | 'refund' | 'cashback';
export type TransactionStatus = 'SUCCESS' | 'PENDING' | 'FAILED' | 'CANCELLED' | 'PROCESSING' | 'EXPIRED' | 'REFUNDED';
export type TransactionDirection = 'in' | 'out';

export interface Transaction {
  id: string;
  title: string;
  category: string;
  type: TransactionType;
  amount: number;
  fee: number;
  date: string;
  timestamp: number;
  direction: TransactionDirection;
  status: TransactionStatus;
  recipientOrSender: string;
  accountNumber?: string;
  referenceNumber: string;
  ecoImpact?: {
    co2SavedKg: number;
    ecoPoints: number;
  };
  note?: string;
  provider?: string;
  merchantNmid?: string;
  idempotencyKey?: string;
  refTransactionId?: string;
  balanceBefore?: number;
  balanceAfter?: number;
  ledgerId?: string;
}

export interface LedgerEntry {
  id: string;
  user_id: string;
  transaction_id: string;
  type: 'CREDIT' | 'DEBIT';
  category: string;
  amount: number;
  fee: number;
  total: number;
  status: TransactionStatus;
  balance_before: number;
  balance_after: number;
  payment_method: string;
  recipient_or_sender: string;
  account_number?: string;
  reference_number: string;
  description: string;
  created_at: number;
  date: string;
  idempotency_key?: string;
  ref_transaction_id?: string;
  eco_impact?: {
    co2SavedKg: number;
    ecoPoints: number;
  };
}

export interface CashFlowPeriodItem {
  period: string;
  income: number;
  expense: number;
  net: number;
}

export interface CashFlowSummary {
  currentBalance: number;
  totalIncome: number;
  totalExpense: number;
  netCashFlow: number;
  transactionCount: number;
  incomeCount: number;
  expenseCount: number;
  chartData: {
    daily: CashFlowPeriodItem[];
    weekly: CashFlowPeriodItem[];
    monthly: CashFlowPeriodItem[];
  };
  categoryBreakdown: {
    income: { category: string; amount: number; percentage: number; color: string }[];
    expense: { category: string; amount: number; percentage: number; color: string }[];
  };
  reconciliation: ReconciliationResult;
}

export interface ReconciliationResult {
  status: 'BALANCED' | 'BALANCE_MISMATCH';
  isMatched: boolean;
  baselineBalance: number;
  totalCredit: number;
  totalDebit: number;
  computedBalance: number;
  storedBalance: number;
  discrepancy: number;
  ledgerCount: number;
  lastCheckedAt: string;
}

export interface UserProfile {
  name: string;
  username: string;
  phone: string;
  email: string;
  bio?: string;
  avatarUrl?: string;
  membershipTier: string;
  balance: number;
  ecoPoints: number;
  treesPlanted: number;
  co2SavedKg: number;
  isPhoneVerified: boolean;
  isEmailVerified: boolean;
  isPinActive: boolean;
  isBiometricActive: boolean;
  isNotificationActive?: boolean;
  securityScore: number;
  pinHash?: string;
}

export interface ChangePinRequest {
  currentPin: string;
  newPin: string;
  confirmPin: string;
}

export interface ChangePinResponse {
  success: boolean;
  message?: string;
  error?: string;
  attemptsLeft?: number;
}

export interface ConnectedDevice {
  id: string;
  name: string;
  type: 'mobile' | 'tablet' | 'desktop';
  browser: string;
  os: string;
  ipLocation: string;
  lastActive: string;
  isCurrent: boolean;
  status: 'active' | 'revoked';
  loginTimestamp: number;
}

export interface FAQItem {
  id: string;
  category: 'Akun' | 'Transaksi' | 'QRIS' | 'Top Up' | 'Transfer' | 'Keamanan';
  question: string;
  answer: string;
}

export type TicketPriority = 'Tinggi' | 'Sedang' | 'Rendah';
export type TicketStatus = 'Menunggu' | 'Diproses' | 'Tunggu User' | 'Selesai';

export interface TicketReply {
  id: string;
  ticket_id: string;
  sender_id: string;
  sender_role: 'user' | 'admin';
  sender_name: string;
  message: string;
  created_at: number;
  dateFormatted?: string;
}

export interface ComplaintTicket {
  id: string;
  ticket_code: string;
  order_id: string;
  user_id: string;
  user_name: string;
  user_email: string;
  category: string;
  subject: string;
  description: string;
  attachment_url?: string;
  priority: TicketPriority;
  status: TicketStatus;
  created_at: number;
  updated_at: number;
  dateFormatted?: string;
  updatedFormatted?: string;
  replies?: TicketReply[];
  replyCount?: number;
}

export interface TicketSummaryStats {
  total: number;
  menunggu: number;
  diproses: number;
  tungguUser: number;
  selesai: number;
}

export interface SupportTicket {
  id: string;
  name: string;
  email: string;
  phone: string;
  category: string;
  subject: string;
  message: string;
  createdAt: string;
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED';
}

export interface LegalDocument {
  title: string;
  version: string;
  lastUpdated: string;
  effectiveDate: string;
  sections: {
    heading: string;
    content: string;
    subsections?: { title: string; text: string }[];
  }[];
}

export interface QRISMerchantInfo {
  merchantName: string;
  nmid: string;
  city: string;
  postalCode?: string;
  category: string;
  isDynamic: boolean;
  defaultAmount?: number;
  fee: number;
  rawPayload: string;
  acquirer?: string;
}

export interface QRISPaymentRequest {
  merchantName: string;
  nmid: string;
  amount: number;
  fee: number;
  note?: string;
  idempotencyKey: string;
  pin: string;
}

export interface QRISPaymentResponse {
  success: boolean;
  status: TransactionStatus;
  transaction?: Transaction;
  newBalance?: number;
  message?: string;
  error?: string;
}

export interface EWalletProvider {
  id: 'gopay' | 'dana' | 'ovo' | 'shopeepay';
  name: string;
  logoText: string;
  fee: number;
  minAmount: number;
  maxAmount: number;
  description: string;
}

export interface BankProvider {
  id: string;
  name: string;
  code: string;
  accountNumberSample: string;
  popular?: boolean;
}

export interface ServiceItem {
  id: string;
  title: string;
  iconName: string;
  category: string;
  badge?: string;
  description: string;
}

export interface PromoItem {
  id: string;
  title: string;
  discount: string;
  code: string;
  category: string;
  validUntil: string;
  description: string;
  terms: string[];
  bannerStyle: 'forest' | 'lime' | 'organic';
}

export interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  totalTransactions: number;
  transactionVolume: number;
  totalTopUp: number;
  totalTransfer: number;
  totalQRIS: number;
  successRate: number;
}

export interface AIInsight {
  id: string;
  title: string;
  message: string;
  category: 'growth' | 'qris' | 'ewallet' | 'security' | 'eco';
  impact: 'positive' | 'neutral' | 'alert';
  metricHighlight: string;
  dateGenerated: string;
}

export type AccountStatus = 'active' | 'blocked' | 'pending' | 'inactive';

export interface AdminUser {
  id: string;
  username: string;
  name: string;
  email: string;
  role: 'admin' | 'superadmin' | 'operator';
  avatarUrl?: string;
  lastLogin?: string;
}

export interface ManagedUser {
  id: string;
  name: string;
  username: string;
  phone: string;
  email: string;
  avatarUrl?: string;
  membershipTier: string;
  balance: number;
  ecoPoints: number;
  treesPlanted: number;
  co2SavedKg: number;
  isPhoneVerified: boolean;
  isEmailVerified: boolean;
  isPinActive: boolean;
  isBiometricActive: boolean;
  securityScore: number;
  status: AccountStatus;
  blockedReason?: string;
  blockedAt?: string;
  blockedBy?: string;
  unblockedAt?: string;
  unblockedBy?: string;
  registeredAt: string;
  lastLogin: string;
  transactionCount: number;
  totalTransactionAmount: number;
  activeDevices?: ConnectedDevice[];
  recentTransactions?: Transaction[];
}

export interface AuditLogEntry {
  id: string;
  adminId: string;
  adminName: string;
  action: string;
  targetUser?: string;
  targetUserId?: string;
  timestamp: number;
  date: string;
  status: 'SUCCESS' | 'FAILED';
  details: string;
  ipAddress?: string;
  riskScore?: number;
  riskLevel?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface SecurityIncident {
  id: string;
  type: 'BRUTE_FORCE' | 'HIGH_VALUE_TX' | 'VELOCITY_ANOMALY' | 'DEVICE_ANOMALY' | 'SUSPICIOUS_LOGIN' | 'SYSTEM_LOCKDOWN';
  severity: RiskLevel;
  userId?: string;
  userIdentifier?: string;
  description: string;
  timestamp: number;
  date: string;
  ipAddress: string;
  deviceInfo?: string;
  status: 'DETECTED' | 'MITIGATED' | 'BLOCKED' | 'INVESTIGATING';
  mitigationAction?: string;
}

export interface SecurityChallenge {
  challengeId: string;
  type: 'MATH_CAPTCHA' | 'STEP_UP_OTP';
  question: string;
  expiresAt: number;
}

export interface SecurityAlert {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'login' | 'device' | 'pin' | 'tx_risk' | 'lockout' | 'warning';
  timestamp: number;
  date: string;
  isRead: boolean;
  severity: 'info' | 'warning' | 'danger';
}

export interface SecurityDiagnostics {
  overallScore: number;
  encryptionStatus: string;
  bruteForceProtection: boolean;
  activeSessionsCount: number;
  lastSecurityEvent?: string;
  threatLevel: 'NORMAL' | 'ELEVATED' | 'HIGH';
  isSystemLockdownActive: boolean;
  checks: {
    name: string;
    status: 'PASSED' | 'WARNING' | 'FAILED';
    detail: string;
  }[];
}

export interface AdminOverviewStats {
  totalUsers: number;
  activeUsers: number;
  newUsers: number;
  blockedUsers: number;
  totalTransactions: number;
  todayTransactions: number;
  successTransactions: number;
  failedTransactions: number;
  totalTransactionVolume: number;
  totalUserBalance: number;
  successRate: number;
  userGrowthData: { name: string; users: number; active: number }[];
  transactionCountData: { name: string; count: number; failed: number }[];
  transactionVolumeData: { name: string; volume: number }[];
  userActivityData: { hour: string; active: number; transactions: number }[];
  categoryBreakdown: { name: string; value: number; color: string }[];
  recentActivities: AuditLogEntry[];
}
