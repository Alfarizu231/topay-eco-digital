import crypto from 'crypto';
import { RiskLevel, SecurityIncident, SecurityChallenge } from '../types';

// =================================================================
// 1. CRYPTOGRAPHIC PASSWORD & PIN HASHING (PBKDF2 + TIMING-SAFE)
// =================================================================

const PBKDF2_ITERATIONS = 12000;
const PBKDF2_KEYLEN = 32;
const PBKDF2_DIGEST = 'sha256';
const LEGACY_PIN_SALT = process.env.TOPAY_LEGACY_PIN_SALT || 'TOPAY_SECURE_SALT_2026_';

function timingSafeHexCompare(hexA: string, hexB: string): boolean {
  try {
    const bufA = Buffer.from(hexA, 'hex');
    const bufB = Buffer.from(hexB, 'hex');
    if (bufA.length === 0 || bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
  } catch {
    return false;
  }
}

/**
 * Hash a password using PBKDF2 with a unique random 16-byte cryptographic salt
 */
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto
    .pbkdf2Sync(password, salt, PBKDF2_ITERATIONS, PBKDF2_KEYLEN, PBKDF2_DIGEST)
    .toString('hex');
  return `pbkdf2:${PBKDF2_ITERATIONS}:${salt}:${hash}`;
}

/**
 * Verify a plaintext password against a stored PBKDF2 hash (no hardcoded backdoor passwords)
 */
export function verifyPassword(password: string, storedHash?: string): boolean {
  if (!password || !storedHash || typeof storedHash !== 'string') return false;

  if (storedHash.startsWith('pbkdf2:')) {
    const parts = storedHash.split(':');
    if (parts.length !== 4) return false;
    const iterations = parseInt(parts[1], 10);
    const salt = parts[2];
    const storedKey = parts[3];
    if (!Number.isFinite(iterations) || iterations < 1000 || !salt || !storedKey) return false;

    const derivedKey = crypto
      .pbkdf2Sync(password, salt, iterations, PBKDF2_KEYLEN, PBKDF2_DIGEST)
      .toString('hex');
    return timingSafeHexCompare(derivedKey, storedKey);
  }

  return false;
}

/**
 * Secure Per-User Salted PBKDF2 PIN Hashing
 */
export function hashPin(pin: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto
    .pbkdf2Sync(`pin:${pin}`, salt, PBKDF2_ITERATIONS, PBKDF2_KEYLEN, PBKDF2_DIGEST)
    .toString('hex');
  return `pbkdf2:${PBKDF2_ITERATIONS}:${salt}:${hash}`;
}

/**
 * Check if a 6-digit transaction PIN is weak or trivial
 */
export function isWeakPin(pin: string): { isWeak: boolean; reason?: string } {
  if (!pin || typeof pin !== 'string') {
    return { isWeak: true, reason: 'PIN transaksi wajib diisi.' };
  }

  const cleaned = pin.trim();
  if (!/^\d{6}$/.test(cleaned)) {
    return { isWeak: true, reason: 'PIN harus terdiri dari tepat 6 digit angka.' };
  }

  if (/^(\d)\1{5}$/.test(cleaned)) {
    return {
      isWeak: true,
      reason: 'PIN tidak boleh menggunakan angka yang sama berulang (contoh: 000000 atau 111111).',
    };
  }

  const sequentialPatterns = [
    '012345',
    '123456',
    '234567',
    '345678',
    '456789',
    '987654',
    '876543',
    '765432',
    '654321',
    '543210',
  ];
  if (sequentialPatterns.includes(cleaned)) {
    return {
      isWeak: true,
      reason: 'PIN tidak boleh menggunakan pola angka berurutan (contoh: 123456 atau 654321).',
    };
  }

  const repeatedSubstrings = [
    '123123',
    '321321',
    '121212',
    '212121',
    '112233',
    '332211',
    '111222',
    '000111',
    '999888',
    '123321',
    '654456',
    '010101',
    '101010',
    '131313',
    '313131',
    '242424',
    '424242',
    '696969',
  ];
  if (repeatedSubstrings.includes(cleaned)) {
    return {
      isWeak: true,
      reason: 'PIN terlalu mudah ditebak. Gunakan kombinasi 6 angka yang lebih unik.',
    };
  }

  return { isWeak: false };
}

/**
 * Constant-time PIN Verification (PBKDF2 primary + timing-safe legacy SHA-256 migration support)
 */
export function verifyPinMatch(inputPin: string, storedHash?: string): boolean {
  if (!inputPin || !storedHash || typeof storedHash !== 'string') return false;

  if (storedHash.startsWith('pbkdf2:')) {
    const parts = storedHash.split(':');
    if (parts.length !== 4) return false;
    const iterations = parseInt(parts[1], 10);
    const salt = parts[2];
    const storedKey = parts[3];
    if (!Number.isFinite(iterations) || iterations < 1000 || !salt || !storedKey) return false;

    const derivedKey = crypto
      .pbkdf2Sync(`pin:${inputPin}`, salt, iterations, PBKDF2_KEYLEN, PBKDF2_DIGEST)
      .toString('hex');
    return timingSafeHexCompare(derivedKey, storedKey);
  }

  // Legacy Salted SHA-256 support for pre-existing records (upgraded to PBKDF2 on verify)
  const legacySaltedHash = crypto
    .createHash('sha256')
    .update(`${LEGACY_PIN_SALT}${inputPin}`)
    .digest('hex');
  if (timingSafeHexCompare(legacySaltedHash, storedHash)) return true;

  return false;
}

/**
 * Verify HMAC-SHA256 webhook signature safely
 */
export function verifyWebhookSignature(payloadString: string, signatureHex: string, secret: string): boolean {
  if (!payloadString || !signatureHex || !secret) return false;
  const expected = crypto.createHmac('sha256', secret).update(payloadString).digest('hex');
  const cleanSig = signatureHex.replace(/^sha256=/i, '').trim().toLowerCase();
  return timingSafeHexCompare(expected, cleanSig);
}

// =================================================================
// 2. BRUTE-FORCE PROTECTION & RATE LIMITING WITH EXPONENTIAL BACKOFF
// =================================================================

interface AttemptRecord {
  count: number;
  firstAttempt: number;
  lastAttempt: number;
  lockedUntil: number;
  requiresChallenge: boolean;
}

class SecurityRateLimiter {
  private identifierAttempts = new Map<string, AttemptRecord>();
  private ipAttempts = new Map<string, AttemptRecord>();
  private maxAttemptsBeforeChallenge = 3;
  private maxAttemptsBeforeLockout = 5;
  private lockoutDurationMs = 15 * 60 * 1000;

  private cleanKey(key: string): string {
    return (key || '').toLowerCase().trim().replace(/[@\s-]/g, '');
  }

  private pruneStale() {
    const now = Date.now();
    if (this.identifierAttempts.size > 5000) {
      for (const [k, v] of this.identifierAttempts.entries()) {
        if (now - v.lastAttempt > 2 * 60 * 60 * 1000 && v.lockedUntil < now) {
          this.identifierAttempts.delete(k);
        }
      }
    }
    if (this.ipAttempts.size > 5000) {
      for (const [k, v] of this.ipAttempts.entries()) {
        if (now - v.lastAttempt > 2 * 60 * 60 * 1000 && v.lockedUntil < now) {
          this.ipAttempts.delete(k);
        }
      }
    }
  }

  public checkLockout(identifier: string, ip: string): { isLocked: boolean; remainingSeconds: number; requiresChallenge: boolean } {
    this.pruneStale();
    const now = Date.now();
    const cleanId = this.cleanKey(identifier);

    const recordId = cleanId ? this.identifierAttempts.get(cleanId) : undefined;
    const recordIp = ip ? this.ipAttempts.get(ip) : undefined;

    const lockedUntilId = recordId && recordId.lockedUntil > now ? recordId.lockedUntil : 0;
    const lockedUntilIp = recordIp && recordIp.lockedUntil > now ? recordIp.lockedUntil : 0;
    const maxLock = Math.max(lockedUntilId, lockedUntilIp);

    if (maxLock > now) {
      return {
        isLocked: true,
        remainingSeconds: Math.ceil((maxLock - now) / 1000),
        requiresChallenge: true,
      };
    }

    const needsChallenge =
      (recordId ? recordId.count >= this.maxAttemptsBeforeChallenge : false) ||
      (recordIp ? recordIp.count >= this.maxAttemptsBeforeChallenge : false);

    return {
      isLocked: false,
      remainingSeconds: 0,
      requiresChallenge: needsChallenge,
    };
  }

  public recordFailure(identifier: string, ip: string): {
    attempts: number;
    remaining: number;
    lockedUntil: number | null;
    requiresChallenge: boolean;
    backoffMs: number;
  } {
    this.pruneStale();
    const now = Date.now();
    const cleanId = this.cleanKey(identifier);

    const updateRecord = (map: Map<string, AttemptRecord>, key: string): AttemptRecord => {
      let rec = map.get(key);
      if (!rec || now - rec.lastAttempt > 60 * 60 * 1000) {
        rec = { count: 1, firstAttempt: now, lastAttempt: now, lockedUntil: 0, requiresChallenge: false };
      } else {
        rec.count += 1;
        rec.lastAttempt = now;
      }

      if (rec.count >= this.maxAttemptsBeforeLockout) {
        rec.lockedUntil = now + this.lockoutDurationMs;
        rec.requiresChallenge = true;
      } else if (rec.count >= this.maxAttemptsBeforeChallenge) {
        rec.requiresChallenge = true;
      }

      map.set(key, rec);
      return rec;
    };

    const recId = cleanId ? updateRecord(this.identifierAttempts, cleanId) : null;
    const recIp = ip ? updateRecord(this.ipAttempts, ip) : null;

    const count = Math.max(recId?.count || 0, recIp?.count || 0);
    const lockedUntil = Math.max(recId?.lockedUntil || 0, recIp?.lockedUntil || 0);
    const remaining = Math.max(0, this.maxAttemptsBeforeLockout - count);
    const backoffMs = Math.min(1000 * Math.pow(2, count - 1), 10000);

    return {
      attempts: count,
      remaining,
      lockedUntil: lockedUntil > now ? lockedUntil : null,
      requiresChallenge: count >= this.maxAttemptsBeforeChallenge,
      backoffMs,
    };
  }

  public recordSuccess(identifier: string, ip: string): void {
    const cleanId = this.cleanKey(identifier);
    if (cleanId) this.identifierAttempts.delete(cleanId);
    if (ip) this.ipAttempts.delete(ip);
  }

  public getStats() {
    return {
      activeLockedAccounts: Array.from(this.identifierAttempts.values()).filter((r) => r.lockedUntil > Date.now()).length,
      activeSuspiciousIPs: Array.from(this.ipAttempts.values()).filter((r) => r.count >= this.maxAttemptsBeforeChallenge).length,
    };
  }
}

export const securityRateLimiter = new SecurityRateLimiter();

// =================================================================
// 3. GENERAL API SLIDING-WINDOW RATE LIMITER
// =================================================================

class ApiRateLimiter {
  private buckets = new Map<string, { count: number; resetAt: number }>();

  public consume(key: string, maxRequests: number, windowMs: number): { allowed: boolean; retryAfterSec: number } {
    const now = Date.now();
    if (this.buckets.size > 10000) {
      for (const [k, v] of this.buckets.entries()) {
        if (v.resetAt <= now) this.buckets.delete(k);
      }
    }

    const existing = this.buckets.get(key);
    if (!existing || existing.resetAt <= now) {
      this.buckets.set(key, { count: 1, resetAt: now + windowMs });
      return { allowed: true, retryAfterSec: 0 };
    }

    if (existing.count >= maxRequests) {
      return {
        allowed: false,
        retryAfterSec: Math.max(1, Math.ceil((existing.resetAt - now) / 1000)),
      };
    }

    existing.count += 1;
    return { allowed: true, retryAfterSec: 0 };
  }
}

export const apiRateLimiter = new ApiRateLimiter();

// =================================================================
// 4. SECURITY CHALLENGES (MATH CAPTCHA & STEP-UP VERIFICATION)
// =================================================================

interface ActiveChallenge {
  answer: string;
  expiresAt: number;
}

const activeChallenges = new Map<string, ActiveChallenge>();

export function generateSecurityChallenge(): SecurityChallenge {
  const now = Date.now();
  if (activeChallenges.size > 2000) {
    for (const [k, v] of activeChallenges.entries()) {
      if (v.expiresAt <= now) activeChallenges.delete(k);
    }
  }

  const challengeId = `CHAL-${now}-${crypto.randomBytes(6).toString('hex')}`;
  const num1 = crypto.randomInt(10, 50);
  const num2 = crypto.randomInt(5, 30);
  const answer = (num1 + num2).toString();

  const expiresAt = now + 5 * 60 * 1000;
  activeChallenges.set(challengeId, { answer, expiresAt });

  return {
    challengeId,
    type: 'MATH_CAPTCHA',
    question: `Berapakah hasil dari ${num1} + ${num2}?`,
    expiresAt,
  };
}

export function verifySecurityChallenge(challengeId: string, answer: string): boolean {
  if (!challengeId || !answer) return false;
  const challenge = activeChallenges.get(challengeId);
  if (!challenge) return false;

  if (Date.now() > challenge.expiresAt) {
    activeChallenges.delete(challengeId);
    return false;
  }

  const isMatch = challenge.answer.trim().toLowerCase() === answer.trim().toLowerCase();
  activeChallenges.delete(challengeId);
  return isMatch;
}

// =================================================================
// 5. REAL-TIME RISK & ANTI-FRAUD ENGINE
// =================================================================

export interface RiskEvaluationResult {
  riskScore: number;
  riskLevel: RiskLevel;
  flags: string[];
  requiresStepUp: boolean;
  isBlocked: boolean;
  blockReason?: string;
}

export function evaluateTransactionRisk(params: {
  userId: string;
  amount: number;
  type: string;
  recentTransactions?: { amount: number; timestamp: number }[];
  isSystemLockdownActive?: boolean;
}): RiskEvaluationResult {
  const { amount, recentTransactions = [], isSystemLockdownActive = false } = params;

  let riskScore = 10;
  const flags: string[] = [];

  if (isSystemLockdownActive) {
    return {
      riskScore: 100,
      riskLevel: 'CRITICAL',
      flags: ['Sistem Keamanan Pusat dalam Mode Darurat (System Lockdown Active)'],
      requiresStepUp: true,
      isBlocked: true,
      blockReason: 'Transaksi dibekukan sementara karena sistem sedang dalam mode proteksi darurat (System Lockdown).',
    };
  }

  if (amount >= 15000000) {
    riskScore += 65;
    flags.push('Transaksi Nilai Sangat Tinggi (>= Rp15.000.000)');
  } else if (amount >= 5000000) {
    riskScore += 35;
    flags.push('Transaksi Nilai Signifikan (>= Rp5.000.000)');
  } else if (amount >= 2000000) {
    riskScore += 15;
    flags.push('Transaksi Nilai Menengah');
  }

  const now = Date.now();
  const txLastMinute = recentTransactions.filter((t) => now - t.timestamp < 60 * 1000);
  if (txLastMinute.length >= 3) {
    riskScore += 45;
    flags.push('Anomali Frekuensi Transaksi Tinggi (3+ transaksi dalam 1 menit)');
  } else if (txLastMinute.length >= 2) {
    riskScore += 20;
    flags.push('Frekuensi Transaksi Cepat');
  }

  riskScore = Math.min(100, Math.max(0, riskScore));

  let riskLevel: RiskLevel = 'LOW';
  let requiresStepUp = false;
  let isBlocked = false;
  let blockReason: string | undefined;

  if (riskScore >= 85) {
    riskLevel = 'CRITICAL';
    isBlocked = true;
    blockReason = 'Transaksi diblokir otomatis oleh AI Anti-Fraud Engine karena indikasi risiko kritis.';
  } else if (riskScore >= 60) {
    riskLevel = 'HIGH';
    requiresStepUp = true;
  } else if (riskScore >= 30) {
    riskLevel = 'MEDIUM';
  }

  return {
    riskScore,
    riskLevel,
    flags,
    requiresStepUp,
    isBlocked,
    blockReason,
  };
}
