export const PUBLIC_CONTACT = {
  email: 'muhammadalfarizi2009',
  phoneDisplay: '+628567348139',
  phoneHref: 'tel:+628567348139',
  whatsappNumber: '628567348139',
  whatsappHref:
    'https://wa.me/628567348139?text=Halo%20TO%20PAY%20Care,%20saya%20membutuhkan%20bantuan',
  mailtoHref: 'mailto:muhammadalfarizi2009',
  mailtoSupportHref: 'mailto:muhammadalfarizi2009?subject=Bantuan%20Akun%20TO%20PAY',
} as const;
